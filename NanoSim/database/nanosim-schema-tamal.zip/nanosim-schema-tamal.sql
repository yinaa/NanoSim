-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 16, 2009 at 02:54 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nanosim`
--
CREATE DATABASE `nanosim` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `nanosim`;

-- --------------------------------------------------------

--
-- Table structure for table `budgets`
--

CREATE TABLE IF NOT EXISTS `budgets` (
  `budget_id` int(11) NOT NULL auto_increment,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `credit` float NOT NULL default '0',
  `total` float NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  `purpose` text NOT NULL,
  PRIMARY KEY  (`budget_id`),
  UNIQUE KEY `money_id` (`budget_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1014 ;

--
-- Dumping data for table `budgets`
--

INSERT INTO `budgets` (`budget_id`, `time`, `credit`, `total`, `group_id`, `purpose`) VALUES
(927, '2009-04-22 14:39:14', -2250, 0, 45, 'Transfer to group NSF: Bionic Prosthesis Phase I'),
(926, '2009-04-22 14:38:10', 4450, 4500, 49, 'Transfer from group DARPA: Regenerated Tissues'),
(925, '2009-04-22 14:38:10', -4450, 0, 46, 'Transfer to group MIT: Regenerated Tissues'),
(924, '2009-04-22 14:35:57', 3950, 4450, 46, 'Transfer from group Congress: Regenerative Tissue Research'),
(923, '2009-04-22 14:35:57', -3950, 2250, 45, 'Transfer to group DARPA: Regenerative Tissue Research'),
(922, '2009-04-22 14:35:13', 450, 2850, 54, 'Risk Reduction: Osteoconductive Materials for MIT'),
(921, '2009-04-22 14:35:13', -450, 50, 49, 'Risk Reduction: Osteoconductive Materials by WWIC'),
(920, '2009-04-22 14:35:13', -3000, 500, 49, 'Research: Osteoconductive Materials'),
(919, '2009-04-22 14:34:46', 450, 2400, 54, 'Risk Reduction: Nano-Scaffolds for Rice'),
(918, '2009-04-22 14:34:46', -450, 500, 50, 'Risk Reduction: Nano-Scaffolds by WWIC'),
(917, '2009-04-22 14:34:46', -3000, 950, 50, 'Research: Nano-Scaffolds'),
(916, '2009-04-22 14:34:07', 5000, 6200, 45, 'Adjustment by TA.'),
(915, '2009-04-22 14:33:28', 450, 1950, 54, 'Risk Reduction: Energy Independent Devices for NASA'),
(914, '2009-04-22 14:33:28', -450, 200, 48, 'Risk Reduction: Energy Independent Devices by WWIC'),
(913, '2009-04-22 14:33:28', -5000, 650, 48, 'Research: Energy Independent Devices'),
(912, '2009-04-22 14:33:18', 3500, 3500, 49, 'Transfer from group DARPA: '),
(911, '2009-04-22 14:33:18', -3500, 500, 46, 'Transfer to group MIT: '),
(910, '2009-04-22 14:32:37', 0, 0, 51, 'IBM gave Wearable Computers to NASA.'),
(909, '2009-04-22 14:32:37', 0, 5650, 48, 'IBM gave Wearable Computers to NASA.'),
(908, '2009-04-22 14:32:12', 0, 3950, 50, 'Rice gave Hierarchical Self-Assembly to MIT.'),
(907, '2009-04-22 14:32:12', 0, 0, 49, 'Rice gave Hierarchical Self-Assembly to MIT.'),
(906, '2009-04-22 14:31:32', 0, 0, 49, 'MIT gave Graphene Transistors to Rice.'),
(905, '2009-04-22 14:31:32', 0, 3950, 50, 'MIT gave Graphene Transistors to Rice.'),
(904, '2009-04-22 14:31:23', 3450, 3950, 50, 'Transfer from group NSF: Nanoscaffolds'),
(903, '2009-04-22 14:31:23', -3450, 0, 47, 'Transfer to group Rice: Nanoscaffolds'),
(902, '2009-04-22 14:30:38', 0, 0, 51, 'IBM gave Graphene Transistors to NASA.'),
(901, '2009-04-22 14:30:38', 0, 5650, 48, 'IBM gave Graphene Transistors to NASA.'),
(900, '2009-04-22 14:30:23', 3450, 3450, 47, 'Transfer from group Congress: Nanoscaffolds'),
(899, '2009-04-22 14:30:23', -3450, 1200, 45, 'Transfer to group NSF: Nanoscaffolds'),
(898, '2009-04-22 14:29:27', 0, 0, 51, 'IBM gave Graphene Transistors to MIT.'),
(897, '2009-04-22 14:29:27', 0, 0, 49, 'IBM gave Graphene Transistors to MIT.'),
(896, '2009-04-22 14:29:06', 0, 5650, 48, 'NASA gave Portable Photovoltaic to IBM.'),
(895, '2009-04-22 14:29:06', 0, 0, 51, 'NASA gave Portable Photovoltaic to IBM.'),
(894, '2009-04-22 14:27:36', 4000, 4000, 46, 'Transfer from group Congress: Funding Spree'),
(893, '2009-04-22 14:27:36', -4000, 4650, 45, 'Transfer to group DARPA: Funding Spree'),
(892, '2009-04-22 14:24:28', 450, 1500, 54, 'Risk Reduction: Wearable Computers for IBM'),
(891, '2009-04-22 14:24:28', -450, 0, 51, 'Risk Reduction: Wearable Computers by WWIC'),
(890, '2009-04-22 14:24:28', -4000, 450, 51, 'Research: Wearable Computers'),
(889, '2009-04-22 14:23:01', 3000, 4900, 52, 'Newkirk Venture Capital '),
(888, '2009-04-22 14:22:10', 5000, 5650, 48, 'Transfer from group Congress: Energy Indepedent Dev'),
(886, '2009-04-22 14:21:08', 10000, 13650, 45, 'Adjustment by TA.'),
(887, '2009-04-22 14:22:10', -5000, 8650, 45, 'Transfer to group NASA: Energy Indepedent Dev'),
(885, '2009-04-22 14:20:56', 450, 650, 48, 'Transfer from group WWIC: Refund'),
(884, '2009-04-22 14:20:56', -450, 1050, 54, 'Transfer to group NASA: Refund'),
(883, '2009-04-22 14:20:10', 2850, 4450, 51, 'Transfer from group Congress: Wearable Coms'),
(882, '2009-04-22 14:20:10', -2850, 3650, 45, 'Transfer to group IBM: Wearable Coms'),
(881, '2009-04-22 14:15:17', 350, 1500, 54, 'Risk Reduction: Graphene Transistors for IBM'),
(880, '2009-04-22 14:15:17', -350, 1600, 51, 'Risk Reduction: Graphene Transistors by WWIC'),
(879, '2009-04-22 14:15:17', -3000, 1950, 51, 'Research: Graphene Transistors'),
(878, '2009-04-22 14:14:59', 0, 500, 50, 'Rice gave Hybrid Devices to MIT.'),
(877, '2009-04-22 14:14:59', 0, 0, 49, 'Rice gave Hybrid Devices to MIT.'),
(876, '2009-04-22 14:14:42', 0, 0, 49, 'MIT gave Nanowire Assembly to Rice.'),
(875, '2009-04-22 14:14:42', 0, 500, 50, 'MIT gave Nanowire Assembly to Rice.'),
(874, '2009-04-22 14:13:14', 450, 1150, 54, 'Risk Reduction: Portable Photovoltaic for NASA'),
(873, '2009-04-22 14:13:14', -450, 200, 48, 'Risk Reduction: Portable Photovoltaic by WWIC'),
(872, '2009-04-22 14:13:14', -4000, 650, 48, 'Research: Portable Photovoltaic'),
(871, '2009-04-22 14:12:20', 0, 4950, 51, 'IBM gave Templated Self-Assembly to NASA.'),
(870, '2009-04-22 14:12:20', 0, 4650, 48, 'IBM gave Templated Self-Assembly to NASA.'),
(869, '2009-04-22 14:11:41', 0, 4950, 51, 'IBM gave Hybrid Devices to Rice.'),
(868, '2009-04-22 14:11:41', 0, 500, 50, 'IBM gave Hybrid Devices to Rice.'),
(867, '2009-04-22 14:11:05', 0, 500, 50, 'Rice gave Templated Self-Assembly to IBM.'),
(866, '2009-04-22 14:11:05', 0, 4950, 51, 'Rice gave Templated Self-Assembly to IBM.'),
(865, '2009-04-22 14:10:49', 5000, 6500, 45, 'Adjustment by TA.'),
(864, '2009-04-22 14:09:03', 0, 4950, 51, 'IBM gave Nanowire Assembly to NASA.'),
(863, '2009-04-22 14:09:03', 0, 4650, 48, 'IBM gave Nanowire Assembly to NASA.'),
(862, '2009-04-22 14:06:24', 0, 0, 49, 'MIT gave Nanowire Assembly to IBM.'),
(861, '2009-04-22 14:06:23', 0, 4950, 51, 'MIT gave Nanowire Assembly to IBM.'),
(860, '2009-04-22 13:58:51', 0, 1900, 52, 'PI gave Gradient Lithography to MIT.'),
(859, '2009-04-22 13:58:51', 0, 0, 49, 'PI gave Gradient Lithography to MIT.'),
(858, '2009-04-20 14:33:32', 450, 700, 54, 'Risk Reduction: Templated Self-Assembly for Rice'),
(857, '2009-04-20 14:33:31', -450, 500, 50, 'Risk Reduction: Templated Self-Assembly by WWIC'),
(856, '2009-04-20 14:33:31', -2000, 950, 50, 'Research: Templated Self-Assembly'),
(855, '2009-04-20 14:31:21', 250, 250, 54, 'Risk Reduction: Gradient Lithography for PI'),
(854, '2009-04-20 14:31:21', -250, 1900, 52, 'Risk Reduction: Gradient Lithography by WWIC'),
(853, '2009-04-20 14:31:21', -2000, 2150, 52, 'Research: Gradient Lithography'),
(852, '2009-04-20 14:26:57', 0, 4950, 51, 'Transfer to group Congress: '),
(851, '2009-04-20 14:26:45', 2350, 2950, 50, 'Transfer from group NSF: Templated Self-Assembly research and risk reduction'),
(850, '2009-04-20 14:26:45', -2350, 0, 47, 'Transfer to group Rice: Templated Self-Assembly research and risk reduction'),
(849, '2009-04-20 14:24:07', 2000, 2350, 47, 'Transfer from group Congress: Templated Self-Assembly'),
(848, '2009-04-20 14:24:07', -2000, 1500, 45, 'Transfer to group NSF: Templated Self-Assembly'),
(847, '2009-04-20 14:20:35', 2500, 4150, 52, 'Newkirk Venture Capital - MIT and PI joint venture'),
(846, '2009-04-20 14:07:56', -5000, 0, 54, 'Purchase Certificate: Excellent Risk Mitigation'),
(845, '2009-04-20 14:04:32', 1450, 5000, 54, 'Transfer from group PI: Risk Management'),
(844, '2009-04-20 14:04:32', -1450, 1650, 52, 'Transfer to group WWIC: Risk Management'),
(843, '2009-04-20 13:56:16', 3500, 3500, 45, 'Adjustment by TA.'),
(842, '2009-04-15 15:07:05', -250, 3100, 52, 'Patent: '),
(841, '2009-04-15 15:03:41', 350, 3550, 54, 'Risk Reduction: Graphene Transistors for IBM'),
(840, '2009-04-15 15:03:40', -350, 4950, 51, 'Risk Reduction: Graphene Transistors by WWIC'),
(839, '2009-04-15 15:03:40', -3000, 5300, 51, 'Research: Graphene Transistors'),
(838, '2009-04-15 15:02:42', 950, 3200, 54, 'From Congress'),
(837, '2009-04-15 15:02:04', 950, 2250, 54, 'From Congress'),
(836, '2009-04-15 15:01:44', 4450, 8300, 51, 'Transfer from group NSF: Wearable Computers research and risk management'),
(835, '2009-04-15 15:01:44', -4450, 350, 47, 'Transfer to group IBM: Wearable Computers research and risk management'),
(834, '2009-04-15 15:01:08', 4450, 4650, 48, 'Transfer from group NSF: Portable Photovoltaic research and risk management'),
(833, '2009-04-15 15:01:08', -4450, 4800, 47, 'Transfer to group NASA: Portable Photovoltaic research and risk management'),
(832, '2009-04-15 15:00:34', 0, 3350, 52, 'PI gave Hierarchical Self-Assembly to Rice.'),
(831, '2009-04-15 15:00:34', 0, 600, 50, 'PI gave Hierarchical Self-Assembly to Rice.'),
(830, '2009-04-15 14:59:47', 3850, 3850, 51, 'Transfer from group DARPA: research, risk, and 2 patents'),
(829, '2009-04-15 14:59:47', -3850, 0, 46, 'Transfer to group IBM: research, risk, and 2 patents'),
(828, '2009-04-15 14:59:03', 500, 3850, 46, 'Transfer from group Congress: Stimulus Package (EID)'),
(827, '2009-04-15 14:59:03', -500, 950, 45, 'Transfer to group DARPA: Stimulus Package (EID)'),
(826, '2009-04-15 14:58:52', 7950, 9250, 47, 'Transfer from group Congress: Stimulus Package (EID)'),
(825, '2009-04-15 14:58:52', -7950, 1450, 45, 'Transfer to group NSF: Stimulus Package (EID)'),
(824, '2009-04-15 14:48:09', 350, 1300, 54, 'Risk Reduction: Hierarchical Self-Assembly for PI'),
(823, '2009-04-15 14:48:09', -350, 3350, 52, 'Risk Reduction: Hierarchical Self-Assembly by WWIC'),
(822, '2009-04-15 14:48:09', -2000, 3700, 52, 'Research: Hierarchical Self-Assembly'),
(821, '2009-04-15 14:43:47', 0, 0, 51, 'Transfer from group MIT: '),
(820, '2009-04-15 14:43:47', 0, 0, 49, 'Transfer to group IBM: '),
(819, '2009-04-15 14:43:35', 0, 3350, 46, 'Transfer from group MIT: '),
(818, '2009-04-15 14:43:35', 0, 0, 49, 'Transfer to group DARPA: '),
(817, '2009-04-15 14:43:26', 0, 200, 48, 'Transfer from group MIT: '),
(816, '2009-04-15 14:43:25', 0, 0, 49, 'Transfer to group NASA: '),
(815, '2009-04-15 14:41:34', 4500, 5700, 52, 'Adjustment by TA.'),
(814, '2009-04-15 14:41:34', 0, 0, 51, 'IBM gave Hybrid Devices to NASA.'),
(813, '2009-04-15 14:41:33', 0, 200, 48, 'IBM gave Hybrid Devices to NASA.'),
(812, '2009-04-15 14:41:23', 0, 200, 48, 'NASA gave Assembled Quantum Dots to IBM.'),
(811, '2009-04-15 14:41:23', 0, 0, 51, 'NASA gave Assembled Quantum Dots to IBM.'),
(810, '2009-04-15 14:39:31', 3350, 3350, 46, 'Transfer from group Congress: '),
(809, '2009-04-15 14:39:31', -3350, 9400, 45, 'Transfer to group DARPA: '),
(808, '2009-04-15 14:35:31', 12000, 12750, 45, 'Stimulus Package'),
(807, '2009-04-15 14:24:38', 350, 950, 54, 'Risk Reduction: Assembled Quantum Dots for IBM'),
(806, '2009-04-15 14:24:38', -350, 0, 51, 'Risk Reduction: Assembled Quantum Dots by WWIC'),
(805, '2009-04-15 14:24:38', -3000, 350, 51, 'Research: Assembled Quantum Dots'),
(804, '2009-04-15 14:21:58', 2750, 3350, 51, 'Transfer from group NSF: hybrid devices research and risk management'),
(803, '2009-04-15 14:21:58', -2750, 1300, 47, 'Transfer to group IBM: hybrid devices research and risk management'),
(802, '2009-04-15 14:18:23', 250, 600, 54, 'Risk Reduction: Nanowire Assembly for MIT'),
(801, '2009-04-15 14:18:23', -250, 0, 49, 'Risk Reduction: Nanowire Assembly by WWIC'),
(800, '2009-04-15 14:18:23', -2000, 250, 49, 'Research: Nanowire Assembly'),
(799, '2009-04-15 14:17:00', 2250, 2250, 49, 'Transfer from group DARPA: you need the monies'),
(798, '2009-04-15 14:17:00', -2250, 0, 46, 'Transfer to group MIT: you need the monies'),
(797, '2009-04-15 14:16:35', 1300, 2250, 46, 'Transfer from group Congress: '),
(796, '2009-04-15 14:16:35', -1300, 750, 45, 'Transfer to group DARPA: '),
(795, '2009-04-15 14:14:56', 3950, 4050, 47, 'Transfer from group Congress: '),
(794, '2009-04-15 14:14:56', -3950, 2050, 45, 'Transfer to group NSF: '),
(793, '2009-04-15 13:52:26', 5000, 6000, 45, 'Adjustment by TA.'),
(792, '2009-04-13 15:11:37', 0, 600, 50, 'Rice gave Electron Microscopy to PI.'),
(791, '2009-04-13 15:11:37', 0, 1200, 52, 'Rice gave Electron Microscopy to PI.'),
(790, '2009-04-13 15:10:45', 0, 600, 50, 'Rice gave Ion Etching to PI.'),
(789, '2009-04-13 15:10:45', 0, 1200, 52, 'Rice gave Ion Etching to PI.'),
(788, '2009-04-13 15:05:04', 0, 600, 51, 'IBM gave Block Co-polymer Lithography to NASA.'),
(787, '2009-04-13 15:05:04', 0, 200, 48, 'IBM gave Block Co-polymer Lithography to NASA.'),
(786, '2009-04-13 15:03:50', 0, 600, 50, 'Rice gave Scanning Probe Microscopy to MIT.'),
(785, '2009-04-13 15:03:50', 0, 0, 49, 'Rice gave Scanning Probe Microscopy to MIT.'),
(784, '2009-04-13 15:03:50', 0, 0, 49, 'MIT gave Ion Etching to Rice.'),
(783, '2009-04-13 15:03:50', 0, 600, 50, 'MIT gave Ion Etching to Rice.'),
(782, '2009-04-13 15:03:38', 0, 200, 48, 'NASA gave Lithographic Self-Assembly to IBM.'),
(781, '2009-04-13 15:03:38', 0, 600, 51, 'NASA gave Lithographic Self-Assembly to IBM.'),
(780, '2009-04-13 15:02:18', 350, 600, 51, 'Transfer from group WWIC: Promise to purchase next level of risk mitigation services worth $ 350.  Thanks. '),
(779, '2009-04-13 15:02:18', -350, 350, 54, 'Transfer to group IBM: Promise to purchase next level of risk mitigation services worth $ 350.  Thanks. '),
(778, '2009-04-13 15:00:08', 350, 700, 54, 'Risk Reduction: Assembled Quantum Dots for NASA'),
(777, '2009-04-13 15:00:07', -350, 200, 48, 'Risk Reduction: Assembled Quantum Dots by WWIC'),
(776, '2009-04-13 15:00:06', -3000, 550, 48, 'Research: Assembled Quantum Dots'),
(775, '2009-04-13 14:58:17', -3500, 350, 54, 'Purchase Certificate: Good Risk Mitigation'),
(774, '2009-04-13 14:57:41', 3000, 3850, 54, 'Adjustment by TA.'),
(773, '2009-04-13 14:54:34', 500, 600, 50, 'Transfer from group DARPA: '),
(772, '2009-04-13 14:54:34', -500, 950, 46, 'Transfer to group Rice: '),
(771, '2009-04-13 14:53:59', 0, 0, 55, 'Transfer from group DARPA: '),
(770, '2009-04-13 14:53:59', 0, 1450, 46, 'Transfer to group NanoPost: '),
(769, '2009-04-13 14:52:25', 3250, 3550, 48, 'Transfer from group NSF: research funding and risk management'),
(768, '2009-04-13 14:52:25', -3250, 100, 47, 'Transfer to group NASA: research funding and risk management'),
(767, '2009-04-13 14:52:00', 3250, 3350, 47, 'Transfer from group Congress: Clerical Error'),
(766, '2009-04-13 14:52:00', -3250, 1000, 45, 'Transfer to group NSF: Clerical Error'),
(765, '2009-04-13 14:51:12', 3250, 4250, 45, 'Transfer from group NSF: research funding and risk management'),
(764, '2009-04-13 14:51:12', -3250, 100, 47, 'Transfer to group Congress: research funding and risk management'),
(763, '2009-04-13 14:50:33', 550, 3350, 47, 'Transfer from group IBM: Sending money back'),
(762, '2009-04-13 14:50:33', -550, 250, 51, 'Transfer to group NSF: Sending money back'),
(761, '2009-04-13 14:46:16', 250, 850, 54, 'Risk Reduction: Block Co-polymer Lithography for IBM'),
(760, '2009-04-13 14:46:16', -250, 800, 51, 'Risk Reduction: Block Co-polymer Lithography by WWIC'),
(759, '2009-04-13 14:46:16', -2000, 1050, 51, 'Research: Block Co-polymer Lithography'),
(758, '2009-04-13 14:46:16', 600, 3050, 51, 'Transfer from group NSF: Risk management'),
(757, '2009-04-13 14:46:16', -600, 2800, 47, 'Transfer to group IBM: Risk management'),
(756, '2009-04-13 14:45:57', 600, 600, 54, 'Transfer from group IBM: Risk Reduction'),
(755, '2009-04-13 14:45:57', -600, 2450, 51, 'Transfer to group WWIC: Risk Reduction'),
(754, '2009-04-13 14:44:48', 2250, 3050, 51, 'Transfer from group DARPA: research and risk-assessment'),
(753, '2009-04-13 14:44:48', -2250, 1450, 46, 'Transfer to group IBM: research and risk-assessment'),
(752, '2009-04-13 14:44:35', 0, 1200, 52, 'PI gave Scanning Probe Microscopy to Rice.'),
(751, '2009-04-13 14:44:35', 0, 100, 50, 'PI gave Scanning Probe Microscopy to Rice.'),
(750, '2009-04-13 14:44:25', 1000, 1200, 52, 'Newkirk Venture Capital - Patent Acquisition'),
(749, '2009-04-13 14:43:40', 600, 800, 51, 'Transfer from group NSF: Risk management'),
(748, '2009-04-13 14:43:40', -600, 3400, 47, 'Transfer to group IBM: Risk management'),
(747, '2009-04-13 14:42:56', 4000, 4000, 47, 'Transfer from group Congress: '),
(746, '2009-04-13 14:42:56', -4000, 1000, 45, 'Transfer to group NSF: '),
(745, '2009-04-13 14:39:55', 2250, 3700, 46, 'Transfer from group Congress: '),
(744, '2009-04-13 14:39:55', -2250, 5000, 45, 'Transfer to group DARPA: '),
(743, '2009-04-13 14:37:38', 2250, 7250, 45, 'Adjustment by TA.'),
(742, '2009-04-13 14:35:30', -250, 200, 52, 'Patent: '),
(741, '2009-04-13 14:25:42', -2500, 0, 54, 'Purchase Certificate: Moderate Risk Mitigation'),
(740, '2009-04-13 14:23:46', 150, 2500, 54, 'Risk Reduction: Scanning Probe Microscopy for PI'),
(739, '2009-04-13 14:23:46', -150, 450, 52, 'Risk Reduction: Scanning Probe Microscopy by WWIC'),
(738, '2009-04-13 14:23:46', -1000, 600, 52, 'Research: Scanning Probe Microscopy'),
(737, '2009-04-13 14:17:49', 1500, 1600, 52, 'Newkirk Venture Capital'),
(736, '2009-04-13 14:11:57', 1000, 2350, 54, 'Adjustment by TA.'),
(735, '2009-04-13 14:11:48', 150, 1350, 54, 'Risk Reduction: Lithographic Self-Assembly for NASA'),
(734, '2009-04-13 14:11:48', -150, 300, 48, 'Risk Reduction: Lithographic Self-Assembly by WWIC'),
(733, '2009-04-13 14:11:48', -2000, 450, 48, 'Research: Lithographic Self-Assembly'),
(732, '2009-04-13 13:58:20', 4250, 5000, 45, 'Adjustment by TA.'),
(731, '2009-04-08 15:16:01', 2000, 2450, 48, 'Transfer from group NSF: Cooperative Research and Risk Management'),
(730, '2009-04-08 15:16:01', -2000, 0, 47, 'Transfer to group NASA: Cooperative Research and Risk Management'),
(729, '2009-04-08 15:10:13', 0, 450, 48, 'NASA gave Scanning Probe Microscopy to IBM.'),
(728, '2009-04-08 15:10:13', 0, 200, 51, 'NASA gave Scanning Probe Microscopy to IBM.'),
(727, '2009-04-08 15:10:04', 0, 200, 51, 'IBM gave Quantum Dots to NASA.'),
(726, '2009-04-08 15:10:04', 0, 450, 48, 'IBM gave Quantum Dots to NASA.'),
(725, '2009-04-08 15:09:54', 150, 1200, 54, 'Risk Reduction: Ion Etching for MIT'),
(724, '2009-04-08 15:09:54', -150, 0, 49, 'Risk Reduction: Ion Etching by WWIC'),
(723, '2009-04-08 15:09:54', -1000, 150, 49, 'Research: Ion Etching'),
(722, '2009-04-08 15:09:31', 50, 1150, 49, 'Transfer from group DARPA: risk/patent'),
(721, '2009-04-08 15:09:31', -50, 1450, 46, 'Transfer to group MIT: risk/patent'),
(720, '2009-04-08 15:09:08', 150, 1050, 54, 'Transfer from group IBM: Risk Mitigation Services'),
(719, '2009-04-08 15:09:08', -150, 200, 51, 'Transfer to group WWIC: Risk Mitigation Services'),
(718, '2009-04-08 15:08:25', 1500, 1500, 46, 'Transfer from group Congress: Ion-etch/Nanoassembly'),
(717, '2009-04-08 15:08:25', -1500, 750, 45, 'Transfer to group DARPA: Ion-etch/Nanoassembly'),
(716, '2009-04-08 15:06:54', 750, 900, 54, 'Transfer from group Congress: '),
(715, '2009-04-08 15:06:54', -750, 2250, 45, 'Transfer to group WWIC: '),
(714, '2009-04-08 15:01:46', 1998, 2000, 47, 'Transfer from group Congress: NSF,neurosurgery/energy'),
(713, '2009-04-08 15:01:46', -1998, 3000, 45, 'Transfer to group NSF: NSF,neurosurgery/energy'),
(712, '2009-04-08 15:01:25', -2, 4998, 45, 'Transfer to group NSF: NSF, neurosurgery/energy'),
(711, '2009-04-08 14:57:06', 3000, 5000, 45, 'Adjustment by TA.'),
(710, '2009-04-08 14:45:11', -1000, 350, 51, 'Research: Quantum Dots'),
(709, '2009-04-08 14:44:28', 0, 450, 48, 'NASA gave Optical Lithography to IBM.'),
(708, '2009-04-08 14:44:28', 0, 1350, 51, 'NASA gave Optical Lithography to IBM.'),
(707, '2009-04-08 14:40:56', 150, 150, 54, 'Risk Reduction: Scanning Probe Microscopy for NASA'),
(706, '2009-04-08 14:40:56', -150, 450, 48, 'Risk Reduction: Scanning Probe Microscopy by WWIC'),
(705, '2009-04-08 14:40:56', -1000, 600, 48, 'Research: Scanning Probe Microscopy'),
(704, '2009-04-08 14:35:43', -250, 1100, 49, 'Patent: '),
(703, '2009-04-08 14:31:48', 1500, 1600, 48, 'Transfer from group NSF: Research Grant'),
(702, '2009-04-08 14:31:48', -1500, 0, 47, 'Transfer to group NASA: Research Grant'),
(701, '2009-04-08 14:25:14', 1250, 1350, 51, 'Transfer from group DARPA: Research and Patents'),
(700, '2009-04-08 14:25:14', -1250, 0, 46, 'Transfer to group IBM: Research and Patents'),
(699, '2009-04-08 14:24:43', 1250, 1350, 49, 'Transfer from group DARPA: Research and Patents'),
(698, '2009-04-08 14:24:43', -1250, 1250, 46, 'Transfer to group MIT: Research and Patents'),
(697, '2009-04-06 15:08:27', 1000, 2500, 46, 'Transfer from group Congress: Defense Research'),
(696, '2009-04-06 15:08:27', -1000, 2000, 45, 'Transfer to group DARPA: Defense Research'),
(695, '2009-04-06 15:02:36', -1000, 100, 48, 'Research: Optical Lithography'),
(694, '2009-04-06 15:01:40', -1000, 100, 49, 'Research: Chemical Vapor Deposition'),
(693, '2009-04-06 14:58:32', 1000, 1100, 48, 'Adjustment by TA.'),
(692, '2009-04-06 14:57:35', -1000, 100, 48, 'Research: Chemical Vapor Deposition'),
(691, '2009-04-06 14:56:21', -1000, 100, 51, 'Research: Polymers'),
(690, '2009-04-06 14:55:41', -1000, 100, 50, 'Research: Electron Microscopy'),
(689, '2009-04-06 14:36:30', 2500, 0, 54, 'Adjustment by TA - purchase error'),
(688, '2009-04-06 14:32:15', -1000, 100, 52, 'Research: Polymers'),
(687, '2009-04-06 14:16:09', -2500, -2500, 54, 'Purchase Certificate: Moderate Risk Mitigation'),
(686, '2009-04-06 13:50:35', 1100, 1100, 52, 'Adjustment by TA.'),
(685, '2009-04-06 13:50:32', 1100, 1100, 51, 'Adjustment by TA.'),
(684, '2009-04-06 13:50:28', 1100, 1100, 50, 'Adjustment by TA.'),
(683, '2009-04-06 13:50:25', 1100, 1100, 49, 'Adjustment by TA.'),
(682, '2009-04-06 13:50:22', 1100, 1100, 48, 'Adjustment by TA.'),
(681, '2009-04-06 13:50:17', 1500, 1500, 47, 'Adjustment by TA.'),
(680, '2009-04-06 13:50:13', 1500, 1500, 46, 'Adjustment by TA.'),
(679, '2009-04-06 13:49:53', 3000, 3000, 45, 'Adjustment by TA.'),
(928, '2009-04-22 14:39:14', 2250, 2250, 47, 'Transfer from group Congress: Bionic Prosthesis Phase I'),
(929, '2009-04-22 14:39:46', 5000, 5000, 45, 'Adjustment by TA.'),
(930, '2009-04-22 14:40:04', -450, 2400, 54, 'Transfer to group NASA: Your Money'),
(931, '2009-04-22 14:40:04', 450, 650, 48, 'Transfer from group WWIC: Your Money'),
(932, '2009-04-22 14:41:05', -250, 4650, 52, 'Patent: '),
(933, '2009-04-22 14:42:02', -3300, 1700, 45, 'Transfer to group NSF: Bionic Prosthesis Phase II'),
(934, '2009-04-22 14:42:03', 3300, 5550, 47, 'Transfer from group Congress: Bionic Prosthesis Phase II'),
(935, '2009-04-22 14:43:40', -5550, 0, 47, 'Transfer to group IBM: Bionic Prosthesis funding'),
(936, '2009-04-22 14:43:40', 5550, 5550, 51, 'Transfer from group NSF: Bionic Prosthesis funding'),
(937, '2009-04-22 14:44:31', 0, 5550, 51, 'NASA gave Energy Independent Devices to IBM.'),
(938, '2009-04-22 14:44:31', 0, 650, 48, 'NASA gave Energy Independent Devices to IBM.'),
(939, '2009-04-22 14:44:45', 0, 4500, 49, 'Rice gave Nano-Scaffolds to MIT.'),
(940, '2009-04-22 14:44:45', 0, 500, 50, 'Rice gave Nano-Scaffolds to MIT.'),
(941, '2009-04-22 14:45:39', -4000, 500, 49, 'Research: Regenerated Tissue'),
(942, '2009-04-22 14:45:39', -450, 50, 49, 'Risk Reduction: Regenerated Tissue by WWIC'),
(943, '2009-04-22 14:45:39', 450, 2850, 54, 'Risk Reduction: Regenerated Tissue for MIT'),
(944, '2009-04-22 14:46:22', 0, 500, 50, 'MIT gave Osteoconductive Materials to Rice.'),
(945, '2009-04-22 14:46:22', 0, 50, 49, 'MIT gave Osteoconductive Materials to Rice.'),
(946, '2009-04-22 14:50:57', 0, 4650, 52, 'Rice gave Hybrid Devices to PI.'),
(947, '2009-04-22 14:50:57', 0, 500, 50, 'Rice gave Hybrid Devices to PI.'),
(948, '2009-04-22 14:51:24', 0, 4650, 52, 'Rice gave Graphene Transistors to PI.'),
(949, '2009-04-22 14:51:24', 0, 500, 50, 'Rice gave Graphene Transistors to PI.'),
(950, '2009-04-22 14:52:01', -500, 1200, 45, 'Transfer to group IBM: Risk Litigation'),
(951, '2009-04-22 14:52:01', 500, 6050, 51, 'Transfer from group Congress: Risk Litigation'),
(952, '2009-04-22 14:52:36', 5000, 6200, 45, 'Adjustment by TA.'),
(953, '2009-04-22 14:53:19', 0, 6050, 51, 'MIT gave Regenerated Tissue to IBM.'),
(954, '2009-04-22 14:53:19', 0, 50, 49, 'MIT gave Regenerated Tissue to IBM.'),
(955, '2009-04-22 14:53:28', -4000, 650, 52, 'Research: Wearable Computers'),
(956, '2009-04-22 14:53:28', -350, 300, 52, 'Risk Reduction: Wearable Computers by WWIC'),
(957, '2009-04-22 14:53:28', 350, 3200, 54, 'Risk Reduction: Wearable Computers for PI'),
(958, '2009-04-22 14:53:47', 0, 500, 50, 'MIT gave Regenerated Tissue to Rice.'),
(959, '2009-04-22 14:53:47', 0, 50, 49, 'MIT gave Regenerated Tissue to Rice.'),
(960, '2009-04-22 14:54:24', -5000, 1050, 51, 'Research: Bionic Prosthesis'),
(961, '2009-04-22 14:54:24', -450, 600, 51, 'Risk Reduction: Bionic Prosthesis by WWIC'),
(962, '2009-04-22 14:54:24', 450, 3650, 54, 'Risk Reduction: Bionic Prosthesis for IBM'),
(963, '2009-04-22 14:56:20', -5, 6195, 45, 'Transfer to group NanoPost: you guys rule'),
(964, '2009-04-22 14:56:20', 5, 5, 55, 'Transfer from group Congress: you guys rule'),
(965, '2009-04-22 14:56:31', -500, 5695, 45, 'Transfer to group MIT: Risk Mitigation'),
(966, '2009-04-22 14:56:31', 500, 550, 49, 'Transfer from group Congress: Risk Mitigation'),
(967, '2009-04-22 14:56:33', -5.25, 5689.75, 45, 'Transfer to group WWIC: you are the best'),
(968, '2009-04-22 14:56:33', 5.25, 3655.25, 54, 'Transfer from group Congress: you are the best'),
(969, '2009-04-22 14:57:10', 0, 500, 50, 'PI gave Energy Independent Devices to Rice.'),
(970, '2009-04-22 14:57:10', 0, 300, 52, 'PI gave Energy Independent Devices to Rice.'),
(971, '2009-04-22 14:59:11', -500, 100, 51, 'Transfer to group WWIC: To help make co-block polymers safer'),
(972, '2009-04-22 14:59:11', 500, 4155.25, 54, 'Transfer from group IBM: To help make co-block polymers safer'),
(973, '2009-04-22 15:01:26', 0, 500, 50, 'PI gave Wearable Computers to Rice.'),
(974, '2009-04-22 15:01:26', 0, 300, 52, 'PI gave Wearable Computers to Rice.'),
(975, '2009-04-22 15:01:43', 5250, 5550, 52, 'Adjustment by TA.'),
(976, '2009-04-22 15:03:12', 0, 50, 49, 'IBM gave Bionic Prosthesis to MIT.'),
(977, '2009-04-22 15:03:12', 0, 100, 51, 'IBM gave Bionic Prosthesis to MIT.'),
(978, '2009-04-22 15:03:55', -1000, 4689.75, 45, 'Transfer to group ETC: You guys are the best'),
(979, '2009-04-22 15:03:55', 1000, 1000, 53, 'Transfer from group Congress: You guys are the best'),
(980, '2009-04-22 15:04:00', 0, 5550, 52, 'Rice gave Regenerated Tissue to PI.'),
(981, '2009-04-22 15:04:00', 0, 500, 50, 'Rice gave Regenerated Tissue to PI.'),
(982, '2009-04-22 15:05:46', -150, 350, 50, 'Transfer to group PI: '),
(983, '2009-04-22 15:05:46', 150, 5700, 52, 'Transfer from group Rice: '),
(984, '2009-04-22 15:06:14', -5000, 700, 52, 'Research: Bionic Prosthesis'),
(985, '2009-04-22 15:06:14', -450, 250, 52, 'Risk Reduction: Bionic Prosthesis by WWIC'),
(986, '2009-04-22 15:06:14', 450, 4605.25, 54, 'Risk Reduction: Bionic Prosthesis for PI'),
(987, '2009-04-22 15:08:37', -0.5, 4.5, 55, 'Transfer to group MIT: Happiness'),
(988, '2009-04-22 15:08:37', 0.5, 50.5, 49, 'Transfer from group NanoPost: Happiness'),
(989, '2009-04-22 15:08:46', -1, 49.5, 49, 'Transfer to group NanoPost: BRIBES!?'),
(990, '2009-04-22 15:08:46', 1, 5.5, 55, 'Transfer from group MIT: BRIBES!?'),
(991, '2009-04-22 15:09:05', -0.5, 5, 55, 'Transfer to group Congress: Thank you'),
(992, '2009-04-22 15:09:05', 0.5, 4690.25, 45, 'Transfer from group NanoPost: Thank you'),
(993, '2009-04-22 15:09:36', -5, 4685.25, 45, 'Transfer to group NanoPost: Lunch money'),
(994, '2009-04-22 15:09:36', 5, 10, 55, 'Transfer from group Congress: Lunch money'),
(995, '2009-04-22 15:11:17', -0.5, 9.5, 55, 'Transfer to group DARPA: '),
(996, '2009-04-22 15:11:17', 0.5, 0.5, 46, 'Transfer from group NanoPost: '),
(997, '2009-04-22 15:11:22', -0.5, 9, 55, 'Transfer to group DARPA: '),
(998, '2009-04-22 15:11:22', 0.5, 1, 46, 'Transfer from group NanoPost: '),
(999, '2009-04-22 15:11:26', -0.5, 8.5, 55, 'Transfer to group DARPA: '),
(1000, '2009-04-22 15:11:26', 0.5, 1.5, 46, 'Transfer from group NanoPost: '),
(1001, '2009-04-22 15:11:29', -0.5, 8, 55, 'Transfer to group DARPA: '),
(1002, '2009-04-22 15:11:29', 0.5, 2, 46, 'Transfer from group NanoPost: '),
(1003, '2009-04-22 15:11:33', -0.5, 7.5, 55, 'Transfer to group DARPA: '),
(1004, '2009-04-22 15:11:33', 0.5, 2.5, 46, 'Transfer from group NanoPost: '),
(1005, '2009-04-22 15:11:47', -0.5, 7, 55, 'Transfer to group DARPA: '),
(1006, '2009-04-22 15:11:47', 0.5, 3, 46, 'Transfer from group NanoPost: '),
(1007, '2009-04-22 15:12:16', -250, 0, 52, 'Patent: '),
(1008, '2009-04-22 15:12:20', -2.5, 4682.75, 45, 'Transfer to group NanoPost: Mediocre Work'),
(1009, '2009-04-22 15:12:20', 2.5, 9.5, 55, 'Transfer from group Congress: Mediocre Work'),
(1010, '2009-04-22 15:13:15', -69, 4613.75, 45, 'Transfer to group NanoPost: sufficient work'),
(1011, '2009-04-22 15:13:15', 69, 78.5, 55, 'Transfer from group Congress: sufficient work'),
(1012, '2009-04-22 15:14:23', -4500, 113.75, 45, 'Transfer to group ETC: Continued Support'),
(1013, '2009-04-22 15:14:23', 4500, 5500, 53, 'Transfer from group Congress: Continued Support');

-- --------------------------------------------------------

--
-- Table structure for table `business`
--

CREATE TABLE IF NOT EXISTS `business` (
  `business_id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL default '0',
  `sent` datetime NOT NULL default '0000-00-00 00:00:00',
  `proposal` longtext NOT NULL,
  `responded` enum('y','n') NOT NULL default 'n',
  `response` longtext NOT NULL,
  PRIMARY KEY  (`business_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `business`
--

INSERT INTO `business` (`business_id`, `group_id`, `sent`, `proposal`, `responded`, `response`) VALUES
(1, 52, '2009-04-13 14:14:30', 'Prometheus Industries and Rice University hereby submit their request for funding to engage in a business partnership to research Scanning Probe Microscopy. Our request for funds breaks down as follows: $1000 for direct research costs $150 for risk mitigation $250 for patent fees $100 for P.I. revenue After the research is completed, P.I. will patent the Scanning Probe Microscopy technology and share it with Rice University. They may then use this to further their own research efforts in further tiers of the tech tree. P.I. may then engage in another business partnership with Rice University or another academic institution. Rice University''s summary: <<<: Project Overview: The researchers at Rice University are paving the way in the realm of new microscope technologies. We have already researched and mastered the use of basic electron microscopy, and wish to advance our knowledge and delve into researching scanning probe microscopy. Scanning Probe Background: Scanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position. Benefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed. Researching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Public greatly. Children born without limbs will hopefully be able to achieve some semblence of normalcy in their lives thanks to our research. Business Relationship: PI will research C&F for Rice University. -Rice Mission Objective:: Electron Microscopy --> hierarchical self-assembly --> nano-scaffolds -->regenerated tissues --> bionic prosthesis polymers --> block co-polymer lithography -->hybrid devices --> wearable computers --> bionic prosthesis As well as spectroscopy and scanning probe microscopy.>>>', 'n', ''),
(2, 52, '2009-04-15 14:33:07', 'Proposal:     \r\nPrometheus Industries and Rice University hereby submit their request for funding to engage in a business partnership to research hierarchical self-assembly.\r\nOur request for funds breaks down as follows:\r\n$2000 for direct research costs\r\n$250 for risk mitigation\r\n$250 for patent fees\r\n$200 for P.I. revenue\r\nTOTAL: $2700\r\nAfter the research is completed, P.I. will patent the hierarchical self-assembly technology and share it with Rice University. They may then use this to further their own research efforts in further tiers of the tech tree. P.I. may then engage in another business partnership with Rice University or another academic institution.\r\n\r\n\r\nBackground by Rice University:\r\n<<<Hierarchical self-assembly, also known as hierarchical self-organization, is non-covalent organization of individual building blocks are formed over distinct and multiple levels. This tool allows for greatly increases the flexibility and adaptability of a material. The whole entire structure typically behaves much different then the individual building blocks and levels.\r\n\r\nWith this technology, we can improve the efficiency and survivability of our bionic prostheses. Nanomachines inside the limbs could administer endorphins, platelets, and medicine as needed.>>>', 'y', 'PI appears to have fallen from the elite in this field.  Consider this a last ditch effort to thrust yourselves back into the spotlight.  If this fails, future funds could be scarce.\r\n\r\nNewkirk Venture Capital'),
(3, 52, '2009-04-15 15:17:28', 'Proposal:\r\nPrometheus Industries and MIT hereby submit their request for funding to engage in a business partnership to research Gradient Lithography.\r\nOur request for funds breaks down as follows:\r\n$2000 for direct research costs\r\n$250 for risk mitigation\r\n$250 for patent fees\r\nTOTAL: $2500\r\nAfter the research is completed, P.I. will patent the gradient lithography technology and share it with MIT. They may then use this to obtain their grand challenge of bionic prosthesis. P.I. may then engage in another business partnership with MIT or another academic institution.\r\n\r\n\r\nBackground by MIT:\r\n 	At MIT, we are working towards bionic prosthesis. Amputees could soon be fitted with prosthetic limbs that enable them to regain their sense of touch thanks to these new devices. For example, a bionic arm is effectively controlled by one''s thoughts, as sensors attached to their chest pick up electrical cues from their rerouted arm nerves. For this, we need the gradient lithography technology to further progress up the technology tree.', 'y', '');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`class_id`),
  UNIQUE KEY `code` (`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Class codes for each year''s simulation';

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`) VALUES
(91);

-- --------------------------------------------------------

--
-- Table structure for table `core_competency`
--

CREATE TABLE IF NOT EXISTS `core_competency` (
  `group_id` int(11) NOT NULL default '0',
  `core_area` int(11) NOT NULL default '0',
  `time_reduction` int(11) NOT NULL default '0',
  PRIMARY KEY  (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `core_competency`
--

INSERT INTO `core_competency` (`group_id`, `core_area`, `time_reduction`) VALUES
(48, 1, -10),
(49, 2, -10),
(50, 3, -10),
(51, 4, -10),
(52, 5, -5);

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE IF NOT EXISTS `facilities` (
  `facility_id` int(11) NOT NULL auto_increment,
  `facility_type_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `purchased` datetime NOT NULL default '0000-00-00 00:00:00',
  `time_left` int(11) NOT NULL default '0',
  `facility_proposal` text NOT NULL,
  `facility_sources` text NOT NULL,
  `failed` enum('y','n') NOT NULL default 'n',
  `failed_message` text NOT NULL,
  `owns_facility` enum('n','y') NOT NULL default 'n',
  PRIMARY KEY  (`facility_id`),
  UNIQUE KEY `facility_id` (`facility_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Holds the facilities owned by different groups.' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`facility_id`, `facility_type_id`, `group_id`, `title`, `purchased`, `time_left`, `facility_proposal`, `facility_sources`, `failed`, `failed_message`, `owns_facility`) VALUES
(2, 2, 33, 'Test Facility', '0000-00-00 00:00:00', 0, 'This is a test.', 'test.com', 'n', '', 'n'),
(4, 4, 33, 'IBM - Armonk Campus', '2006-10-18 13:54:05', 10, 'We have this.', 'http://www-03.ibm.com/ibm/history/history/year_2002.html', 'n', '', 'n'),
(5, 2, 37, 'MIT''s Energy Lab', '0000-00-00 00:00:00', 0, '', '', 'n', '', 'n'),
(6, 1, 38, 'IBM''s Electronics Lab', '0000-00-00 00:00:00', 0, '', '', 'n', '', 'n'),
(8, 4, 48, 'NASA Goddard Composite Plant', '2006-11-06 18:54:19', 0, 'We begin with this facility.', '', 'n', '', 'n'),
(10, 2, 49, 'Institute for Soldier Nanotechnologies', '2006-11-06 19:12:26', 0, 'We begin with this facility.', '', 'n', '', 'n'),
(11, 3, 50, 'Carbon Nanotechnology Laboratory', '2006-11-06 19:14:38', 0, 'We begin with this facility.', '', 'n', '', 'n'),
(12, 1, 51, 'Almaden Research Center', '2006-11-06 19:16:58', 0, 'We begin with this facility.', '', 'n', '', 'n'),
(13, 4, 52, 'The Lab', '2006-11-07 13:04:41', 0, '', '', 'n', '', 'n'),
(14, 2, 51, 'We want it', '2006-11-30 12:56:58', 0, 'We really want to research hydrogen power.', '', 'n', '', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `facility_types`
--

CREATE TABLE IF NOT EXISTS `facility_types` (
  `facility_type_id` int(11) NOT NULL auto_increment,
  `type` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `cost` int(11) NOT NULL default '0',
  `duration` int(11) NOT NULL default '0',
  PRIMARY KEY  (`facility_type_id`),
  UNIQUE KEY `facilities_type_id` (`facility_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Identifies types of facilities groups can purchase.' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `facility_types`
--

INSERT INTO `facility_types` (`facility_type_id`, `type`, `description`, `cost`, `duration`) VALUES
(1, 'Electronics Research Facility', '', 2500, 50),
(2, 'Energy Research Facility', '', 2500, 50),
(3, 'Biomedical Research Facility', '', 2500, 50),
(4, 'Composites Research Facility', '', 2500, 50);

-- --------------------------------------------------------

--
-- Table structure for table `facility_users`
--

CREATE TABLE IF NOT EXISTS `facility_users` (
  `facility_user_id` int(11) NOT NULL auto_increment,
  `facility_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`facility_user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `facility_users`
--

INSERT INTO `facility_users` (`facility_user_id`, `facility_id`, `group_id`) VALUES
(2, 2, 34),
(11, 13, 45),
(12, 14, 54),
(13, 14, 55),
(14, 12, 49);

-- --------------------------------------------------------

--
-- Table structure for table `failure_rates`
--

CREATE TABLE IF NOT EXISTS `failure_rates` (
  `time` int(11) NOT NULL default '0',
  `cost` int(11) NOT NULL default '0',
  `failure_rate` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `failure_rates`
--

INSERT INTO `failure_rates` (`time`, `cost`, `failure_rate`) VALUES
(-10, -500, 175),
(0, -500, 150),
(10, -500, 125),
(-10, 0, 125),
(0, 0, 100),
(10, 0, 75),
(-10, 500, 75),
(0, 500, 50),
(10, 500, 25);

-- --------------------------------------------------------

--
-- Table structure for table `funding`
--

CREATE TABLE IF NOT EXISTS `funding` (
  `funding_id` int(11) NOT NULL auto_increment,
  `to_group` int(11) NOT NULL default '0',
  `from_group` int(11) NOT NULL default '0',
  `title` text NOT NULL,
  `proposal` longtext NOT NULL,
  `response` text NOT NULL,
  `responded` enum('y','n') NOT NULL default 'n',
  `sent` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`funding_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `funding`
--

INSERT INTO `funding` (`funding_id`, `to_group`, `from_group`, `title`, `proposal`, `response`, `responded`, `sent`) VALUES
(1, 46, 52, 'Prometheus Industries Request for Funding #001', 'As a young start-up, we currently have most of our capital invested in research, leaving us with no opportunities to patent our discoveries. We believe our current research into polymers would provide significant advantages to DARPA project. If we cannot secure the rights to our research, other factions may gain control of it. Factions who may not be as willing as we are to aid DARPA. Hear our plea. If our offer is pleasing to you, please send us $3000. This will let us protect and continue our research and ensure that adequate risk mitigation is present.', '', 'n', '2009-04-06 14:39:35'),
(2, 46, 52, 'Funding Proposal #001a', 'We have recently received information above the amount of funding available from DARPA. We would like to lower our request for funding to $300, effective immediately. This will give us enough resources to patent our research and secure our technology for future collaboration. ', '', 'n', '2009-04-06 14:46:38'),
(3, 48, 52, 'Prometheus Industries Funding Proposal #001', 'Prometheus Industries is a humble start-up company that currently invests the majority of its capital in R&D. We have no resources to spare for securing intellectual property rights or risk management.\r\nWe are currently engaged in polymer research that we think has important implications for materials science, which would benefit virtually every area of industry.\r\nWe humbly submit our proposal for $200 in funding. Thank you.', '', 'n', '2009-04-06 14:56:24'),
(4, 45, 52, 'P.I. Funding Proposal #002', 'Prometheus Industries is a humble start-up company that currently invests the majority of its capital in R&D. We have no resources to spare for securing intellectual property rights or risk management.\r\nWe are currently engaged in polymer research that we think has important implications for materials science, which would benefit virtually every area of industry.\r\nWe humbly submit our proposal for $200 in funding. Thank you.', 'We support your initiative and research goals, but at this time we are acting mainly through our funding agencies, NSF and DARPA.  Before Congress engages in earmarked funding, we would like you to go through the proper channels.  \r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-06 14:56:44'),
(5, 49, 52, 'P.I. Funding proposal #004', 'Prometheus Industries is a humble start-up company that currently invests the majority of its capital in R&D. We have no resources to spare for securing intellectual property rights or risk management.\r\nWe are currently engaged in polymer research that we think has important implications for materials science, which would benefit virtually every area of industry.\r\nWe humbly submit our proposal for $200 in funding. Thank you.', '', 'n', '2009-04-06 14:57:01'),
(6, 50, 52, 'P.I. Funding Proposal #005', 'Prometheus Industries is a humble start-up company that currently invests the majority of its capital in R&D. We have no resources to spare for securing intellectual property rights or risk management.\r\nWe are currently engaged in polymer research that we think has important implications for materials science, which would benefit virtually every area of industry.\r\nWe humbly submit our proposal for $200 in funding. Thank you.', 'We will consider your proposal next time...We broke as a joke', 'y', '2009-04-06 14:57:16'),
(7, 51, 52, 'P.I. Funding Proposal #006', 'Prometheus Industries is a humble start-up company that currently invests the majority of its capital in R&D. We have no resources to spare for securing intellectual property rights or risk management.\r\nWe are currently engaged in polymer research that we think has important implications for materials science, which would benefit virtually every area of industry.\r\nWe humbly submit our proposal for $200 in funding. Thank you.', 'Polymer research obviously public now. ', 'y', '2009-04-06 14:57:35'),
(8, 47, 50, 'Electron Microscope', 'There are four types of the electron microscope: the transmission electron microscope (TEM), the scanning electron microscope (SEM), the reflection electron microscope (REM), and the scanning transmission electron microscope (STEM). All four "use a particle beam of electrons to illuminate a specimen and create a highly-magnified image." They have a greater resolving power and can obtain much higher magnifications.\r\n\r\nWe hope to use this to aid us in hierarchical self-assembly research.\r\n\r\nThis technology does not seem to pose and significant risk threat.', 'Please specify the amount requested to have your proposal properly considered for funding.  Please be aware that the NSF is primarily looking for research forwarding the goals of Energy Independent devices, Nanoscale Neurosurgery, and Bionic Prosthesis.', 'y', '2009-04-06 14:57:48'),
(9, 53, 52, 'P.I. Funding Proposal #007', 'Prometheus Industries is a humble start-up company that currently invests the majority of its capital in R&D. We have no resources to spare for securing intellectual property rights or risk management.\r\nWe are currently engaged in polymer research that we think has important implications for materials science, which would benefit virtually every area of industry.\r\nWe humbly submit our proposal for $200 in funding. Thank you.', '', 'n', '2009-04-06 14:57:54'),
(10, 46, 50, 'Electron Microscope', 'There are four types of the electron microscope: the transmission electron microscope (TEM), the scanning electron microscope (SEM), the reflection electron microscope (REM), and the scanning transmission electron microscope (STEM). All four "use a particle beam of electrons to illuminate a specimen and create a highly-magnified image." They have a greater resolving power and can obtain much higher magnifications.\r\n\r\nWe hope to use this to aid us in hierarchical self-assembly research.\r\n\r\nThis technology does not seem to pose and significant risk threat.', '', 'n', '2009-04-06 14:58:06'),
(11, 45, 50, 'Electron Microscope', 'There are four types of the electron microscope: the transmission electron microscope (TEM), the scanning electron microscope (SEM), the reflection electron microscope (REM), and the scanning transmission electron microscope (STEM). All four "use a particle beam of electrons to illuminate a specimen and create a highly-magnified image." They have a greater resolving power and can obtain much higher magnifications.\r\n\r\nWe hope to use this to aid us in hierarchical self-assembly research.\r\n\r\nThis technology does not seem to pose and significant risk threat.', 'Rice,\r\n\r\nWe commend your research. Please send proposals to the NSF/DARPA for funding.\r\n\r\nSincerely,\r\n\r\nCongress', 'y', '2009-04-06 14:58:20'),
(12, 46, 49, 'Taking the first steps towards bionic soldiers', 'Here at MIT we are looking toward the future, with a focus on creating the prosthetics of the future that can be used in both civilian and military situations.  In the short term we are looking at ion etching as one of the first steps towards viable prosthetics.  Ion etching will allow us to create the extremely fine, high quality circuitry, as well as some of the more exacting materials that will be necessary to interface the prosthetics with the body at the most fundamental level.  Additionally, the products we can create with ion etching will allow us to develop materials so specific that we can enhance the quality of our prosthetics to be superior to regular human limbs, giving soldiers who at one time looked to be crippled the ability to return to combat, with an edge.  More than just refined bionic limbs, ion etching will be integral to development of improved neural prosthetic interfaces that will allow soldiers and civilians with prosthetics to directly control their bionic parts with their nervous system, perhaps once again at a superior rate and with superior quality over our current organic components.', '', 'n', '2009-04-06 15:00:28'),
(13, 46, 50, 'Request for $1500', 'We wish to advance our research to eventually produce bionic prostheses for helping wounded soldiers continue to do their duties even after injury.  We would greatly appreciate your financial help', '', 'n', '2009-04-06 15:05:00'),
(14, 47, 52, 'P.I. Funding Request', '$1500 would greatly aid Prometheus Industries in its effort to secure basic technologies that lead to wearable computers--tech. that would be of interest to NSF agents. We have already completed research in polymers, but lack the funds to patent it. If we could patent, we could then progress in research on Chemical Vapor Deposition and Scanning Probe Microscopy.\r\nIf we could secure these, it would put us well on the way to achieving wearable computer technology, and on the path to being halfway to bionic prostheses. \r\n\r\nThank you for your time.', 'The purpose of the NSF is to fund further research, not to fund patent applications.\r\n\r\nThe NSF has currently allocated all of its available funds and is thus unable to assist you further at this time.', 'y', '2009-04-06 15:07:26'),
(15, 47, 50, 'Request for $1000', 'Researchers at Rice University are on the leading edge of advancing the field of reconstructive medical processes.  We request funds so that we can eventually produce advanced prostheses for amputees', 'Proposals should typically mention the specific short term goals that the research funding.\r\n\r\nThe NSF has currently allocated all of its available funds and is thus unable to assist you further at this time.', 'y', '2009-04-06 15:09:37'),
(16, 47, 51, 'Funding for "Energy Independent Devices"', 'Background: IBM is currently in the process of researching polymers with the end goal of energy independent devices in mind.  IBM has significant strengths in the research of polymers but also plans to explore other areas that will lead to the development of energy independent devices.\r\n\r\nObjectives\r\nShort term: To research quantum dots in addition to polymers.  This research will aid IBM in the progress towards energy independent devices.  Along this path, prototypes in hybrid devices and assembled quantum dots will be constructed.  Further, technologies related to wearable computers and portable photovoltaics will be pursued.  These two technologies will set the foundation for the grand challenge of energy independent devices.\r\n\r\nLong term: Energy independent devices, more than any other grand challenge, will help the bulk of the public and also address general energy concerns.\r\n\r\nRisk Analysis: IBM is an experienced research company, with experience in the outlined fields.  With funding, IBM will be able to enlist the aid of the WWIC, so as to downgrade risk.  Further, IBM has already been in contact with the WWIC about future collaboration.', 'Please include amount requested in the proposal', 'y', '2009-04-06 15:11:19'),
(17, 46, 48, 'Request for Funding for Quantum Dot Research', 'NASA is requesting $1500 to further research on quantum dots.\r\n\r\nQuantum dots will directly aid in the development of energy independent devices. We hope that this will be applicable to both NASAs and DARPAs technological goals. ', 'We are trying to secure more money from Congress.  Since you are a National Agency and could aid in national defense, you could aid us in securing more funding.  We would like you to come meet with us and discuss your future plans.', 'y', '2009-04-06 15:11:35'),
(18, 46, 51, 'Funding Toward "Energy Independent Devices"', 'Background: IBM is currently in the process of researching polymers with the end goal of energy independent devices in mind.  IBM has significant strengths in the research of polymers but also plans to explore other areas that will lead to the development of energy independent devices.\r\n\r\nObjectives\r\nShort term: To research quantum dots in addition to polymers.  This research will aid IBM in the progress towards energy independent devices.  Along this path, prototypes in hybrid devices and assembled quantum dots will be constructed.  Further, technologies related to wearable computers and portable photovoltaics will be pursued.  These two technologies will set the foundation for the grand challenge of energy independent devices.\r\n\r\nLong term: Energy independent devices, more than any other grand challenge, will help the bulk of the public and also address general energy concerns.\r\n\r\nRisk Analysis: IBM is an experienced research company, with experience in the outlined fields.  With funding, IBM will be able to enlist the aid of the WWIC, so as to downgrade risk.  Further, IBM has already been in contact with the WWIC about future collaboration.', '', 'n', '2009-04-06 15:11:43'),
(19, 47, 48, 'Request for funding for research on quantum dots', 'NASA is requesting $1500 to further research on quantum dots.\r\n\r\nQuantum dots will directly aid in the development of energy independent devices. We hope that this will be applicable to both NASAs and NSFs technological goals.', 'The NSF is happy to be able to fund NASA in its collaboration in its research goals with IBM.', 'y', '2009-04-06 15:13:41'),
(20, 47, 49, 'Patent Funding for Chemical Vapor Deposition', 'MIT is conducting research to develop new innovative bionic prosthetic developments. With chemical vapor deposition (CVD), we can put a thin, hole-free film on the prosthetic materials, making them more reliable. The film cannot be dissolved by either hydrophobic or hydrophilic materials. Our future objectives with CVD is to understand how the coating will behave in an active biological environment. In addition, the surface of the material will be modified for attachment of bioactive molecules to increase cell attraction for the material surface. This will maximize the integration and stability of the coating within the cellular matrix after implantation. \r\n\r\nThis new technology that MIT is developing has the potential to be used in all sorts of various nano applications, and is integral to the development of higher level nano-technologies, nanowire assembly in particular.  At MIT we believe in securing property rights so that technologies can be developed responsibly and with credit assigned where do.  To this end, we are requesting a small grant of $250 to patent this technology of CVD.', 'The purpose of the NSF is to fund further research, not to fund patent applications.\r\n\r\nThe NSF has currently allocated all of its available funds and is thus unable to assist you further at this time.', 'y', '2009-04-08 14:19:33'),
(21, 45, 50, 'Electron Microscope\r\n', 'Thank you for your interest! Currently, we are having great difficulty receiving money from both NSF and DARPA because they say that are out of money. Our research will be highly beneficial to society in multiple ways. Please do consider allocating more money to NSF and DARPA in order to further our research!', 'We have allocated money to the NSF/DARPA', 'y', '2009-04-08 14:48:07'),
(22, 45, 48, 'Request for funds', 'NASA is requesting funds to further our research and aid in patent application. We are aiming to further research in templated self assembly to aid in research concerning hybrid devices. Eventually this research will lead to development of energy independent devices. Patents will aid us in protecting our research. Continuing our research in a low risk way will continue to improve our risk rating, making us a more efficient government research program. NASA requests $1500 for this endeavor.', 'We have allocated money to the NSF/DARPA. Please contact them for funding.', 'y', '2009-04-08 14:48:16'),
(23, 45, 52, 'P.I. Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', 'PI,\r\n\r\nWe are humbled by our offer of service, although the government does not wish to be the sole proprietor of the properties and technology you develop. Please look into the NSF/DARPA. In future dealings, when talking with the DARPA and NSF, please be more transparent with where the funds are going on how this will impact the public.\r\n\r\nSincerely,\r\n\r\nCongress ', 'y', '2009-04-08 14:48:47'),
(24, 47, 49, 'Request for funding to research imprint lithography.', 'Funding request to research imprint lithography, MIT is devoted to state of the art nano research for academic pursuits. Nanoimprint lithography is one exciting field of research with endless possibilities. A breakthrough in imprint lithography would allow for low cost, high throughput nanometer scale patterning. Such a technique would apply to wide variety of fields including optics, biomedical applications, and electric engineering. We predict that imprint lithography would allow for fabrication of MOSFET, polarizers, and plasmonic devices among other things. Estimated cost to complete and patent research in imprint lithography is $1250. Having such funds to research imprint lithography is imperative to looking towards the future of nanotechnology.', 'The NSF has currently allocated all of its available funds and is thus unable to assist you further at this time.  Once additional funding is available we will reconsider your proposal. \r\n\r\nWhen we have received additional funding please send us a new proposal updating us on your current status and needs.', 'y', '2009-04-08 14:49:15'),
(25, 46, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '', 'n', '2009-04-08 14:49:16'),
(26, 47, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', 'The NSF has currently allocated all of its available funds and is thus unable to assist you further at this time.  Once additional funding is available we will reconsider your proposal. \r\n\r\nWhen we have received additional funding please send us a new proposal updating us on your current status and needs.', 'y', '2009-04-08 14:49:37'),
(27, 45, 54, 'FUNDING PROPOSAL', 'Dear Congressmen/Congresswomen, \r\nWe here at Woodrow Wilson International Center help various organizations with risk mitigation strategies for anything concerned with nanotechnology. Our experts go at any length to ensure that any venture or research on nanotechnology is safe for all of us concerned; especially the public. But so far, we are equipped with only Basic Risk Mitigation expertise. For upgrade, we''ll need a budget of $2500. Could you possibly look into this matter and help us with the funding to keep the American people and the world community safe. \r\nSo far we are looking forward to helping NASA and a variety of other organization.\r\nPlease feel free to contact us for any details. We are open for negotiation for the funds.\r\nSincerely,\r\nWoodrow Wilson International Center\r\n\r\n', 'We appreciate your efforts in identifying and managing risk.  While the $2,500 is too expensive for Congress to supply right now, we have provided what resources we have available.  Hopefully we can continue to work together to keep the public informed and safe.\r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-08 14:49:55'),
(28, 48, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '', 'n', '2009-04-08 14:49:58'),
(29, 47, 50, 'Scanning Probe Microscopy Funding Proposal', 'Project Overview:\r\n  The researchers at Rice University are paving the way in the realm of new microscope technologies. We have already researched and mastered the use of basic electron microscopy, and wish to advance our knowledge and delve into researching scanning probe microscopy.\r\n\r\nScanning Probe Background:\r\n\r\n  Scanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position.\r\n  Benefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed.\r\n  Researching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Public greatly. Children born without limbs will hopefully be able to achieve some semblence of normalcy in their lives thanks to our research.\r\n\r\nNeeded Resources:\r\n  In order to achieve our goals and create a brighter future for America, we need the amount of 1000 United States Dollars to research SPM. It would be greatly appreciated if you could supply our University with funding.\r\n\r\n-Rice', 'The NSF has currently allocated all of its available funds and is thus unable to assist you further at this time.  Once additional funding is available we will reconsider your proposal. \r\n\r\nWhen we have received additional funding please send us a new proposal updating us on your current status and needs.', 'y', '2009-04-08 14:50:04'),
(30, 49, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '', 'n', '2009-04-08 14:50:20'),
(31, 45, 49, 'Request for funding to research imprint lithography.', 'Funding request to fund DARPA for researching imprint lithography, MIT is devoted to state of the art nano research for academic pursuits. Nanoimprint lithography is one exciting field of research with endless possibilities. A breakthrough in imprint lithography would allow for low cost, high throughput nanometer scale patterning. Such a technique would apply to wide variety of fields including optics, biomedical applications, and electric engineering. We predict that imprint lithography would allow for fabrication of MOSFET, polarizers, and plasmonic devices among other things. Estimated cost to complete and patent research in imprint lithography is $1250. Having such funds to research imprint lithography is imperative to looking towards the future of nanotechnology.', 'MIT,\r\n\r\nPlease look through DARPA/NSF for proper funding.\r\n\r\nSincerely,\r\n\r\nCongress', 'y', '2009-04-08 14:50:22'),
(32, 50, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', 'gots no money', 'y', '2009-04-08 14:50:35'),
(33, 45, 47, 'NSF Research Funding', 'To continue our goal of peaceful applications of nanotechnolgy to societal ills, the NSF requests funding from congress. We request $4500 in order to achieve these goals. We are currently funding joint research with IBM and NASA for the end goal of Energy Independent Devices. We are also still recieving research proposals for Nanoscale Neurosurgery and Bionic Prothesis. Each research grant we give, to more forward in the technology tree, needs to be around $1500. In order to continue to fund energy independent device research and also to start research on Nanoscale Neurosurgery we require the sum of $4500 We are available to meet at your convenience.', 'We will fund $2,000 for your energy independent devices, nanoscale surgery and bionic prostheses. We will keep in contact with how well your research is coming and if they agree with this proposal.', 'y', '2009-04-08 14:50:41'),
(34, 51, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', 'No thanks, don''t need any C&F''s as of now.', 'y', '2009-04-08 14:50:50'),
(35, 53, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '', 'n', '2009-04-08 14:51:04'),
(36, 45, 46, 'Funding to further Research at MIT', 'Congress,\r\nWe are in need of more funding to further research at MIT.  They just researched a patent in Chemical Vapor Deposition, and need money to reserach Ion Etching, they can then move on to Gradient Lithography and Nanowire Assembly, and move ever closer to their end goal, bionic prosthesis.  Any funding would be very helpful. The current research costs $1000 per item, and the next level will double that to $2000.  Also, patents cost $250 each, and a bit more to hold the risk factor down is beneficial to them as well as you.  Thank you very much.', 'DARPA,\r\n\r\nWe look forward to your funded oversight of Ion Etching and Gradient Lithography/Nanoassembly. We expect oversight over how well these technologies are being monitored and controlled.\r\n\r\nSincerely,\r\n\r\nCongress', 'y', '2009-04-08 14:51:22'),
(37, 54, 52, 'Prometheus Industries: C&F Experts', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '', 'n', '2009-04-08 14:51:24'),
(38, 46, 50, 'Scanning Probe Microscopy', 'Project Overview:\r\n  The researchers at Rice University are paving the way in the realm of new microscope technologies. We have already researched and mastered the use of basic electron microscopy, and wish to advance our knowledge and delve into researching scanning probe microscopy.\r\n\r\nScanning Probe Background:\r\n\r\n  Scanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position.\r\n  Benefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed.\r\n  Researching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Army greatly. In the event of a tragedy during combat, bionic prosthesis will help to bring a soldier to normalcy and may even allow them to fight again. Congress highly commends our research!\r\n\r\nNeeded Resources:\r\n  In order to achieve our goals and create a brighter future for America, we need the amount of 1000 United States Dollars to research SPM. It would be greatly appreciated if you could supply our University with funding.\r\n\r\n-Rice', 'Rice U, \r\nWe understand your proposal and admire your end goal, bionic prosthesis and their military applications. However, we cannot afford to fund you at this time, due to both lack of funds and our previous funding toward the same goal (MIT).  If you can cooperate in a constructive way to help further this previously funded goal, we would love to help you out.\r\nDARPA', 'y', '2009-04-08 14:51:53'),
(39, 55, 52, 'Prometheus Industries'' Press Release:\r\n"Prometheus Industries: C&F Experts"', 'To expand on NanoPost''s announcement:\r\n\r\nPrometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '', 'n', '2009-04-08 14:51:58'),
(40, 45, 50, 'Scanning Probe Microscopy Funding Proposal', 'Project Overview:\r\n  The researchers at Rice University are paving the way in the realm of new microscope technologies. We have already researched and mastered the use of basic electron microscopy, and wish to advance our knowledge and delve into researching scanning probe microscopy.\r\n\r\nScanning Probe Background:\r\n\r\n  Scanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position.\r\n  Benefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed.\r\n  Researching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Public greatly. Children born without limbs will hopefully be able to achieve some semblence of normalcy in their lives thanks to our research.\r\n\r\nNeeded Resources:\r\n  In order to achieve our goals and create a brighter future for America, we need the amount of 1000 United States Dollars to research SPM. It would be greatly appreciated if you could supply our University with funding.\r\n\r\n-Rice', 'Rice,\r\n\r\nSounds awesome! Please look to NSF/DARPA for proper funding.\r\n\r\nSincerely,\r\n\r\nCongress', 'y', '2009-04-08 14:54:38'),
(41, 46, 51, 'Requesting Funding for Co-Block Polymer Lithography research + Risk mitigation', 'In order to continue our progress toward researching Energy Independent Devices, we are requesting funds of $2,050 to research Co-block Polymer Lithography. We plan to include Risk Mitigation from the WWIC with this research, per your recommendation.\r\n\r\nWe are collaborating with NASA to reach a common goal of Energy Independent Devices, which is in theCongress''s and NSF''s as well as the public''s interest. It is imperative that we receive this research funding in order to continue our progress toward more advanced research.', '', 'n', '2009-04-08 15:02:14'),
(42, 45, 51, 'Funding Proposal for Block co-polymer lithography', 'As promised here is our funding proposal:\r\n\r\nIn order to continue our progress toward researching Energy Independent Devices, we are requesting funds of $2,050 to research Block Co-Polymer Lithography. We plan to include Risk Mitigation from the WWIC with this research, per your recommendation.\r\n\r\nWe are collaborating with NASA to reach a common goal of Energy Independent Devices, which is in theCongress''s and NSF''s as well as the public''s interest. It is imperative that we receive this research funding in order to continue our progress toward more advanced research.\r\n\r\n\r\nCurrent Financing Proposal:\r\nAvailable funds: $350\r\n-$2000 Block co-polymer lithography research\r\n-$150 Risk mitigation from WWIC\r\n-$250 Patent application\r\n\r\nSeeking $2050 toward Energy Independent Devices', 'IBM,\r\n\r\nPlease get your "risk rating" in check before making such lofty proposals. We highly suggest you contact DARPA or WWIC themselves for proper risk management ($150, WWIC should have funding themselves) and ask for risk management funding before asking us for technology funding.\r\n\r\nSincerely,\r\n\r\nCongress', 'y', '2009-04-08 15:05:24'),
(43, 46, 49, 'Nanowire assembly funding proposal', 'Dear DARPA,\r\n\r\nIn order to research towards bionic prosthesis, we believe that we need to research nanowire assembly. This would allow for wire assembly on the 10^-9 scale, thereby making bionic prosthesis technology more efficient. Without nanowire assembly, bionic prosthesis would not be possible (the complicated nature of the technology would result in gigantic prosthestics without nanowire assembly). Therefore, we at MIT ask for $1150 in order to fund research and mitigate possible risk.\r\n\r\nLove,\r\nMIT', '', 'n', '2009-04-08 15:05:28'),
(44, 46, 51, 'Requesting Funding for Risk Mitigation', 'IBM is requesting $150 in funding for further risk mitigation in an effort to improve our risk rating.', '', 'n', '2009-04-08 15:09:29'),
(45, 47, 48, 'Funding for Lithographic Self-Assembly - $2200', 'Short Term:\r\nAfter the research of Optical Lithography we have reached the limitations of that top down approach.  We are now looking forward towards new ways of development in the nanoscale.  The way we believe to best do this is by bottom up technology.  Lithographic Self-Assembly is one of those technologies.  With Lithographic Self-Assembly we?ll be able to pursue new avenues and discovery new material properties.\r\n\r\nLong Term:\r\nWe are working with IBM in order to pursue improvements in energy efficient devices.  We believe this partnership will result in faster technology development which can eventually lead to reaching end goals such as lessening our dependency on foreign oil.   The availability of funding is crucial at such an important time for our nation. \r\n\r\n', 'Though $2200 is above our current budget, your proposal has been approved with the stipulation that you put some of the funding toward risk management.', 'y', '2009-04-08 15:11:04'),
(46, 47, 50, 'Scanning Probe Microscopy', 'Project Overview:\r\n  The researchers at Rice University are paving the way in the realm of new microscope technologies. We have already researched and mastered the use of basic electron microscopy, and wish to advance our knowledge and delve into researching scanning probe microscopy.\r\n\r\nScanning Probe Background:\r\n\r\n  Scanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position.\r\n  Benefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed.\r\n  Researching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Public greatly. Children born without limbs will hopefully be able to achieve some semblence of normalcy in their lives thanks to our research.\r\n\r\nUPDATE: At this point, we have entered into a business relationship with PI.\r\n\r\nNeeded Resources:\r\n  In order to achieve our goals and create a brighter future for America, we need the amount of 1250 United States Dollars to research SPM, risk management and business expenses. It would be greatly appreciated if you could supply our University with funding.\r\n\r\n-Rice', 'As Rice has already achieved SPM form other funding sources, we do not see it as necessary to allocate funds.', 'y', '2009-04-08 15:11:18'),
(47, 46, 48, 'Funding for Lithographic Self-Assembly - $2200', 'Short Term:\r\nAfter the research of Optical Lithography we have reached the limitations of that top down approach.  We are now looking forward towards new ways of development in the nanoscale.  The way we believe to best do this is by bottom up technology.  Lithographic Self-Assembly is one of those technologies.  With Lithographic Self-Assembly we?ll be able to pursue new avenues and discovery new material properties.\r\n\r\nLong Term:\r\nWe are working with IBM in order to pursue improvements in energy efficient devices.  We believe this partnership will result in faster technology development which can eventually lead to reaching end goals such as lessening our dependency on foreign oil.   The availability of funding is crucial at such an important time for our nation. \r\n', '', 'n', '2009-04-08 15:11:20'),
(48, 45, 49, 'DARPA funding for Nanowire assembly ', 'Dear Congress,\r\n\r\nWe humbly ask for DARPA funding in order to research nanowire assembly. With risk in mind, we ask for funds in the amount of $1150. Nanowire assembly would further academic research to increase defense technology. Please consider allowing us to continue research in defense technology.\r\n\r\nThank you,\r\nMIT', 'While we respect and encourage your research endeavors (especially that you are considering the risks), Congress is unwilling to directly fund neither public nor private labs at this moment.  Please contact DARPA or the NSF instead of Congress on this matter.\r\n\r\nPlease continue to keep us up to date with your research direction, however, it would be appreciated if instead of sending us funding proposals that you would email us or talk to us in person.\r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-08 15:14:55'),
(49, 47, 51, 'Requesting funds for Block Co-polymer Lithography + Risk Mitigation', 'In order to continue our progress toward researching Energy Independent Devices, we are requesting funds of $2,050 to research Block Co-Polymer Lithography. We plan to include Risk Mitigation from the WWIC with this research, per your recommendation.\r\n\r\nWe are collaborating with NASA to reach a common goal of Energy Independent Devices, which is in Congress''s and NSF''s as well as the public''s interest. It is imperative that we receive this research funding in order to continue our progress toward more advanced research and ultimately reaching Energy Independent Device with NASA.', 'We allocated money for risk management, but owing to funding from DARPA, we feel that most of our funding could be better allocated elsewhere.', 'y', '2009-04-08 15:15:32'),
(50, 45, 47, 'Research Funding', 'Research is moving forward towards energy independence.  We have spent our most recent budget on further research as well as risk management.  We require additional funds to continue along this path as well as fund research in other areas.  (which we are currently still looking for proposals.)  We plan on asking for proposals trying to further research toward nanoscale neurosurgery.', 'Congress is enthusiastic about your research aims - especially energy independence. However, due to nanotechnology''s perception in the media, it is important to our constituents that research is conducted in a safe and responsible manner. $3000 is a very large sum of money, even without detailing specifically for what the money will be used (patents, new toolkits or prototypes, risk, etc). \r\n\r\nBefore we can allocate funds to the NSF, Congress would like to hear more about how this money will be used. \r\n\r\nSincerely, Congress', 'y', '2009-04-08 15:17:00'),
(51, 45, 47, 'Append last email', 'We request an additional $3000', 'See previous proposal for an answer.', 'y', '2009-04-08 15:17:33'),
(52, 46, 51, 'Funding for Risk Reduction', 'IBM is currently greatly concerned about our poor risk rating.  We are looking to reduce it by buying services from WWIC.  In order to do this we need some money.  If we could receive $600 to use solely for risk reduction this would greatly help our situation and we would be back on track to conduct good research.\r\n\r\nSummary: \r\n$600 plus any extra you are willing to give for risk reduction purposes.', '', 'n', '2009-04-13 14:10:39'),
(53, 46, 49, 'Nanowire assembly funding proposal', 'Dear DARPA,\r\n\r\nIn order to research towards bionic prosthesis, we believe that we need to research nanowire assembly. This would allow for wire assembly on the 10^-9 scale, thereby making bionic prosthesis technology more efficient. Without nanowire assembly, bionic prosthesis would not be possible (the complicated nature of the technology would result in gigantic prosthestics without nanowire assembly). Therefore, we at MIT ask for $1150 in order to fund research and mitigate possible risk.\r\n\r\nLove,\r\nMIT', '', 'n', '2009-04-13 14:12:13'),
(54, 45, 49, 'DARPA funding for Nanowire assembly ', 'Dear Congress,\r\n\r\nWe humbly ask for DARPA funding in order to research nanowire assembly. With risk in mind, we ask for funds in the amount of $1150. Nanowire assembly would further academic research to increase defense technology. Please consider allowing us to continue research in defense technology.\r\n\r\nThank you,\r\nMIT', 'MIT,\r\n\r\nDARPA currently has sufficient funds to meet your request.  Please refer to them for funding first.\r\n\r\nCongress', 'y', '2009-04-13 14:13:05'),
(55, 46, 49, 'Funding request for Block co-polymer Lithography $2150\r\n', 'Dear DARPA,\r\n\r\nIn order to continue research towards Bionic Prosthesis, it is imperative that we research Block copolymer Lithography. Block copolymer lithography would allow for nano assembly with unique magnetic properties. Additionally, vertical transistors as well as graphene transistors would further aid in bionic prosthesis research. We humbly ask for $2150 to fund such research. This DoD project is estimated to cost $2000, with an added $150 to help with risk mitigation.\r\n\r\nRegards,\r\nMIT', '', 'n', '2009-04-13 14:13:59'),
(56, 46, 49, 'Nanowire assembly funding proposal', 'Dear DARPA,\r\n\r\nDisregard our previous message. Nanowire assembly research costs $2000, not $1000.\r\n\r\nIn order to research towards bionic prosthesis, we believe that we need to research nanowire assembly. This would allow for wire assembly on the 10^-9 scale, thereby making bionic prosthesis technology more efficient. Without nanowire assembly, bionic prosthesis would not be possible (the complicated nature of the technology would result in gigantic prosthestics without nanowire assembly). Therefore, we at MIT ask for $2150 in order to fund research and mitigate possible risk.\r\n\r\nLove,\r\nMIT', '', 'n', '2009-04-13 14:15:19'),
(57, 45, 49, 'DARPA funding for Nanowire assembly ', 'Dear Congress,\r\n\r\nDisregard our previous message. Nanowire assembly costs $2000, not $1000. \r\n\r\nWe humbly ask for DARPA funding in order to research nanowire assembly. With risk in mind, we ask for funds in the amount of $2150. Nanowire assembly would further academic research to increase defense technology. Please consider allowing us to continue research in defense technology.\r\n\r\nThank you,\r\nMIT', 'Please do not submit funding proposals directly to Congress.  We are interested in where your research is going, but the proper channels for this type of communication is in person or via email.\r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-13 14:17:10'),
(58, 47, 51, 'Reducing Risk', 'IBM is currently greatly concerned about our poor risk rating. We are looking to reduce it by buying services from WWIC. In order to do this we need some money. If we could receive $600 to use solely for risk reduction this would greatly help our situation and we would be back on track to conduct good research.\r\n\r\nSummary:\r\n$600 plus any extra you are willing to give for risk reduction purposes.', '600 granted for risk management.  ', 'y', '2009-04-13 14:24:38'),
(59, 47, 54, 'Additional Funding', 'NSF,\r\nWe need an extra $150 for purchase of additional expertise for risk reduction.\r\nSincerely,\r\nWWIC', 'As you have received funding from other sources, the NSF does not see it as necessary to fund WWIC at this time.', 'y', '2009-04-13 14:25:12'),
(60, 47, 49, 'Funding request for Block copolymer lithography. - $2000', 'Here at MIT we are dedicated to the highest degree of education. We understand that you are currently offering research funding for a graduate research fellowship program through The Division of Graduate Education and the Office of International Science and Engineering. We currently have a graduate student interested in researching block copolymer lithography as a NSF Graduate Research Fellow. This would allow him to collaborate with international graduate students in academic pursuit. The funding request for block copolymer lithography is of the amount of $2000. Please consider this funding request. Thank you.', 'The NSF has currently allocated the majority of its budget to other projects at this time and is thus unable to support you financially at this time.', 'y', '2009-04-13 14:25:12'),
(61, 45, 46, 'DARPA - funding update for phase II research', 'Per our last funding proposal, the labs we are funding have reached the next phase of research, which, as mentioned in the last proposal, will cost upwards of $2500 to fully fund, mitigate risks, and secure valuable patents for. With our current funds, we are trying to fund MIT, NASA, and IBM (who are collaborating to achieve the same ends) in their research of Nanowire Assembly and Block co-polymer lithography. However, we are in need of at least $1750 in order to be able to fund these agencies, but more would be used in funding the additional costs (risk mitigation, patent application, etc.).\r\n\r\nThank you for your consideration,\r\n\r\nDARPA', 'See rev.2', 'y', '2009-04-13 14:26:41'),
(62, 47, 49, 'Funding proposal for block copolymer lithography - added risk mitigation $2250', 'Re: Here at MIT we are dedicated to the highest degree of education. We understand that you are currently offering research funding for a graduate research fellowship program through The Division of Graduate Education and the Office of International Science and Engineering. We currently have a graduate student interested in researching block copolymer lithography as a NSF Graduate Research Fellow. This would allow him to collaborate with international graduate students in academic pursuit. The funding request for block copolymer lithography is of the amount of $2000. Please consider this funding request. Thank you.\r\n\r\nIf possible, we ask for an extra $250 for a total of $2250 in order to mitigate possible risks associated with this field of research.', 'The NSF has currently allocated the majority of its budget to other projects at this time and is thus unable to support you financially at this time.', 'y', '2009-04-13 14:29:28'),
(63, 47, 48, '$3250 proposal for Lithographic Self-Assembly', 'Short Term:\r\nAfter the research Lithographic Self-Assembly we are now looking at newer ways of self assembly.  We are looking to the future with assembled quantum dots.  With this research we will be leading the market in semiconductor technology.  This is a continuation of our bottom up approach to produce futuristic technology.\r\n\r\nLong Term:\r\nWe are working with IBM in order to pursue improvements in energy efficient devices. We believe this partnership will result in faster technology development which can eventually lead to reaching end goals such as lessening our dependency on foreign oil. The availability of funding is crucial at such an important time for our nation.\r\n\r\nFunding breakdown:\r\n$3000 for Lithographic Self-Assembly research\r\n$250 for risk management\r\n', '3250 GRANTED for Research and risk management. ', 'y', '2009-04-13 14:31:00'),
(64, 46, 48, '$3250 proposal for Lithographic Self-Assembly', 'Short Term:\r\nAfter the research Lithographic Self-Assembly we are now looking at newer ways of self assembly.  We are looking to the future with assembled quantum dots.  With this research we will be leading the market in semiconductor technology.  This is a continuation of our bottom up approach to produce futuristic technology.\r\n\r\nLong Term:\r\nWe are working with IBM in order to pursue improvements in energy efficient devices. We believe this partnership will result in faster technology development which can eventually lead to reaching end goals such as lessening our dependency on foreign oil. The availability of funding is crucial at such an important time for our nation.\r\n\r\nFunding breakdown:\r\n$3000 for Lithographic Self-Assembly research\r\n$250 for risk management\r\n', '', 'n', '2009-04-13 14:31:22');
INSERT INTO `funding` (`funding_id`, `to_group`, `from_group`, `title`, `proposal`, `response`, `responded`, `sent`) VALUES
(65, 45, 48, '$3250 proposal for Lithographic Self-Assembly', 'This is our proposal for our next research.  We either need funding directly from you or for you to give funding to NSF.\r\n\r\nShort Term:\r\nAfter the research Lithographic Self-Assembly we are now looking at newer ways of self assembly.  We are looking to the future with assembled quantum dots.  With this research we will be leading the market in semiconductor technology.  This is a continuation of our bottom up approach to produce futuristic technology.\r\n\r\nLong Term:\r\nWe are working with IBM in order to pursue improvements in energy efficient devices. We believe this partnership will result in faster technology development which can eventually lead to reaching end goals such as lessening our dependency on foreign oil. The availability of funding is crucial at such an important time for our nation.\r\n\r\nFunding breakdown:\r\n$3000 for Lithographic Self-Assembly research\r\n$250 for risk management\r\n', 'Please do not submit funding proposals directly to Congress.  We are interested in where your research is going, but the proper channels for this type of communication is in person or via email.  \r\n\r\nSincerely,\r\nCongress\r\n\r\nP.S. - We are especially pleased with the funding breakdown, please be sure to send those figures to NSF.', 'y', '2009-04-13 14:33:08'),
(66, 45, 46, 'DARPA - funding update for phase II research - rev.2', 'Updated figures:\r\n\r\nPer our last funding proposal, the labs we are funding have reached the next phase of research, which, as mentioned in the last proposal, will cost upwards of $2500 to fully fund, mitigate risks, and secure valuable patents for. With our current funds, we are trying to fund MIT, NASA, and IBM (who are collaborating to achieve the same ends) in their research of Nanowire Assembly and Block co-polymer lithography. However, we are in need of at least $1750 in order to be able to fund these agencies, but more would be used in funding the additional costs for risk mitigation ($500 more, for a grand request total of $2250.\r\n\r\nThank you for your consideration,\r\n\r\nDARPA', 'Request granted.  Thank you for keeping the public''s interest at heart and outlining risk mitigation as a key concern.\r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-13 14:41:39'),
(67, 45, 46, 'Funding for MIT and their continuing collaboration with IBM', 'Congress,\r\nMIT and IBM''s collaboration has been finalized, and with a bit more funding, MIT can make the next step in their research. They will be researching NanoWire Assembly. This is important to their advancement toward bionic prosthesis, which will help in both civilian and military applications.\r\nThis research is also necessary for IBM''s end goal (Energy Independent Devices) as MIT and IBM are sharing patents and research to speed up research. \r\nWe are asking for at least $1300, which will put us at $2250 (we have $950 now). This is just enough to fund MIT''s next round of research in NanoWire Assembly ($2000 and $250 for risk)\r\nThanks,\r\nDARPA', '', 'n', '2009-04-13 15:09:24'),
(68, 46, 51, 'Funding for Hybrid Devices', 'IBM''s next step is to research hybrid devices, as per your stipulation that we work with MIT to reach wearable computers.  We are now ready to research hybrid devices but need money.  The research cost is $3000.  We already have the money from WWIC to cover the good risk mitigation, which we are going to use.  \r\n\r\nAfter we research hybrid devices, we plan to share the research with MIT to be able to research wearable computers.\r\n\r\nSummary:\r\n$3000 for hybrid devices research', '', 'n', '2009-04-13 15:10:13'),
(69, 47, 48, 'Portable Photovoltaics', 'Battery technology is currently in a sad state of neglect.  Batteries are simply incapable of holding enough energy to power advanced electronics for any substantial amount of time.  Developments come few and far between.  Current batteries are heavy and inefficient.  What is needed is a source of power that has a high energy-density and can extend the electronic life of equipment tremendously.\r\nResearch into portable photovoltaics can solve this issue.   Photovoltaics are components that can create energy from light, usually the sun, and are frequently used to power small electronics, while larger photovoltaics are used to help run buildings.  However, devices larger then a calculator require too much power to be operated on solar power, and systems large enough to run a building can be as large as several acres. \r\nOur research into portable photovoltaics is increasing the efficiency and compactness of the technology. This will lead to more portable and powerful technologies.\r\n\r\n$4450 will be required to complete research and obtain the full risk mitigation package.', 'Your proposal has been approved and funded, and though it has been postponed due to current technological complications, we expect you to pursue it again as soon as the difficulties are resolved.', 'y', '2009-04-13 15:11:08'),
(70, 47, 49, ' Nanowire assembly funding proposal', 'Dear NSF,\r\n\r\nIn order to research towards bionic prosthesis, we believe that we need to research nanowire assembly. This would allow for wire assembly on the 10^-9 scale, thereby making bionic prosthesis technology more efficient. Without nanowire assembly, bionic prosthesis would not be possible (the complicated nature of the technology would result in gigantic prosthestics without nanowire assembly). In the immediate future, nanowire is going to be necessary for the development of graphene transistors which will lead to much more efficient and smaller electronics than the silicon counterparts.  Therefore, we at MIT ask for $2250 in order to fund research and mitigate possible risk.\r\n\r\nMIT', 'As you have by now completed this research we find to further reason to grant your proposal.', 'y', '2009-04-13 15:12:21'),
(71, 45, 47, 'Stage Three Funding', 'We request 7000$ for research funding and 900$ for risk management funding.  this comes to 7900$ total requested.  In this funding is included one level four research grant and one level three research grant.  Both research grants will include 450$ each for "good" risk management (maximum available).  We are still currently supporting research along the lines of energy independent devices and are making good progress.  The coming rounds of research will be expensive, but worthwhile--as we will be within few places of the ultimate goal of energy independence.  As a side note, we are still looking for research proposals for Nanoscale Nerosurgery, but proposals have been lacking.  After the next round, we will ask for proposals in this area.  \r\n\r\nNSF\r\n\r\n\r\nrequest for 7900$', 'Congress does not have the amount of funds needed to fully endorse your goals.  Instead, we will allocate $3,950 in order for you to fully fund one half of your aims.  This will allow one of your possible funding paths to perform research and risk analysis, but clearly isn''t enough for the other.\r\n\r\nAlso, in light of the recent scanning probe microscopy faux pas, Congress also asks that you attempt to avoid similar situations in which funds are wasted.\r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-13 15:12:40'),
(72, 47, 48, '$3350 for Graphene Transistors', 'We are seeking funding for graphene transistors.  We see this technology as being very beneficial now.  Doing this research will also improve our risk rating.  We are still seeking funding for Portable Photovoltaic.\r\n', 'As your research partner IBM no longer has the required requisite research due to the problem with Block Co-polymers, we are currently turning down this grant proposal.', 'y', '2009-04-15 14:11:12'),
(73, 46, 51, 'Request for $3350 to research Hybrid Devices', 'First, thank you for your continued support and funding.\r\n\r\nWe are requesting $3350 to research Hybrid Devices. $3000 is for research and $350 is for the best risk mitigation. \r\n\r\nWe are very close to reaching our goal of Energy Independent Devices. Our cooperation with other institutions as well as your funding will allow us to advance our research.\r\n\r\nThank you for your time.', '', 'n', '2009-04-15 14:12:29'),
(74, 47, 51, 'Requesting $3350 to research Hybrid Devices', 'First, thank you for your continued support and funding.\r\n\r\nWe are requesting $3350 to research Hybrid Devices. $3000 is for research and $350 is for risk mitigation. \r\n\r\nWe are very close to reaching our goal of Energy Independent Devices. Our cooperation with other institutions as well as your funding will allow us to advance our research.\r\n\r\nThank you for your time.', '2750$ Granted for research towards Hybrid Devices and risk management.  This amount should raise your fund enough to achieve this goal.  ', 'y', '2009-04-15 14:13:07'),
(75, 46, 48, '$3400 for Graphene transistors', 'We are seeking funding for graphene transistors. We see this technology as being very beneficial now. Doing this research will also improve our risk rating. We are also working with NSF for funding so if we could get combined funding it would be good.', '', 'n', '2009-04-15 14:33:31'),
(76, 46, 49, 'Graphene Transistor Funding Request ? $3350', 'Research into Graphene transistors is an integral next step in MIT?s development towards bionic prosthetics.  Our research in Nanowire assembly suggests the possibility of developing what are termed ?ballistic transistors? from graphene.  Ballistic transistors are transistors that can function as high speed switching devices due to the ability for electrons to flow through effectively unimpeded, causing there to be no intrinsic resistance, allowing electrons to move more quickly and create circuits that can operate at higher clock speeds.  In the case of the Graphene Transistor, a ballistic transistor made with graphene, due to the construction with graphene nanoribbons these transistors will also be extremely small and can thus be concentrated in much greater quantities per unit area, leading to a two dimensional improvement over current transistors.  Additionally microchips developed with graphene will likely have less noise than their silicon counterparts, leading to lower error rates and allowing for once again higher clock speeds.  These improvements of more powerful and much smaller processors and circuitry will be one of the founding principles in the development of wearable computers, and thus we would like to request $3350: $3000 for research and $350 for risk assessment.\r\n', '', 'n', '2009-04-15 14:34:36'),
(77, 47, 49, 'Graphene Transistor Funding Request ? $3350', 'Research into Graphene transistors is an integral next step in MIT?s development towards bionic prosthetics.  Our research in Nanowire assembly suggests the possibility of developing what are termed ?ballistic transistors? from graphene.  Ballistic transistors are transistors that can function as high speed switching devices due to the ability for electrons to flow through effectively unimpeded, causing there to be no intrinsic resistance, allowing electrons to move more quickly and create circuits that can operate at higher clock speeds.  In the case of the Graphene Transistor, a ballistic transistor made with graphene, due to the construction with graphene nanoribbons these transistors will also be extremely small and can thus be concentrated in much greater quantities per unit area, leading to a two dimensional improvement over current transistors.  Additionally microchips developed with graphene will likely have less noise than their silicon counterparts, leading to lower error rates and allowing for once again higher clock speeds.  These improvements of more powerful and much smaller processors and circuitry will be one of the founding principles in the development of wearable computers, and thus we would like to request $3350: $3000 for research and $350 for risk assessment.', 'Though the NSF is eager to fund MIT in this venture we are sorry to report that we have already allocated all of our currently available funds, though we strongly encourage you to submit another proposal for this research at a later time once the NSF acquires additional funding.', 'y', '2009-04-15 14:34:56'),
(78, 45, 54, 'Funding Request', 'Dear Congressmen/Women,\r\nWWIC has been actively involved in risk mitigation of various organizations. But we need some additional funding to further hone our expertise in risk mitigation.\r\nThe new expertise costs $5000 and we have $950 only in our vault. At this point any help would be welcome. We have been saving face of Congress and we want it to be robust and trustworthy going into elections.\r\n\r\nYour Sincerely,\r\nWWIC ', 'We''re glad to help however we can.  NSF said that they have invested some of the government money in WWIC, so let us know if we can be of further assistance.\r\n\r\nSincerely,\r\nCongress', 'y', '2009-04-15 14:38:34'),
(79, 47, 49, 'Gradient Lithography - $2250', 'Here at MIT we are continuing on in our vision of a future with Bionic Prosthetics able to all who need them.  To this end, we are requesting funding for research into Gradient Lithography.  Gradient Lithography is the process of creating structures that are used in filtering things down to nano quantities.  These structures are created by various lithographic processes, where a gradient is made to allow smaller and smaller quantities to pass through various stages, eventually moving from micro quantities into nano quantities.  This type of separation will be integral in many of the filtering and more exacting processes in nano, with particular applicability to developing nano particles that will be of the correct size and quantity to move through the human body as designed, passing through some desired channels but not the undesired others.  Thus, we are requesting $2000 for the research, and an additional $250 for the risk mitigation research.', 'Since the NSF has currently allocated all of its available funds elsewhere and research in this line is not currently the first priority of the funding of the NSF, we are unable to grant your proposal for funding at this time.', 'y', '2009-04-15 14:41:57'),
(80, 46, 49, 'Gradient Lithography - $2250', 'Here at MIT we are continuing on in our vision of a future with Bionic Prosthetics able to all who need them. To this end, we are requesting funding for research into Gradient Lithography. Gradient Lithography is the process of creating structures that are used in filtering things down to nano quantities. These structures are created by various lithographic processes, where a gradient is made to allow smaller and smaller quantities to pass through various stages, eventually moving from micro quantities into nano quantities. This type of separation will be integral in many of the filtering and more exacting processes in nano, with particular applicability to developing nano particles that will be of the correct size and quantity to serve as osteoconductive materials, used for bone growth scaffolding in the human body. This sort of improved human regenerative technology will be integral in the development of Bionic Prosthetics. Thus, we are requesting $2000 for the research, and an additional $250 for the risk mitigation research.', '', 'n', '2009-04-15 14:48:14'),
(81, 45, 47, 'Funding', '1450$ for enabling WWIC to achieve better risk mitigation', 'Complete', 'y', '2009-04-15 15:07:16'),
(82, 47, 50, 'Rice''s plea for Templated Self-Assembly', 'We desperately need $2000 for researching Templated Self-Assembly and $350 for "good" risk mitigation.  Afterward our plans are to research hybrid devices, then wearable computers, and eventually Bionic prostheses', 'Your grant application has been approved on caveat of sharing resulting research with IBM.', 'y', '2009-04-15 15:10:01'),
(83, 46, 49, 'Graphene Transistors funding request $3350', 'Research into Graphene transistors is an integral next step in MIT?s development towards bionic prosthetics. Our research in Nanowire assembly suggests the possibility of developing what are termed ?ballistic transistors? from graphene. Ballistic transistors are transistors that can function as high speed switching devices due to the ability for electrons to flow through effectively unimpeded, causing there to be no intrinsic resistance, allowing electrons to move more quickly and create circuits that can operate at higher clock speeds. In the case of the Graphene Transistor, a ballistic transistor made with graphene, due to the construction with graphene nanoribbons these transistors will also be extremely small and can thus be concentrated in much greater quantities per unit area, leading to a two dimensional improvement over current transistors. Additionally microchips developed with graphene will likely have less noise than their silicon counterparts, leading to lower error rates and allowing for once again higher clock speeds. These improvements of more powerful and much smaller processors and circuitry will be one of the founding principles in the development of wearable computers, and thus we would like to request $3350: $3000 for research and $350 for risk assessment.', '', 'n', '2009-04-20 14:10:14'),
(84, 46, 49, 'Gradient Lithography $2250', 'Here at MIT we are continuing on in our vision of a future with Bionic Prosthetics able to all who need them. To this end, we are requesting funding for research into Gradient Lithography. Gradient Lithography is the process of creating structures that are used in filtering things down to nano quantities. These structures are created by various lithographic processes, where a gradient is made to allow smaller and smaller quantities to pass through various stages, eventually moving from micro quantities into nano quantities. This type of separation will be integral in many of the filtering and more exacting processes in nano, with particular applicability to developing nano particles that will be of the correct size and quantity to serve as osteoconductive materials, used for bone growth scaffolding in the human body. This sort of improved human regenerative technology will be integral in the development of Bionic Prosthetics. Thus, we are requesting $2000 for the research, and an additional $250 for the risk mitigation research.', '', 'n', '2009-04-20 14:12:31'),
(85, 45, 51, 'Funding for Energy Independent Devices', 'We are requesting $5550 to research Energy Independent Devices.\r\n\r\n$5000 for research\r\n$550 for best available risk mitigation\r\n\r\nWe are a few minutes away from having the research necessary to research Wearable Computers, and the next step is to research Energy Independent Devices. \r\n\r\nWe also have an Excellent risk rating. Rest assured that you are making a good investment.', 'NASA is completing work on EIDs.', 'y', '2009-04-22 14:24:36'),
(86, 47, 49, 'Osteoconductive Materials funding proposal - $3500\r\n ', 'To research Regenerative Tissues, we need $3500 to research OsteoconductiveMaterials first.\r\n\r\nThanks,\r\nMIT ', 'Funded by DARPA.', 'y', '2009-04-22 14:25:57'),
(87, 46, 49, 'Regenerated Tissues funding proposal - $4500\r\n', 'Can we get some money?\r\n\r\nMIT', '', 'n', '2009-04-22 14:26:51'),
(88, 47, 49, 'Regenerated Tissues funding proposal - $4500\r\n', 'Money us, please.\r\n\r\nMIT', 'Funded by Darpa.', 'y', '2009-04-22 14:27:25'),
(89, 47, 50, 'Rice wants to research Nano Scaffolds!', 'We need $3450 so we can get to regenerated tissues leading to bionic prostheses.', 'Approved.', 'y', '2009-04-22 14:29:08'),
(90, 45, 47, 'Bionic Prosthesis funding', 'requesting $5550 for Bionic Prosthesis funding', '', 'n', '2009-04-22 14:42:13'),
(91, 47, 51, 'Funding for Bionic Prosthesis', 'In order to reach as many Grand Challenges as possible, we plan to research Bionic Prosthesis.\r\n\r\nIn order to do this, we need $5450 in funds to start the research.  We are working with MIT and Rice to achieve this goal by sharing research.\r\n\r\nSummary:\r\n\r\n$5450 for Bionic Prosthesis', 'Approved.', 'y', '2009-04-22 14:44:05'),
(92, 46, 50, 'Request for $5450', 'Our final goal is to create two levels of bionic prostheses.  The first level consists of rehabilitative limbs to allow injured soldiers to continue fighting on the battlefield.  In addition these limbs will vastly improve upon normal human limbs by being able to heal wounds and administer needed medicine instantaneously. The second level of prostheses consists of wearable suits that will allow soldiers to achieve super-human abilities on and off the battlefield.', '', 'n', '2009-04-22 15:03:15');

-- --------------------------------------------------------

--
-- Table structure for table `group_types`
--

CREATE TABLE IF NOT EXISTS `group_types` (
  `group_type_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `has_patents` enum('y','n') NOT NULL default 'y',
  `has_research` enum('y','n') NOT NULL default 'y',
  `has_business` enum('y','n') NOT NULL default 'n',
  `has_facilities` enum('y','n') NOT NULL default 'y',
  `research_availability` enum('public','private') NOT NULL default 'private',
  `view_all_budgets` enum('y','n') NOT NULL default 'n',
  `newspaper` enum('y','n') NOT NULL default 'n',
  `has_review` enum('y','n') NOT NULL default 'n',
  `has_certificates` enum('y','n') NOT NULL default 'n',
  PRIMARY KEY  (`group_type_id`),
  UNIQUE KEY `group_id` (`group_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Specifies the type of groups and their characteristics' AUTO_INCREMENT=9 ;

--
-- Dumping data for table `group_types`
--

INSERT INTO `group_types` (`group_type_id`, `name`, `has_patents`, `has_research`, `has_business`, `has_facilities`, `research_availability`, `view_all_budgets`, `newspaper`, `has_review`, `has_certificates`) VALUES
(1, 'Government', 'n', 'n', 'n', 'n', 'public', 'y', 'n', 'n', 'n'),
(2, 'Public Laboratory', 'y', 'y', 'n', 'y', 'public', 'n', 'n', 'n', 'n'),
(3, 'Private Laboratory', 'y', 'y', 'y', 'y', 'private', 'y', 'y', 'y', 'y'),
(4, 'Funding Agency', 'n', 'n', 'n', 'n', 'private', 'y', 'n', 'n', 'n'),
(5, 'NGO', 'n', 'n', 'n', 'n', 'private', 'y', 'n', 'n', 'n'),
(6, 'Newspaper', 'n', 'n', 'n', 'n', 'private', 'n', 'y', 'n', 'n'),
(7, 'Risk Reduction', 'n', 'n', 'n', 'n', 'private', 'n', 'n', 'n', 'y'),
(8, 'Review', 'n', 'n', 'n', 'n', 'private', 'y', 'n', 'y', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `group_id` int(255) NOT NULL auto_increment,
  `class_id` int(11) NOT NULL default '0',
  `group_type_id` int(11) NOT NULL default '0',
  `members` text NOT NULL,
  `password` varchar(32) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `budget` float NOT NULL default '0',
  `objective` text NOT NULL,
  PRIMARY KEY  (`group_id`),
  UNIQUE KEY `group_pk` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Associates a class with its groups' AUTO_INCREMENT=56 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`group_id`, `class_id`, `group_type_id`, `members`, `password`, `name`, `budget`, `objective`) VALUES
(45, 91, 1, '', 'bills', 'Congress', 113.75, '- represent the will of the people and their opinion on ethical authorization and appropriation of nanotechnology funding'),
(46, 91, 4, '', 'soldiers', 'DARPA', 3, 'DARPA?s mission is still to prevent technological surprise to the US, but also to create technological surprise for our enemies.'),
(47, 91, 4, '', 'medicine', 'NSF', 0, 'To fund basic research that works towards peaceful applications of technology to societal problems in a way that does not pose significant risk to humans or the environment.'),
(48, 91, 2, '', 'asteroid', 'NASA', 650, 'In the past, NASAs excellence in research regarding space exploration has had a profound influence on science as well as technology in everyday life. We intend to pursue future technologies in order to further enhance the lives of Americans and push the boundaries of human exploration.'),
(49, 91, 2, '', 'bulletproof', 'MIT', 49.5, 'We plan on starting our research with ion etching and chemical vapor deposition and then working towards other tools and prototypes that will lead us to novel bionic prosthesis. '),
(50, 91, 2, '', 'sandydunes', 'Rice', 350, 'Electron Microscopy --> hierarchical self-assembly --> nano-scaffolds -->regenerated tissues --> bionic prosthesis\r\n\r\nscanning probe microscopy --> templated self-assembly -->hybrid devices --> wearable computers --> bionic prosthesis\r\n\r\nAs well as ion etching and polymers'),
(51, 91, 3, '', 'microchip', 'IBM', 100, 'IBM is an advanced technology corporation with proven research and development expertise in producing high performance electronic devices.  With the application of our specialized knowledge in this field, IBM plans on developing cutting edge solutions for a wide array of technologies, with emphasis on Energy Independent Devices and Sensory Enhancement.'),
(52, 91, 3, '', 'freedom', 'PI', 0, 'Prometheus Industries is a small start-up company dedicated to advancing technology for the good of mankind. And the U.S. Government.'),
(53, 91, 8, '', 'stopnano', 'ETC', 5500, '"ETC Group is dedicated to the conservation and sustainable advancement of cultural and ecological diversity and human rights. To this end, ETC Group supports socially responsible developments of technologies useful to the poor and marginalized and it addresses international governance issues and corporate power."\r\n-from etcgroup.org'),
(54, 91, 7, '', 'polls', 'WWIC', 4605.25, 'We are Woodrow Wilson Project on Emerging Nanotechnologies. We provide you with expert services on risk reduction and mitigation. As you all know, a robust framework for risk management is a prerequisite for funding from the Federal Government, especially the National Science Foundation(NSF). Also, our trustworthy services will help you gain public approval. So, we can help you get the money you need for that research you have been planning for.\r\n\r\n-Woodrow Wilson Project on Emerging Nanotechnologies '),
(55, 91, 6, '', 'truth', 'NanoPost', 78.5, '');

-- --------------------------------------------------------

--
-- Table structure for table `hires_aid`
--

CREATE TABLE IF NOT EXISTS `hires_aid` (
  `hiring_id` int(11) NOT NULL auto_increment,
  `hiring_group` int(11) NOT NULL default '0',
  `hired_group` int(11) NOT NULL default '54',
  `research_type_id` int(11) NOT NULL default '0',
  `cost` int(11) NOT NULL default '500',
  `risk_reduction` int(11) NOT NULL default '5',
  PRIMARY KEY  (`hiring_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `hires_aid`
--

INSERT INTO `hires_aid` (`hiring_id`, `hiring_group`, `hired_group`, `research_type_id`, `cost`, `risk_reduction`) VALUES
(1, 48, 54, 9, 150, 5),
(2, 49, 54, 4, 150, 5),
(3, 48, 54, 18, 150, 5),
(4, 52, 54, 9, 150, 5),
(5, 51, 54, 19, 250, 10),
(6, 48, 54, 26, 350, 15),
(7, 49, 54, 16, 250, 10),
(8, 51, 54, 26, 350, 15),
(9, 52, 54, 14, 350, 15),
(10, 51, 54, 22, 350, 15),
(11, 52, 54, 15, 250, 10),
(12, 50, 54, 17, 450, 20),
(13, 48, 54, 34, 450, 20),
(14, 51, 54, 22, 350, 15),
(15, 51, 54, 31, 450, 20),
(16, 48, 54, 39, 450, 20),
(17, 50, 54, 21, 450, 20),
(18, 49, 54, 23, 450, 20),
(19, 49, 54, 29, 450, 20),
(20, 52, 54, 31, 350, 15),
(21, 51, 54, 37, 450, 20),
(22, 52, 54, 37, 450, 20);

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE IF NOT EXISTS `mail` (
  `mail_id` int(11) NOT NULL auto_increment,
  `to_group` int(11) NOT NULL default '0',
  `from_group` int(11) NOT NULL default '0',
  `subject` text NOT NULL,
  `message` longtext NOT NULL,
  `sent` datetime NOT NULL default '2000-00-00 00:00:00',
  `unread` enum('y','n') NOT NULL default 'y',
  PRIMARY KEY  (`mail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Dumping data for table `mail`
--

INSERT INTO `mail` (`mail_id`, `to_group`, `from_group`, `subject`, `message`, `sent`, `unread`) VALUES
(1, 46, 45, 'Congressional Hearing Appointment', 'We would like to hold a hearing to discuss your current proposals for nanotechnology research. Once you have proposals ready, please come to us (front of room) when you are prepared.', '2009-04-06 14:30:06', 'n'),
(2, 47, 45, 'Congressional Hearing', 'We would like to hold a hearing to discuss your current proposals for nanotechnology research. Once you have proposals ready, please come to us (front of room) when you are prepared.', '2009-04-06 14:30:33', 'n'),
(3, 55, 47, 'Add', 'Would you please run the following blurb for us.\r\n\r\n"NSF is currently soliciting proposals for level two toolkit research.  Please submit your proposal directly to the NSF and include amount requested.  In the proposal include research plan from toolkit to grand challenge."\r\n\r\n\r\nThanks, \r\n\r\n        NSF', '2009-04-06 14:31:53', 'n'),
(4, 55, 54, 'Risk Management Services Here', 'We are Woodrow Wilson Project on Emerging Nanotechnologies. We provide you with expert services on risk reduction and mitigation. As you all know, a robust framework for risk management is a prerequisite for funding from the Federal Government, especially the National Science Foundation(NSF). Also, our trustworthy services will help you gain public approval.  So, hey we can help you get the money you need for that research you have been planning for.\r\n\r\n-Woodrow Wilson Project on Emerging Nanotechnologies', '2009-04-06 14:49:42', 'n'),
(5, 55, 46, 'Receiving funding from DARPA', 'Greetings from DARPA, your friendly neighborhood defense research organization! In order for funding proposals to be considered for approval, your proposal should advance defense technologies in one of the following areas: Sensory Enhancement, Biometric Nanoparticle Tracking, Bionic Prosthesis, or Energy Independent Devices. Please bear in mind that our funding is limited, and only those proposals that advance the state of military technology the most will be considered.\r\n\r\n-DARPA', '2009-04-06 14:50:06', 'n'),
(6, 55, 47, 'NSF Mission Statement', 'To fund basic research that works towards peaceful applications of technology to societal problems.', '2009-04-06 14:55:53', 'n'),
(7, 55, 45, 'U.S. Nano Initiatives', 'The United States Congress is looking to spearhead the global nanotechnology challenge.  We feel that nanotechnology offers great benefits to the average American, and it is of the utmost importance that nanotechnology research is geared towards improving the quality of life for our citizens.  The private interest groups are not the key concern when investigating the vast possibilities and applications of nanotechnology, it is the American public.\r\n\r\nThat being said, nanotechnology also implies a great risk; these technologies can be applied in harmful and negative ways.  It is the purpose of the U.S. government to protect its people, as the people are its greatest asset.  Defending against the baneful application of nanotechnologies and also protecting against unseen negative consequences are major goals of this Congress.\r\n\r\nWe look forward to serving, you, the public.\r\nSincerely,\r\nCongress', '2009-04-06 14:57:01', 'n'),
(8, 47, 55, 'Thank you for your message', 'Your message, thank you for it', '2009-04-06 14:57:11', 'n'),
(9, 55, 53, 'Important Reminder', 'To the Nanotechnology Community, \r\n\r\nWe want to inform you that you need to keep ETC in mind when making decisions and putting forth ideas. Do not hesitate to message us with questions before acting out on anything, and make sure your risks are low or you will not be able to continue. As ETC exec, our primary concerns are the public and the amount of communication between the public and corporate is clear and thorough. The risk of nano should be presented to everyone openly and blatantly. \r\n\r\nRegards, ETC\r\n', '2009-04-06 15:03:27', 'n'),
(10, 48, 53, 'Your risk rating', 'NASA:\r\n\r\nYour current research in optical lithography currently has a poor risk rating.  If this is not improved by next class, as the ETC, we will have to make this information open to the public.\r\n\r\nETC', '2009-04-06 15:10:50', 'n'),
(11, 55, 47, 'bulletin to be posted', 'Can you please ask that researchers include the amount of funding that they are requesting for their research?  We have already received several proposals with no specified amounts of funding requested.', '2009-04-06 15:13:37', 'n'),
(12, 45, 51, 'Good Afternoon', 'Congress,\r\n\r\nIBM is an advanced technology corporation with proven research and development expertise in producing high performance electronic devices.  With the application of our specialized knowledge in this field, IBM plans on developing cutting edge solutions for a wide array of technologies, with emphasis on Energy Independent Devices and Sensory Enhancement.  Currently, we are in the process of researching polymers in order to work toward our primary goal of developing Energy Independent Devices.  Our devices will have a significant impact on the environmental crisis and we hope you will have our support in developing this new technology.  Thank you for your consideration\r\n\r\nIBM', '2009-04-06 15:15:06', 'n'),
(13, 54, 51, '', '', '2009-04-08 14:18:23', 'n'),
(14, 47, 51, 'Funding for Polymer Patent', 'IBM is attempting to work in conjuncture with the goals of NSF.  In order for this to occur, we need to acquire the patent for polymers so that another group cannot.  Please lend us $150 now so PI does not ruin this for us.', '2009-04-08 14:19:23', 'n'),
(15, 45, 53, 'TEst', 'Test\r\n\r\nhe''s that ""', '2009-04-08 14:47:39', 'n'),
(16, 54, 45, 'test', 'test', '2009-04-08 14:48:56', 'n'),
(17, 51, 47, 'Risk Analysis', 'Notice:\r\n\r\nIn order to receive continued funding from the NSF, we require that you work to reduce risk in the research you are conducting. We expect this risk analysis to be incorporated in your next proposal.', '2009-04-08 14:49:04', 'n'),
(18, 48, 47, 'Risk Analysis', 'Notice:\r\n\r\nIn order to receive continued funding from the NSF, we require that you work to reduce risk in the research you are conducting. We expect this risk analysis to be incorporated in your next proposal.', '2009-04-08 14:49:18', 'n'),
(19, 53, 49, 'ion etching risk', 'We would like to know what risks you may find possible with ion etching research. MIT believes that there is low risk involved; however, risk mitigation is something that we would like to keep in mind.', '2009-04-08 14:52:00', 'n'),
(20, 45, 51, 'Mitigating Future Risk', 'Hello,\r\n\r\nWe are looking to invest some money left over from our research in a way that will help to reduce the risk of our research. We at IBM were wondering if we could use that money to work with WWIC to help determine/reduce the risk of our current and future research. \r\n\r\nCurrently we have a risk rating of poor and are seriously looking to reduce that.  We plan to use pay the $150 risk mitigation fee for the next round of research to help this.  Can we work with you to help mitigate risk further?\r\n\r\nIBMs current goal is to develop energy independent devices in conjuncture with NASA in order to alleviate the current strain on the worlds energy sources. By researching polymers, we are taking the first step to reach that final goal. We are looking to help reduce the worlds dependence on non-renewable energy sources and reduce the pollution that current energy sources create.\r\n\r\n If you are interested in working with IBM and helping us achieve our goal of the developing energy independent devices, please let us know and we can start working together and we can get you the money that we have left over from our current research project. \r\n\r\nSincerely, IBM', '2009-04-08 14:52:44', 'n'),
(21, 47, 48, 'NSF', 'We are working with Wilson to reducing our risk. We have already talked to them and our risk rating will be lowered soon. Our relationship with the NSF is important and hope you reconsider our funding requests soon. ', '2009-04-08 14:52:48', 'n'),
(22, 47, 51, 'Risk', 'We are currently talking to and working with WWIC to mitigate our risk.  We will also pay the $150 risk mitigation fee for the next round of research. When we submitted the most recent round, we forgot we had enough money to do it.  But we have recognized the risk problem and are working on reducing it.\r\n\r\nIBM ', '2009-04-08 14:55:57', 'n'),
(23, 45, 53, 'PI - Polymers', 'Congress,\r\n\r\nWhen the PI group made their research on polymers public, the risk rating was very bad, and everyone accessing this will be accessing risky material.  That being said, PI has moved forward and bettered their research and has a good rating, but everyone else is still using this risky data.  If it were to stay on the market as a poor rating, it could have catastrophic consequences.  We believe you need to step in and get them to retract their making polymers public until they make such research public after having reduced the risk greatly.\r\n\r\nRegards,\r\nETC', '2009-04-08 14:56:40', 'n'),
(24, 54, 48, 'good points about NASA', 'NASA is in a technology exchange partnership with IBM, working together to develop Energy Independent devices.  We are currently researching Scanning Probe Microscopy, an established and secure field,  which will help lead to Hybrid Devices, a stepping stone to our goal.   We are insuring the risk on all our future research, and the only reason our previous research was not risk-reduced was due to lack of funding.  Things are looking up, and with our partnership, progress should be swift and decisive. ', '2009-04-08 14:58:05', 'n'),
(25, 45, 47, 'Risk Management', 'We are now requiring as part of funding proposals details on how each Lab plans to reduce the risk of each technology they research.  As a public funding agency we believe that risk management and public opinions are essential to proper application of research and technology.', '2009-04-08 14:58:19', 'n'),
(26, 51, 54, 'Your Rating dropped! ', 'Hey there IBM,\r\nWe were recently reviewing your risk ratings and found out that you have dropped from "good" to "poor".\r\nThis is to let you know that it is crucial for you at this point to hire our services, so that we can work together to improve your rating.  we are also working with NASA who is in a similar situation.  \r\nHope to hear from you soon. ', '2009-04-08 14:58:41', 'n'),
(27, 51, 47, 'Risk', 'sounds good, look forward to receiving your next proposals.', '2009-04-08 15:00:21', 'n'),
(28, 48, 47, 'Risk', 'Sounds good, we look forward to receiving you next proposal.', '2009-04-08 15:00:53', 'n'),
(29, 49, 53, 'Risks', 'MIT,\r\n\r\nThank you for contacting us about the risks and keeping us in mind before you publicize any risky data.  As of now, your risk status is low, which is good, but we do see a few things that could potentially lead to a subpar ending product.  We see potential risk in superhuman "powers" and human enhancements becoming the norm and abused power.  We also see risk in potential handicaps.  Please do not hesitate to ask any questions about your status, but as of now, you''re doing the right thing.\r\n\r\nRegards,\r\nETC', '2009-04-08 15:04:06', 'n'),
(30, 55, 47, '2nd Round Proposals', 'Please post:\r\n\r\n\r\n"NSF is currently accepting proposals from research labs.  Please address your research plan, both long term and short term.  We also need to see how you plan on reducing the associated risk with any nanotechnology research.  Do not forget to include the amount you are requesting."\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nthanks,\r\n            NSF', '2009-04-08 15:05:27', 'n'),
(31, 48, 47, 'funding', 'We have acquired more funding.  Send us proposals ASAP.  ', '2009-04-08 15:06:19', 'n'),
(32, 54, 51, 'Services', 'We are currently researching Quantum Dots and working on funding from DARPA to research Block co-polymers.  We are currently working with NASA to develop energy independent devices faster than on our own.  NSF supports our collaboration but we need to reduce risk.\r\n\r\nWe will send the $150 for your services.\r\n\r\nIBM', '2009-04-08 15:06:22', 'n'),
(33, 51, 47, 'Funding', 'We have acquired more funding.  Send us proposals ASAP.  ', '2009-04-08 15:06:27', 'n'),
(34, 54, 45, '', 'Just sent $750.\r\n\r\n-Congress', '2009-04-08 15:07:44', 'n'),
(35, 52, 50, 'Scanning Probe Micrscopy', 'Project Overview:\r\n  The researchers at Rice University are paving the way in the realm of new microscope technologies. We have already researched and mastered the use of basic electron microscopy, and wish to advance our knowledge and delve into researching scanning probe microscopy.\r\n\r\nScanning Probe Background:\r\n\r\n  Scanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position.\r\n  Benefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed.\r\n  Researching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Public greatly. Children born without limbs will hopefully be able to achieve some semblence of normalcy in their lives thanks to our research.\r\n\r\nBusiness Relationship:\r\n\r\nPI will research C&F for Rice University.\r\n\r\n-Rice\r\n\r\n\r\nMission Objective::\r\n\r\nElectron Microscopy --> hierarchical self-assembly --> nano-scaffolds -->regenerated tissues --> bionic prosthesis\r\n\r\npolymers --> block co-polymer lithography -->hybrid devices --> wearable computers --> bionic prosthesis\r\n\r\nAs well as spectroscopy and scanning probe microscopy', '2009-04-08 15:08:59', 'n'),
(36, 47, 51, 'Risk', 'We have sent money to WWIC to reduce risk, hopefully that will show up soon.', '2009-04-08 15:13:08', 'n'),
(37, 54, 51, 'Risk', 'Were you able to figure out where we stand on the risk level?', '2009-04-08 15:15:32', 'n'),
(38, 46, 53, 'TAKE THIS SURVEY BY END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:18:25', 'n'),
(39, 47, 53, 'TAKE THIS SURVEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:18:44', 'n'),
(40, 48, 53, 'TAKE THIS SURVEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:18:55', 'n'),
(41, 49, 53, 'TAKE THIS SURVEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:19:10', 'n'),
(42, 50, 53, 'TAKE THIS SURVEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:19:21', 'n'),
(43, 51, 53, 'TAKE THIS SURVEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:19:41', 'n'),
(44, 52, 53, 'TAKE THIS SURVEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:19:54', 'n'),
(45, 54, 53, 'TAKE THIS SURBEY BY THE END OF CLASS MONDAY!', 'http://www.surveymonkey.com/s.aspx?sm=5l4nU82H0a_2byARTWcUHFEw_3d_3d', '2009-04-08 15:20:07', 'n'),
(46, 45, 47, 'New Mission Statement', 'To fund basic research that works towards peaceful applications of technology to societal problems in a way that does not pose significant risk to humans or the environment.', '2009-04-08 15:33:18', 'n'),
(47, 49, 54, 'Current Risk Rating', 'Just to let you guys know-- your current risk rating is a 71.  The scale is as follows:\r\n\r\n70 and below: poor\r\n71-90: good\r\n91+: excellent\r\n\r\nYou are one point away from a "poor" rating.', '2009-04-13 14:09:48', 'n'),
(48, 48, 54, 'Current Risk Rating', 'Just to let you guys know-- your current risk rating is a 64.  The scale is as follows:\r\n\r\n70 and below: poor\r\n71-90: good\r\n91+: excellent\r\n\r\nIn order to receive funding and public approval, you need to improve your risk rating!  You are 7 points away from a "good" rating.', '2009-04-13 14:10:45', 'n'),
(49, 48, 45, 'Risk Rating Congressional Hearing', 'NASA,\r\n\r\nDue to the extent of your poor risk ratings, we are calling a congressional hearing to discuss the implications, consequences and actions necessary. Please report to Congress immediately.\r\n\r\nSincerely,\r\n\r\nCongress', '2009-04-13 14:12:06', 'n'),
(50, 51, 54, 'Current Risk Rating', 'Just to let you guys know-- your current risk rating is a 65.  The scale is as follows:\r\n\r\n70 and below: poor\r\n71-90: good\r\n91+: excellent\r\n\r\nIn order to get funding and public approval, you need to improve your risk rating!  You are 6 points away from a "good" rating.  ', '2009-04-13 14:12:27', 'n'),
(51, 51, 45, 'Risk Rating Congressional Hearing', 'IBM,\r\n\r\nCongress is taking note of your poor risk ratings. As legislators for the good of the people, we will not tolerate poor risk management of nanotechnology.\r\n\r\nWe are calling a congressional hearing to discuss the implications, consequences and actions necessary. Please report to Congress immediately.\r\n\r\nSincerely,\r\n\r\nCongress', '2009-04-13 14:14:26', 'n'),
(52, 50, 54, 'Your Current Risk Rating', 'Dear RICE,\r\nyou are currently at a risk rating of 75.  The scale goes as follows:\r\n\r\n70 and below:  Poor\r\n71-90:  Good\r\n91+ :  Excellent\r\n\r\nYou are only 5 points away from a poor rating.  I think in light of thinking ahead, it is time you start thinking about improving your risk rating.  Once improved, it will become much easier for you to win funding from Congress, DARPA, and the NSF.  Also, an improvement will make you the only organization with an "excellent" rating.  \r\nHope to hear from you soon. \r\n\r\nWWIC', '2009-04-13 14:16:23', 'n'),
(53, 52, 54, 'Your Current Risk Rating', 'Dear PI,\r\nyou are currently at a risk rating of 80.  The scale goes as follows:\r\n\r\n70 and below:  Poor\r\n71-90:  Good\r\n91+ :  Excellent\r\n\r\nYou are only 10 points away from an excellent rating.  I think in light of thinking ahead, it is time you start thinking about improving your risk rating.  Once improved, it will become much easier for you to win funding from Congress, DARPA, and the NSF.  Also, an improvement will make you the only organization with an "excellent" rating.  \r\nHope to hear from you soon. \r\n\r\nWWIC', '2009-04-13 14:17:25', 'n'),
(54, 55, 54, 'Improved Risk Mitigation Expertise', 'WWIC is pleased to announce that we have finally purchased Moderate Risk Mitigation Expertise. We are better equipped now for any type of risk forecast, detection and mitigation. \r\nHey what are you waiting for, Go for it.\r\nCharge is $250\r\n\r\nWWIC', '2009-04-13 14:29:11', 'n'),
(55, 45, 51, 'Risk Reduction', 'We are currently asking both NSF and DARPA for money specifically for risk reduction money.  We are concerned about our risk rating and are doing anything to reduce it.\r\n\r\nWe are working on it\r\n\r\nIBM', '2009-04-13 14:30:13', 'n'),
(56, 48, 53, 'Your research and risk ratings', 'NASA,\r\nIt has come to our attention that you are investing time and money into many different research endeavors.  Last Wednesday, you started 3 different kinds of research within about 1.5 hours.  We are just concerned because the risk ratings for all of them are poor, and we think that you should try to bring up your risk ratings for one instead of having lots of poor research being conducted.  We strongly suggest that you change your standards of research.\r\n\r\nETC', '2009-04-13 14:31:27', 'n'),
(57, 53, 48, 'NASA''s Risk Rating', 'Due to lack of funding, Wilson could not offer better risk management above the lowest level. Because of this our risk rating lowered and did not improve. However, on the technology proposals we submitted last Wednesday, we purchased the risk management package available. The other technologies shown were shared with IBM and are not a reflection of our risk rating.\r\n\r\nWilson has recently received the funds to offer better risk management and we are committed to purchasing the highest package from now on.', '2009-04-13 14:39:32', 'n'),
(58, 46, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:40:24', 'n'),
(59, 47, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:40:33', 'n'),
(60, 48, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:40:40', 'n'),
(61, 49, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:40:49', 'n'),
(62, 50, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:40:57', 'n'),
(63, 51, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:41:04', 'n'),
(64, 52, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:41:13', 'n'),
(65, 54, 53, 'TAKE THIS NOW!', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 14:41:23', 'n'),
(66, 55, 53, 'CORRECTION', 'Due to technical difficulties, we were unable to receive the results of the last poll.  Please, take the poll sent out to individual groups ASAP, before this class period ends!!!  Thanks.', '2009-04-13 14:42:05', 'n'),
(67, 51, 47, 'Funding ', 'What is the news with funding from DARPA.  Has your research towards Co-block assembly been completed, or do you still require funding for that.  Also, how is the risk management going?\r\n\r\nNSF', '2009-04-13 14:42:17', 'n'),
(68, 45, 53, 'Survey', 'We issued a poll for the priorities you mentioned, and we will send you the results soon.\r\n\r\nRegards,\r\nETC', '2009-04-13 14:42:37', 'n'),
(69, 53, 49, 'Survey', 'Please elaborate on this survey. What is it for? What will it be used for? Are we anonymous?', '2009-04-13 14:42:58', 'n'),
(70, 49, 53, 'survey', 'Yes, the survey is anonymous.  As ETC, we wanted to make a survey that represented what the public was interested in.  Please do not take this survey as a MIT member but as yourself.\r\n\r\nThanks', '2009-04-13 14:44:30', 'n'),
(71, 46, 48, 'Assembled Quantum Dots not Lithographic Self-Assembly\r\n', 'In out last proposal we had it titled Lithographic Self-Assembly it should have been Assembled Quantum Dots as that is our next step.  Any funding you can give us for this research will be greatly appreciated as we try to stay competitive in this market.', '2009-04-13 14:44:35', 'n'),
(72, 47, 51, 'Funding', 'We have no idea about the funding from DARPA.  We haven''t been able to start co-polymers because no funding has come thru. All we have heard is that congress has been holding up funding.  We still need money both for risk reduction and research.  But so far we haven''t heard from DARPA if we are getting money from them\r\n\r\nIBM', '2009-04-13 14:45:13', 'n'),
(73, 54, 51, 'Risk Rating', 'Is there anyway ya''ll can let us know what our current rating score is?', '2009-04-13 14:49:03', 'n'),
(74, 51, 52, 'Scanning Probe Microscopy Research', 'Dear IBM,\r\n\r\nIt has come to our attention that you have independently developed and shared our patented research in Scanning Probe Microscopy. Normally, this situation would lead to unpleasantness for all concerned. However, we are willing to overlook your and NASA''s illicit possession of our patented research if you are willing to agree:\r\n1) It is indeed the property of Prometheus Industries and\r\n2) IBM and NASA agree to refrain from further sharing the research.\r\n\r\nSincerely,\r\nPrometheus Industries', '2009-04-13 14:54:00', 'n'),
(75, 48, 52, 'Scanning Probe Microscopy Patent\r\nCC: NASA', 'Dear IBM,\r\n\r\nIt has come to our attention that you have independently developed and shared our patented research in Scanning Probe Microscopy. Normally, this situation would lead to unpleasantness for all concerned. However, we are willing to overlook your and NASA''s illicit possession of our patented research if you are willing to agree:\r\n1) It is indeed the property of Prometheus Industries and\r\n2) IBM and NASA agree to refrain from further sharing the research.\r\n\r\nSincerely,\r\nPrometheus Industries', '2009-04-13 14:54:38', 'n'),
(76, 55, 47, 'Clarification', 'The NSF was aware of the funds transfer from DARPA to IBM before it took place.  Before learning of this impending transaction out intention was to allocate the bulk of our funding to IBM, but upon learning of their alternate source of funds we decided it was more prudent to allocate more funds to NASA instead.  We were not ignorant of the goings on as your article stated.\r\n\r\nNSF', '2009-04-13 15:07:14', 'n'),
(77, 55, 53, 'ONCE AGAIN', 'http://www.surveymonkey.com/s.aspx?sm=8KekNs_2bL4dxDsXC3zxQjXg_3d_3d', '2009-04-13 15:08:40', 'n'),
(78, 49, 50, 'Research', 'This is just to clear up any confusion that we might have able our deal.  Rice University will conduct research to get the nano-scaffolds prototype.  MIT will conduct research to get the Osteoconductive Materials prototype.  Once these two prototypes have been earned, MIT and Rice will share prototypes with each other.  This is in the common interest of the two groups.\r\n\r\nRice\r\n', '2009-04-13 15:09:34', 'n'),
(79, 45, 48, 'NASA''s Risk Rating', 'Our risk rating is currently at 68, just 3 points below a "good" rating. We sent in a research proposal and purchased the highest risk management package, which brought us up to 68. Now we''re waiting for Wilson to increase their risk package to level four, as we''re interested in researching a level four technology.', '2009-04-13 15:14:47', 'n'),
(80, 45, 47, 'Mission Statement', 'To fund basic research that works towards peaceful applications of technology to societal problems in a way that does not pose significant risk to humans or the environment.\r\n\r\n\r\nNSF', '2009-04-13 15:17:51', 'n'),
(81, 48, 51, 'Congress Elections', 'Is anyone is your group planning on running?  I think from our group, Dylan Hooe, is thinking of running. He would run with the idea being once in Congress, he will pound money into our two groups.  Let me know what you think.', '2009-04-15 14:06:39', 'n'),
(82, 49, 51, 'Graphene Transistors', 'When are you getting this?  Also, from where is the funding coming?', '2009-04-15 14:10:51', 'n'),
(83, 51, 49, 'graphene transistors ', 'congress is in the process of giving DARPA funds which will be funneled to us. will give update shortly ', '2009-04-15 14:14:04', 'n'),
(84, 51, 48, 'Congress Elections', 'IBM-\r\n\r\nI dont think anyone from our group is interested in running, but we will support your candidate if you are planning on helping us!\r\n\r\nNASA', '2009-04-15 14:14:11', 'n'),
(85, 48, 54, 'Current Risk Rating', 'Just to let you guys know, your current risk rating is 68.  A score of 71 would move you up to ''good.''', '2009-04-15 14:17:20', 'n'),
(86, 49, 54, 'Current risk rating', 'Just to let you know, your current risk rating is a 71.  This is the lowest possible score you can have to maintain a ''good'' rating.  70 and below is ''poor.''  ', '2009-04-15 14:18:29', 'n'),
(87, 51, 49, 'holla', 'funds received. currently beginning research.', '2009-04-15 14:18:30', 'n'),
(88, 54, 49, 'risk rating', 'hello,\r\n\r\nwhat is our current risk rating? \r\n\r\nRegards,\r\nMIT', '2009-04-15 14:20:12', 'n'),
(89, 50, 54, 'current risk rating', 'Just to let you guys know, your current risk rating is a 75.  If you drop to a 70, your risk rating will drop to ''poor.''  If you hire us, you will become close to a score of ''excellent'' and no one has reached this level yet.  This will make you stand out!', '2009-04-15 14:20:55', 'n'),
(90, 52, 54, 'current risk rating', 'Just to let you guys know, your current risk rating is an 81.  You guys are only 10 points away from an ''excellent'' rating.  No one has reached this level yet, and it would make you stand out!  It would certainly help with getting research approved.  \r\n\r\nNote: You guys are the closest out of any group, as of now, to reaching the highest level of rating.  ', '2009-04-15 14:22:21', 'n'),
(91, 55, 54, 'RICE Undertaking Research without any risk mitigation', 'It seems that Rice University is undertaking research without proper risk mitigation. Each stakeholder in research has to be responsible to the public and future generations which obviously, does not apply to Rice now.', '2009-04-15 14:22:25', 'n'),
(92, 51, 54, 'current risk rating', 'Just to let you guys know, your current risk rating is a 75.  If you drop to a 70, your rating will drop to a ''poor.''  ', '2009-04-15 14:23:22', 'n'),
(93, 45, 54, '', '', '2009-04-15 14:23:23', 'n'),
(94, 55, 53, 'Public Survey Results', 'http://img106.imageshack.us/img106/2205/resultsofsurvey.png\r\n\r\nhttp://img14.imageshack.us/img14/6071/surveycomments.png', '2009-04-15 14:24:42', 'n'),
(95, 45, 54, 'Rice University', 'Dear Congressmen/women,\r\nIt seems that Rice University is conducting their researches without proper risk mitigation. This will be quite detrimental to the public and future generations. With elections in the horizon, this might tarnish the image of all political establishments including the Congress.  ', '2009-04-15 14:25:03', 'n'),
(96, 45, 54, 'Upcoming election!', 'Hey Congress,\r\nThis is to let you know that you can assume full support from WWIC regarding this upcoming election.  If there''s anything you think we can do in terms of campaign or whatever, feel free to communicate.  \r\nGood Luck, and God Speed !! ', '2009-04-15 14:25:49', 'n'),
(97, 52, 50, 'Hierarchical Self-Assembly ', 'Hierarchical self-assembly, also known as hierarchical self-organization, is non-covalent organization of individual building blocks are formed over distinct and multiple levels. This tool allows for greatly increases the flexibility and adaptability of a material. The whole entire structure typically behaves much different then the individual building blocks and levels.\r\n\r\nWith this technology, we can improve the efficiency and survivability of our bionic prostheses.  Nanomachines inside the limbs could administer endorphins, platelets, and medicine as needed.', '2009-04-15 14:27:53', 'n'),
(98, 49, 54, 'Thank you for your purchase! ', 'Risk shall be mitigated !! ', '2009-04-15 14:30:02', 'n'),
(99, 51, 54, 'Thank you for purchase', 'Risk shall be mitigated !! ', '2009-04-15 14:30:31', 'n'),
(100, 47, 51, '$350 Risk Mitigation Funds', 'NSF,\r\n\r\nPlease allocate $350 for the risk mitigation services from WWIC.  As mentioned in our previous meeting, we have a contractual obligation to send those funds to WWIC and we were cut short of this money during our proposal funding.\r\n\r\nThank you,\r\nIBM', '2009-04-15 14:31:53', 'n'),
(101, 49, 51, '', 'How is everything coming along with your research?  We are just finishing up researching hybrid devices and are ready to start putting the funds together to research wearable computers with you guys.\r\n\r\nWhat you status?\r\n\r\nIBM', '2009-04-15 14:33:26', 'n'),
(102, 50, 48, 'Cooperation with NASA', 'We regret to tell you that after discussion NASA has decided to hold off on sharing block co-polymer lithography as we are already working on level three and four research. If circumstances change, we will let you know immediately.\r\n\r\nAdditionally, we are not interested in researching hierarchical self assembly as it also does not fit into our research goals.\r\n\r\nBest of luck,\r\n\r\nNASA', '2009-04-15 14:35:18', 'n'),
(103, 48, 51, 'Research', 'Are you still planning to share your assembled quantum dots in exchange for our hybrid devices?\r\n\r\nIBM', '2009-04-15 14:37:39', 'n'),
(104, 54, 45, 'Upcoming Campaign', 'WWIC,\r\n\r\nThank you for your generous support. We hope the manner in which we incorporated you closely in the nanotechnology process demonstrates are deep concern for the societal implications of nanotech reserach, i.e. funding you as best as we can to the next level. Please spread your humble opinion about our close communication and support for your mission as well.\r\n\r\nSincerely,\r\n\r\nCongress', '2009-04-15 14:41:12', 'n'),
(105, 55, 54, 'Awesome Congress', 'The present congress has been very responsible and prudent funding various researches. They have actively worked with WWIC to forecast, detect and mitigate risks concerned with any kind of research. Kudos to the present Congress and we wish them luck for the upcoming elections.', '2009-04-15 14:48:22', 'n'),
(106, 45, 54, 'This is what we sent to the NANOPOST', 'The present congress has been very responsible and prudent funding various researches. They have actively worked with WWIC to forecast, detect and mitigate risks concerned with any kind of research. Kudos to the present Congress and we wish them luck for the upcoming elections.', '2009-04-15 14:48:45', 'n'),
(107, 52, 54, 'Way to Go', 'Hey Hey Hey,\r\nYou are the only people who have an EXCELLENT risk rating. \r\nWWIC\r\n', '2009-04-15 14:52:00', 'n'),
(108, 55, 54, 'Risk Ratings', 'Just wanted to point out that only one group has reached the "Excellent" Risk Rating Level-- PI.  ', '2009-04-15 14:52:38', 'n'),
(109, 54, 51, 'RISK RATING', 'What will happen to our risk rating if we research the different levels of risk?  I.E....\r\n\r\nIf we pursue low risk mitigation, how much will the rating increase/decrease\r\nIf we pursue med. risk,.....\r\nIf we pursue high. risk,.......\r\n\r\nThank you WWIC.  WE LOVE YOU.', '2009-04-15 14:53:19', 'n'),
(110, 55, 52, 'Correction of P.I. bad press', 'this letter is to inform you of the false information you wrote on nanopost. \r\n\r\nFirst; We are not partners with any research company that researched scanning probe microscopy when we patented that technology\r\n\r\nsecond; the patent that we filed for scanning probe microscopy was part of the agreement we had with our investor. It was in our proposal and we are a company of integrity so we followed through with our word.\r\n\r\nthird; Will investors still show interest? our company just received a large amount of research money from an interested investor who is excited for our companies possibilities.', '2009-04-15 14:54:42', 'n'),
(111, 55, 53, 'NANO-CRISIS!', 'A company located in China, working with fabrication of flat screens that used block co-polymer lithography, had a device that catastrophically malfunctioned.  Unforeseen magnetic properties of the used nano-particles caused unsafe overexposure to users to magnetic radiation.  As a consequence, the victims are currently suffering from an array of ailments such as premature loss of hair, skin necrosis, and other side effects are still unknown.  The nanotechnology community has taken a huge blow, affecting any labs researching block co-polymer lithography and nanowire assembly.  Any lab dealing with block co-polymers and any technology deriving from it must cease immediately, pending further safety investigations.  Any labs incorporating nanowires will have their risk levels substantially affected.  \r\n\r\n\r\nPlease post with this image:\r\nhttp://www.etcgroup.org/upload/gallery/89/02/cartoon100.jpg', '2009-04-15 15:03:12', 'n'),
(112, 48, 45, 'Nano Crisis', 'Please return all funds to NSF/DARPA relying copolymers nand nanowire immediately!', '2009-04-15 15:09:22', 'n'),
(113, 51, 45, 'Nanocrisis', 'Please return all funds to NSF/DARPA relying copolymers nand nanowire immediately!', '2009-04-15 15:09:37', 'n'),
(114, 51, 47, 'RE:$350 Risk Mitigation Funds', 'We find your claims of the contractual obligation of $350 to WWIC to be fallacious, and thus do not find it necessary to allocate you this funding.', '2009-04-15 15:10:48', 'n'),
(115, 55, 53, 'Congress', 'Amanda Reid, a member of ETC, will be running for Congress.  Help support her campaign!\r\n\r\n', '2009-04-15 15:13:57', 'n'),
(116, 52, 49, 'Bionic Prosthesis', 'At MIT, we are working towards bionic prosthesis. Amputees could soon be fitted with prosthetic limbs that enable them to regain their sense of touch thanks to these new devices. For example, a bionic arm is effectively controlled by one''s thoughts, as sensors attached to their chest pick up electrical cues from their rerouted arm nerves. For this, we need funding for gradient lithography, as well as risk assessment, which ends up being $2250. Thanks for your consideration.', '2009-04-15 15:14:30', 'n'),
(117, 46, 51, 'Nano-Crisis', 'In accordance with our plan, we started research on Graphene Transistors.  Three minutes into our research, the research failed due to the "nano-crisis" which occurred after our research. We think ETC is up to no good.  Due to this failure, we lost all of our money poured into the research ($3,350).  Just letting you, and everyone involved in the meeting know.  We may need to work out a new plan now.\r\n\r\n\r\n- Very sad IBM', '2009-04-15 15:14:42', 'n'),
(118, 47, 51, 'Nano-crisis', 'In accordance with our plan, we started research on Graphene Transistors.  Three minutes into our research, the research failed due to the "nano-crisis" which occurred after our research. We think ETC is up to no good.  Due to this failure, we lost all of our money poured into the research ($3,350).  Just letting you, and everyone involved in the meeting know.  We may need to work out a new plan now.\r\n\r\n\r\n- Very sad IBM', '2009-04-15 15:14:51', 'n'),
(119, 49, 51, 'Nano-crisis', 'In accordance with our plan, we started research on Graphene Transistors.  Three minutes into our research, the research failed due to the "nano-crisis" which occurred after our research. We think ETC is up to no good.  Due to this failure, we lost all of our money poured into the research ($3,350).  Just letting you, and everyone involved in the meeting know.  We may need to work out a new plan now.\r\n\r\n\r\n- Very sad IBM', '2009-04-15 15:14:59', 'n'),
(120, 48, 51, 'Nano-crisis', 'In accordance with our plan, we started research on Graphene Transistors.  Three minutes into our research, the research failed due to the "nano-crisis" which occurred after our research. We think ETC is up to no good.  Due to this failure, we lost all of our money poured into the research ($3,350).  Just letting you, and everyone involved in the meeting know.  We may need to work out a new plan now.\r\n\r\n\r\n- Very sad IBM', '2009-04-15 15:15:14', 'n'),
(121, 51, 49, 'yea...', 'well unfortunately they also shut down nanowire... which is the other path to graphene transistors... \r\n\r\n-oh well', '2009-04-15 15:16:57', 'n'),
(122, 55, 54, 'Excellent Risk Mitigation', 'WWIC is proud to announce that it has excellent risk mitigation expertise now. This recent improvement will help each and every company to detect and mitigate any kind of risk involved. \r\nSo, why wait, jump on the research and let us know, we''ll be more than happy to help you.\r\n', '2009-04-20 14:16:41', 'n'),
(123, 45, 55, 'Campaign Ad', 'If you would like to run an ad or send a message to the NanoPost readers, please email it to us ASAP.', '2009-04-20 14:22:49', 'n'),
(124, 53, 55, 'Amanda Reid', 'If you would like to run an ad or send a message to the NanoPost readers, please email it to us ASAP.', '2009-04-20 14:23:07', 'n'),
(125, 51, 55, 'Kevin Hart', 'If you would like to run an ad or send a message to the NanoPost readers, please email it to us ASAP.', '2009-04-20 14:23:18', 'n'),
(126, 55, 53, 'AMANDA REID FOR CONGRESS', 'We need Reid!\r\n\r\nVote Amanda Reid for Congress - she can make the change you hope to see in the world.\r\n\r\nIt''s not that easy being green, but that''s a sacrifice she''s willing to take.\r\n\r\nhttp://img212.imageshack.us/img212/8678/funnyo.jpg\r\n\r\nA government block trying to cramp your style??\r\nShe always has the public in mind.  Working for ETC full-time, Amanda knows the ins and outs of the public eye and what needs to be done to make everyone happy.  \r\n\r\nAs Albert Einstein once said, "Yes, we have to divide up our time like that, between our politics and our equations. But to me our equations are far more important, for politics are only a matter of present concern. A mathematical equation stands forever."  This is how Amanda Reid plans to approach a Congressional position - methodically, intelligently, open-mindedly, and strategically.\r\n\r\nYes she can!\r\n', '2009-04-20 14:27:29', 'n'),
(127, 55, 54, 'Excellent Risk Mitigation', 'WWIC is proud to announce that it has excellent risk mitigation expertise now. This recent improvement will help each and every company to detect and mitigate any kind of risk involved. \r\nSo, why wait, jump on the research and let us know, we''ll be more than happy to help you.\r\n', '2009-04-20 14:30:37', 'n'),
(128, 55, 45, 'Congress re-election campaign', 'Ross is boss', '2009-04-20 14:36:02', 'n'),
(129, 52, 54, 'Refund', 'Do you want the $250 you sent us refunded to you or NASA?\r\n-WWIC', '2009-04-20 14:36:50', 'n'),
(130, 55, 45, 'Ted''s re-election', 'If you want to get ahead, vote for big Ted.', '2009-04-20 14:41:19', 'n'),
(131, 55, 45, 'Rita''s re-election campaign', 'Rita can''t be beata!', '2009-04-20 14:42:24', 'n'),
(132, 50, 47, 'Sharing Templated Self-Assembly', 'We need you to share your research on Templated Self-Assembly with IBM, as per our agreement to fund you, as soon as possible so that they may continue with the rest of their research.', '2009-04-22 14:07:21', 'n'),
(133, 51, 47, 'Funding', 'Congress now has additional funding.  As such, now would be a good time to submit proposals for whatever additional funding you need to complete your goals of Graphene Transistors and Wearable Computers.', '2009-04-22 14:16:41', 'n'),
(134, 55, 53, 'VOTE!', 'Amanda Reid for Congress.  Fervent. Dedicated. Just like a good pair of jeans, she''s the perfect fit!', '2009-04-22 14:18:57', 'n'),
(135, 52, 49, 'gradient lithography info..this was our funding proposal.', 'this is a copy of our funding proposal. it has some technical background information. if you need anymore, let us know.\r\n\r\nHere at MIT we are continuing on in our vision of a future with Bionic Prosthetics able to all who need them. To this end, we are requesting funding for research into Gradient Lithography. Gradient Lithography is the process of creating structures that are used in filtering things down to nano quantities. These structures are created by various lithographic processes, where a gradient is made to allow smaller and smaller quantities to pass through various stages, eventually moving from micro quantities into nano quantities. This type of separation will be integral in many of the filtering and more exacting processes in nano, with particular applicability to developing nano particles that will be of the correct size and quantity to serve as osteoconductive materials, used for bone growth scaffolding in the human body. This sort of improved human regenerative technology will be integral in the development of Bionic Prosthetics. Thus, we are requesting $2000 for the research, and an additional $250 for the risk mitigation research.', '2009-04-22 14:30:31', 'n'),
(136, 50, 54, 'YOU ARE EXCELLENT! ', 'CONGRATS.  YOU NOW HAVE EXCELLENT RATING!', '2009-04-22 14:40:53', 'n'),
(137, 49, 54, 'YOU ARE EXCELLENT! ', 'CONGRATS.  YOU NOW HAVE EXCELLENT RATING!', '2009-04-22 14:41:09', 'n'),
(138, 55, 53, 'URGENT!', 'April 22nd, IBM and NASA were offered the opportunity to release the block on co-polymers but rejected the offer.  This was their chance to show the public that they care about the risks at hand, but they did not.  \r\n\r\nAll these companies found ways around the block, but this is not a good thing!  They were told to send ETC a proposal to fix their risk to be able to continue, but they ignored the request and continued on.  \r\n\r\nThis block was supposed to be for everything that block co-polymers affected and thus any succeeding lines connected.  This was not the case, however, in order to allow the companies the chance of a solid proposal to ETC.\r\n\r\nNone of these companies should be trusted;  the public has refused to buy any products and has not only issued an economic blockade, but also they are boycotting.  These companies are not keeping the public''s best interest at hand, which should be the utmost priority.\r\n\r\nSevere consequences shall follow.', '2009-04-22 14:43:01', 'n'),
(139, 49, 46, 'Funding for Regenerated', 'We''ve sent you money for regenerated tissues with the end goal of Bionic Prosthesis in mind.  We are a military agency with an objective to develop future military technologies.  After bionic prosthesis, we would like you to work with IBM, who has energy independent devices, to develop an assitive exoskeleton to produce supersoldiers.  These soldiers, equipped with the exoskeleton, need to be able to jump higher, run faster, and carry bigger loads.', '2009-04-22 14:43:07', 'n'),
(140, 51, 46, 'Super Soldiers', 'IBM,\r\n\r\nWe''ve sent you money in the past that helped bring you to Energy Independent Devices.  We are a military agency with an objective to develop future military technologies.  After you and MIT get Bionic Prosthesis, we would like you to work with MIT to develop an assistive exoskeleton to produce supersoldiers.  These soldiers, equipped with the exoskeleton, need to be able to jump higher, run faster, and carry heavier loads.\r\n\r\nLove,\r\nDARPA\r\n\r\n', '2009-04-22 14:45:34', 'n'),
(141, 45, 53, 'Follow-up!', 'Do the ends justify the means?  \r\n\r\nIBM and NASA are on a race to the finish!  Who shall win the GRANNNNDDD CHALLLEENNNGEEE??\r\n\r\nWho cares about the middle man and the risks involved??  As long as they win, right?', '2009-04-22 14:47:18', 'n'),
(142, 55, 47, 'Two Grand Challenges Funded By NSF', 'Within a few minutes, research will be completed on the second Grand Challenge technology directed and funded by the NSF.  ', '2009-04-22 14:48:15', 'n'),
(143, 55, 53, 'IBM', 'IBM is working with ETC to fix the issues at hand.  Further updates to come.', '2009-04-22 14:53:01', 'n'),
(144, 55, 48, '', 'Can you post something to this effect on NanoPost?\r\n\r\n\r\nIn response to ETCs previous accusation:\r\n\r\nNASA did not continue on a path that required block  co-polymers. To reach hybrid devices, either block co-polymers OR templated self assembly was needed. NASA elected to research a different path that included templated self-assembly to bypass the block rather than appeal to ETC.\r\n\r\n', '2009-04-22 14:53:59', 'n'),
(145, 53, 51, 'Co-block Polymers', 'IBM is currently in possession of co-block polymer research, a research that caused the nano-crisis.  In order to help make this technology safer, we are sending $500 to WWIC to help improve the risk associated with the technology.  In addition, we have found ways to reach our grand challenges with out using co-block polymers.  This way we are making use that our current grand challenge research is as safe as possible.  Also, we have mitigated risk on all our resent research and have achieved and excellent risk rating score.\r\n\r\nThank you for giving us the opportunity to make co-block polymers safer.\r\n\r\nIBM', '2009-04-22 14:58:42', 'n'),
(146, 55, 53, 'ETC Clarifies', 'The ETC has never had any money throughout this whole simulation.  To suggest that giving us money will make us look the other way is ignorant.  The ETC represents the public, so how do you think it looks when you see that NO labs cared to even talk to us about what has been going on in their labs and what safety measures are necessary to prevent a catastrophe from happening again?  (And in reality, we only asked for a TWO sentence "proposal" from each lab)\r\n\r\nWhen we received no proposals from any lab, we then took it upon ourselves to talk to IBM and NASA (labs that originally were researching block co-polymer lithography)  about getting this block lifted from this research, but neither cared because they had already bypassed that technology and were going to reach their end goals.  Not having anyone remotely interested in talking about safety in labs and preventing risk does not look good to the public at all.  \r\n\r\nAfter we talked to WWIC, this is when we spoke to Congress and went to the media for help.  Now, IBM has spoken to us about lifting the ban around safety issues for block co-polymer lithography, and MIT has also spoken to us about safety in their labs.  This is all that ETC wanted; getting involved with the labs to make nanotechnology safe while keeping  the public informed.', '2009-04-22 15:03:48', 'n'),
(147, 53, 45, 'On the spot award', 'ETC,\r\n\r\nCongress is impressed with the risk mitigation your group has worked out with the nanotechnology labs.  This type of work is crucial to the betterment of nanotechnology products and Congress values your group''s work in ensuring that the nanotechnology industry thrives.  Please use this $1000 to continue in your research.\r\n\r\nRegards,\r\nCongress', '2009-04-22 15:05:09', 'n'),
(148, 50, 47, 'Neural Implant Funding', 'If you submit us a proposal quickly, we can get funding from congress to fund you for Neural Implant.', '2009-04-22 15:11:14', 'n'),
(149, 50, 47, 'Neural Implant Funding', 'If you submit us a proposal quickly, we can get funding from congress to fund you for Neural Implant.', '2009-04-22 15:11:28', 'n');
INSERT INTO `mail` (`mail_id`, `to_group`, `from_group`, `subject`, `message`, `sent`, `unread`) VALUES
(150, 55, 53, 'Congrats to IBM!', 'IBM has gotten the block lifted for them to use block co-polymers, if/when needed, and they have the sole rights to this technology.  IBM was concerned with how the public felt about them and the risks at hand.  There was miscommunication at first, but such dilemmas have been cleared up.  Feel free to go to IBM; they seem to be the only ones to really trust!\r\n\r\nOn a side note, MIT was concerned with the public, but did not know how to go about fixing this problem.  MIT cares.\r\n\r\nNASA officially achieved the grand challenge of energy-independent devices.  Too bad the public has boycott NASA''s technologies and refuse to give them any money.  Maybe if they would have cared about the public all along - or about the dangers of technologies along the way - they would have gone to ETC with their proposals.  NASA is not to be trusted.  But, they have reached the grand prize!! oh.. I mean challenge... \r\n\r\nFor those of you bashing ETC, you really shouldn''t shoot the middle man... especially when the middle man is your only hope to the finish line.', '2009-04-22 15:13:02', 'n'),
(151, 46, 55, 'Our Money', 'Can we get our 3 dollars back', '2009-04-22 15:13:21', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `missions`
--

CREATE TABLE IF NOT EXISTS `missions` (
  `mission_id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `cost` float NOT NULL default '0',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `built` datetime NOT NULL default '0000-00-00 00:00:00',
  `launched` datetime NOT NULL default '0000-00-00 00:00:00',
  `finished` datetime NOT NULL default '0000-00-00 00:00:00',
  `result` enum('success','failure') NOT NULL default 'success',
  `result_message` varchar(255) NOT NULL default '',
  `stage` enum('ready','built','launched','completed') NOT NULL default 'ready',
  `duration` float NOT NULL default '0',
  `built_begun` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`mission_id`),
  UNIQUE KEY `mission_id` (`mission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `missions`
--


-- --------------------------------------------------------

--
-- Table structure for table `nanopost`
--

CREATE TABLE IF NOT EXISTS `nanopost` (
  `nanopost_id` int(32) NOT NULL auto_increment,
  `class_id` int(32) NOT NULL default '0',
  `writer` varchar(255) NOT NULL default '',
  `subject` text NOT NULL,
  `body` longtext NOT NULL,
  `post_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`nanopost_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='nanopost articles' AUTO_INCREMENT=77 ;

--
-- Dumping data for table `nanopost`
--

INSERT INTO `nanopost` (`nanopost_id`, `class_id`, `writer`, `subject`, `body`, `post_date`) VALUES
(1, 91, 'Weather', '', 'Weather for Charlottesville, Virginia:\r\n<BR>Tuesday, April 7th: Windy with a high of 48. Partly cloudy.\r\n<BR>\r\n<BR>Wednesday, April 8th: Partly cloud with a high of 57. Much nicer.\r\n<BR>\r\n<BR>Thursday, April 9th: High of 65. Plenty of sunshine!', '2009-04-06 14:34:25'),
(2, 91, '', 'Lv2 Toolkit Research', 'NSF is currently soliciting proposals for level two toolkit research. Please submit your proposal directly to the NSF and include amount requested. In the proposal include research plan from toolkit to grand challenge.', '2009-04-06 14:35:45'),
(3, 91, 'Bryce Turner', 'Nano Buzz Ticker', 'April 6, 2009 14:30:  Congress will hold hearings soon with DARPA and NSF to review mission statements and come up with Grand Challenges they would most like to see be met.  The Congress currently has $3,000 they will appropriate to the funding agency they feel will most accurately reflect their ideas.', '2009-04-06 14:37:46'),
(4, 91, 'Dex Smalls', 'Dear Diary', 'Today I woke up and slid out from in between my nano-sheets and stepped onto my nano-carpet. I slipped into my nano-silver slippers and shuffled down my hall dimly lit by my new nano-filament lightbulbs. I opened a box of enriched nano-wheat cereal and poured in the recently FDA approved nano-milk. De-nano-licious.\r\n<BR>\r\n<BR>As nanotechnology pervades our society we''re charged with informing you, the people, of the ever changing ethical climate associated with the worlds newest buzzword: nano.\r\n<BR>\r\n<BR>There''s plenty of room at the bottom, and we''ll be reporting the whole way. Expect the best from us here at the NANOPOST', '2009-04-06 14:39:03'),
(5, 91, 'Bryce Turner', 'Nano Buzz Ticker', 'April 6, 2009 14:49: MIT currently meeting with DARPA to discuss possible directions to research in order to receive funding.', '2009-04-06 14:51:49'),
(6, 91, '', 'DARPA request', 'Greetings from DARPA, your friendly neighborhood defense research organization! In order for funding proposals to be considered for approval, your proposal should advance defense technologies in one of the following areas: Sensory Enhancement, Biometric Nanoparticle Tracking, Bionic Prosthesis, or Energy Independent Devices. Please bear in mind that our funding is limited, and only those proposals that advance the state of military technology the most will be considered.', '2009-04-06 14:52:28'),
(7, 91, '', 'WWIC', 'We are Woodrow Wilson Project on Emerging Nanotechnologies. We provide you with expert services on risk reduction and mitigation. As you all know, a robust framework for risk management is a prerequisite for funding from the Federal Government, especially the National Science Foundation(NSF). Also, our trustworthy services will help you gain public approval. So, hey we can help you get the money you need for that research you have been planning for.\r\n<BR>\r\n<BR>-Woodrow Wilson Project on Emerging Nanotechnologies', '2009-04-06 14:53:07'),
(8, 91, '', 'NSF', 'The NSF has $1500 that no one wants????????', '2009-04-06 15:00:54'),
(9, 91, '', 'Dear Sheeple,', 'The United States Congress is looking to spearhead the global nanotechnology challenge. Nanotechnology offers great benefits to the average American, and it is of utmost importance that nanotechnology research is geared towards improving quality of life. The key concern when investigating the vast possibilities and applications of nanotechnology are the benefits to the American public.\r\n<BR>\r\n<BR>That being said, nanotechnology also implies a great risk, and it is the purpose of the U.S. government to protect its people. Defending against the baneful application of nanotechnologies and against unseen negative consequences are major goals of this Congress.\r\n<BR>\r\n<BR>We look forward to serving, you, the public.\r\n<BR>Sincerely,\r\n<BR>Congress', '2009-04-06 15:05:02'),
(10, 91, 'Dex Smalls', 'NSF Puzzled', 'Much like the pretty girl at the ball that all the boys are too nervous to ask to dance, the NSF is finding it hard to give their money away.  Man up, boys.', '2009-04-06 15:06:12'),
(11, 91, 'Bryce Turner', 'Nano Buzz Ticker', 'MIT is currently researching Chemical Vapor Deposition.\r\n<BR>', '2009-04-06 15:08:39'),
(12, 91, 'Dex Smalls', 'Communication Breakdown', 'IBM and PI, two private laboratories may have misused their appropriated funds.  Both organizations independently decided to invest in polymers without consulting one another.  A race to the finish or an unfortunate misadventure?\r\n<BR>\r\n<BR>More soon.', '2009-04-06 15:12:17'),
(13, 91, 'Bulletin', 'Keep the ETC in mind', ' 	To the Nanotechnology Community,\r\n<BR>\r\n<BR>We want to inform you that you need to keep ETC in mind when making decisions and putting forth ideas. Do not hesitate to message us with questions before acting out on anything, and make sure your risks are low or you will not be able to continue. As ETC exec, our primary concerns are the public and the amount of communication between the public and corporate is clear and thorough. The risk of nano should be presented to everyone openly and blatantly.\r\n<BR>\r\n<BR>Regards, ETC', '2009-04-06 15:14:21'),
(14, 91, '', 'Congress gives to DARPA', 'Congress has promised 1000 dollars to DARPA who intends to fund MIT''s plan to research prosthetic solutions of the future.Using ion etching, MIT plans to create improved neural prosthetic interfaces and high quality circuitry to advance bionic limbs for military and civilian use. Congress is pushing for more civilian applications, and DARPA will channel funding appropriately. ', '2009-04-06 15:14:32'),
(15, 91, '', 'Communication Breakdown Development', 'It appears that PI, although having researched polymers, does not have enough funds to patent their technology.  Could IBM beat them to the punch?', '2009-04-06 15:15:12'),
(16, 91, 'Bryce Turner', 'MIT funds', 'MIT is currently asking DARPA for $1400 for research.', '2009-04-06 15:16:01'),
(17, 91, 'NANOSPAM', 'Get That Hot Summer Bod Without Ever Leaving the Couch!', 'A recent breakthrough in Nanotechnology is making the outdoors obsolete!  NanoRub(TM), the newest product from Banana Boat, when applied to the skin permanently switches on the genes that produce melanin, the chemical that makes you look tan!  Never go pale again!  NanoRub(TM) has only been tested on trout, but what good is personal safety when you''re friendless and whiter than Larry Bird?  Buy your tube today and enjoy a summer day the easy way!\r\n<BR>\r\n<BR>* NanoRub may cause spontaneous leprosy', '2009-04-08 13:58:21'),
(18, 91, 'Dex Smalls and Bucky Sussex', 'NASA in the wading pool', 'Monday, each group began with a small chunk of money in their bank accounts with no strings attached to spend how they wished.  NASA, one such organization, began with enough money to start researching Optical Lithography but not enough to incorporate risk management into their investment.  Thinking that Optical Lithography was already a safe technology that didn''t require oversight, they dove in head first.  Now they''re finding that the pool was shallower than they thought.  NASA''s risk rating is currently the worst in the NanoSim and only time will tell if they can recompose themselves.', '2009-04-08 14:33:42'),
(19, 91, '', 'Polymer Research is Publicly Available', 'After a competitive race for patent on polymers between P.I. and DARPA funded IBM, no patents have been rewarded and the research is now publicly available.', '2009-04-08 14:42:45'),
(20, 91, 'Bucky Sussex', 'Nano Buzz Ticker', 'Nasa and IBM plan to work together to hopefully reach Energy Independentdevices.  The coalition appears to have the full support of the NSF.\r\n<BR>', '2009-04-08 14:43:56'),
(21, 91, 'Associated Press', 'P.I. , Young and Spry', 'Promethean Industries as an agile young upstart benefits from an increased speed of research.  If time is an issue, look to P.I. in a crunch.', '2009-04-08 14:44:19'),
(22, 91, '', 'Chemical Vapor Deposition', 'MIT has just received a patent for Chemical Vapor Deposition, on their way to researching the grand challenge of bionic prosthesis.  This appears to be a solid move given that PI has made polymers publicly available. Therefore, MIT already has the research needed for Graphene Transistors and are half way to Hybrid Devices.  As such, they are almost half way to the bionic prosthesis grand challenge.', '2009-04-08 14:51:11'),
(23, 91, 'Buckey Sussex', 'Need Risk Management Money?', 'Just ask DARPA.  Congress has made it pretty clear that Risk Management is very important during the research stage.  As such, groups like MIT have just gone up to DARPA asking for $50 for risk management costs and have been instantly approved.  With Congress looking down on NASA and IBM with their low Risk Ratings, its probably safe to talk to DARPA before researching.', '2009-04-08 14:51:26'),
(24, 91, 'Associated Press', 'Polymers Create a Sticky Simulation', 'The recent dissemination of polymer technology has caused a general downturn in the perception of risk across the simulation.  The government is noticeably absent from all of these transactions.  Will it take a catastrophe for them to see the need for involvement?  Write your congressmen if you want to see a change.', '2009-04-08 14:53:12'),
(25, 91, '', 'NSF has Monies', 'NSF is currently accepting proposals from research labs. Please address your research plan, both long term and short term. We also need to see how you plan on reducing the associated risk with any nanotechnology research. Do not forget to include the amount you are requesting.', '2009-04-08 15:10:15'),
(26, 91, 'Buckey Sussex', 'Nano Buzz Ticker', 'PI is currently meeting with Rice and MIT in hopes to create a business cooperation.  It appears that Rice has shown interest with Electron Microscopy research.', '2009-04-08 15:10:46'),
(27, 91, 'Dex Smalls', 'And with the closing bell..', 'I turned on the television this afternoon when I got home and flipped to the only channel I watch, the NanoNews.  The entire hour segment that I watched was consumed by a single subject, it was like Britney Spears shaved her head again.  The issue that so enraptured the network was IBM and NASA collaborating toward a mutual goal.  These two technology super-giants have been getting heat lately for their negligence toward the repercussions of their research and development.  Is this a new leaf that IBM and NASA are turning, or will they throw caution to the wind again?  Regardless, they''ve found funding, so let''s hope they''ve changed their ways.', '2009-04-08 15:14:57'),
(28, 91, 'NANOSPAM', 'Buy the NanoTweeter(TM)!', 'Ever see people whispering and wonder if they''re talking about you?  Ever been in a crowded party and have trouble hearing your friends?  Lip read no more!  Our product the NanoTweeter(TM) is a small earpiece that captures ambient noise, focuses the important bits, and amplifies them directly into your ear.  NanoTweeter(TM) fits discretely in your ear canal and is virtually invisible when inserted.  Buy the NanoTweeter(TM) today and finally understand what that guy at work who mumbles is saying!  Financing available!\r\n<BR>\r\n<BR>*NanoTweeter cannot be removed without completely removing ear.', '2009-04-13 14:13:05'),
(29, 91, 'Buckley Sussex', 'Rejected', 'No Media!!!! Nasa, NSF, and Congress currently engaging in closed door, no media talks.  What could they be up to?\r\n<BR>\r\n<BR><img src="http://www.cartoonstock.com/lowres/nbe0361l.jpg">', '2009-04-13 14:25:51'),
(30, 91, 'Associated Press', 'Bigger, Faster, Stronger', 'If we know anything about technology, it''s that it improves at an exponential rate according to Moore''s law.  Keeping in consideration that simulation time is accelerated relative to reality, research is taking an inexplicable amount of time.  If I were to make a prediction based purely upon the Moore''s model of technological improvement, I would say expect a jump in research efficiency imminently.', '2009-04-13 14:31:23'),
(31, 91, '', 'Congress'' Worries', 'Congress is hesitant to fund labs with poor risk ratings. Currently funding for DARPA and NSF is being withheld until the risk assessment procedures and costs are reported. Congress will no longer give money to poor risk investments. They are open for questions and interviews for further questions.', '2009-04-13 14:37:09'),
(32, 91, '', 'WWIC', 'The WWIC has recently upgraded their risk services to the Moderate Risk Mitigation Expertise. As such, WWIC is better equipped to forecast, detect and mitigate risk.  In addition, their increased skills will reduce the time needed for them to increase a lab''s poor risk ratings.  The new charge for their services is $250, and with Congress placing an increased focus on proposals that have specifics on how the labs intend to mitigate risk, now might be a good time for labs to take notice.', '2009-04-13 14:43:45'),
(33, 91, 'ETC', 'Technical Difficulties', 'Due to technical difficulties, we were unable to receive the results of the last poll. Please, take the poll sent out as an individual ASAP, before this class period ends!!! Thanks.', '2009-04-13 14:46:36'),
(34, 91, 'Buckey Sussex', 'Plently of Room at the bottom, but its nicer upstairs', 'NSF recently gave money to IBM and NASA.  The $600 given to IBM was immediately used to increase their risk rating from poor to good.  On NASA''s side, they plan to use their $2000+ just received towards research making sure they use risk management.  One NASA employee said this while talking to NSF, "We will never again research without risk management."\r\n<BR>\r\n<BR>IBM also received $2250 from DARPA concluding in a net gain of $2850 in under 5 minutes.  Neither DARPA nor NSF was aware that they were both giving money to IBM.\r\n<BR>\r\n<BR>EDIT: It appears the NSF was aware of the funds transfer from DARPA to IBM before it took place. As such they decided to allocate only a portion of their funds to IBM, and gave the rest to NASA.  It is interesting how the NSF keeps blindly throwing money at those labs that are take part in dangerous research.  Does the NSF really have our best interests at heart?', '2009-04-13 14:55:08'),
(35, 91, '', 'Scanning Probe Microscopy', 'PI has just patented Scanning Probe Microscopy and shared this technology with Rice University.  It is interesting that PI achieved the patent well ahead of IBM and NASA, even though the latter two had the research for much longer.', '2009-04-13 14:59:24'),
(36, 91, 'NanoInsider', 'Corruption in Ethics', 'WWIC, a prominent risk assessment firm, was given $600 by IBM for a service that only required a flat rate of $250.  Realizing the monetary discrepancy, WWIC failed to alert IBM to capitalize on their client''s mistake.  What kind of world do we live in today that organizations in charge of upholding ethics cannot conduct themselves ethically?', '2009-04-13 15:04:54'),
(37, 91, 'NanoBusiness', 'The New Face of IBM', 'IBM, a company plagued by a reputation for negligence in risk assessment, recently invested new funds to improve their introspection.  This is a new day for IBM, a superpower who''s only ailment has been remedied.  With the thorn pulled from their paw, only time will tell what this new IBM has in store.', '2009-04-13 15:10:50'),
(38, 91, 'Buckey Sussex', 'Scanning Probe Microscopy the new fad?', 'NASA and IBM seem to be in the middle of every contraversy.  This time it''s with P.I.  NASA researched Scanning Probe Microscopy and shared their research with IBM.  P.I. and Rice together as a business venture also researched Scanning Probe Microscopy but then patented their research.  Now anyone else wanting to use the research must go through P.I. but who does that leave?  MIT.  So MIT, if you''re looking at researching Scanning Probe Microscopy, I would advise against it.  But wait, you seem to already have the research as well.  So why did P.I. patent it?  Seems like a waste of funds in my book.', '2009-04-13 15:15:12'),
(39, 91, 'NanoInsider', 'Ethics is the new Black', 'WWIC, the victim of miscommunication has returned the excess money sent to them by IBM.  The NanoInsider would like to apologize for the inflammatory nature of the previous article pointing to any questionable ethics on the part of the WWIC.', '2009-04-13 15:16:03'),
(40, 91, 'NANOSPAM', 'Have a Nano?  Get a Mega!', 'A new product from Sequoia Labs is adding a swing to the step of men across America!  NanoCure(TM) is an all natural remedy for men who have drawn the short straw in life.  NanoCure(TM) uses a revolutionary carbon-nanotube infrastructure upon which your new skyrise will be constructed.  If you''re looking to add weight to your arguments and finally fit into that baggy pair of jeans in the back of your closet, buy NanoCure(TM) today!\r\n<BR>\r\n<BR>*NanoCure may indirectly cause back problems', '2009-04-15 14:10:21'),
(41, 91, 'Wahaahaaa', 'P.I. Teetering on the Edge', 'What is happening with P.I.? Once P.I. finally gets funding they waste it on patents their partners have already researched. If their upper management doesn''t get their act together soon their lab will fall tremendously behind and funding will be impossible to find. Firing current leaders and reorgnanizing their business plan could be their best option. But with their good risk rating, will investors still show interest? ', '2009-04-15 14:25:19'),
(42, 91, 'Associated Press', 'MIT:  The Well Has Run Dry', 'Monday, we didn''t hear a peep from MIT''s R&D department.  With no funds to speak of, MIT has been dead in the water, wasting precious time in this fast-paced NanoSim.  Grand challenges loom in the distance and we need communication and cooperation to reach them.  MIT''s illustrious reputation precedes it, but that does not mean that this prestigious organization can operate without a platform of financiers to stand on.  Invest in MIT.  Build it, and Grand Challenges will come.', '2009-04-15 14:29:58'),
(43, 91, 'Daily Insider', 'Hearing in Session', 'Congress is expecting a new stimulus package in the near future. They are currently in a hearing with DARPA and NSF to decide their plan of action for this new money and overall research goals. There will be intense competition when new funding arrives and research labs should be ready to align their action plans with Congress'' overall goals. ', '2009-04-15 14:33:09'),
(44, 91, 'Buckey Sussex', 'Little Interest in Changing of Guard', 'With reelections impending, who is going to run?  From initial reports, it seems that only five people plan to run.  Kevin McDonald from P.I. says he is interested but will do more research before officially deciding to run.  An IBM spokesperson informed NanoPost that they plan on having a candidate run for office although they are not sure who yet.  As for Congress, all three incumbents are running for reelection.  It seems that not many people exactly understand the inner workings of Congress.  "I don''t know exactly what Congress does," says one MIT employee.  Who else out there wants to run?', '2009-04-15 14:44:42'),
(45, 91, '', 'Recount', 'PI: 2 researched 2 received\r\n<BR>IBM: 3 researched 3 received\r\n<BR>Rice: 1 researched 3 received\r\n<BR>MIT: 2 researched 2 received\r\n<BR>NASA: 4 researched 3 received\r\n<BR>\r\n<BR>On one end, it appears NASA is being allowed to plow ahead with their research regardless of their poor risk rating? On the other, it appears Rice piggybacked on others to get their initial research done for them.', '2009-04-15 14:51:00'),
(46, 91, 'Anonymous', 'And The Results Are In!', 'The results to the survey that ETC badgered everyone to take are finally in. \r\n<BR>\r\n<BR>\r\n<BR>\r\n<BR><IMG SRC= "http://img106.imageshack.us/img106/2205/resultsofsurvey.png" HEIGHT="500" WIDTH="750">', '2009-04-15 14:52:15'),
(47, 91, 'Buckey Sussex', 'Nano Buzz Ticker', 'Congress met with Rice to remind them of their concern with Rice''s research with risk management.  Rice assured Congress they would no longer do any research without risk assessment.  Rice has remained silent with NanoPost with their goals but they did inform me that "the Rice Cooker is heating up."\r\n<BR>\r\n<BR>IBM was informed by WWIC that they are one point away from an excellent risk rating.  Impressive, seeing that not so long ago they were rated as poor and no other group has gotten an excellent rating yet.', '2009-04-15 14:55:11'),
(48, 91, 'Associated Press', 'The Cup Runneth Over', 'Today, Congress received $12,000 to appropriate to its subsidiaries in hopes to make the final push toward energy independence.  However, $15,000 is required to research these technologies with the appropriate risk management systems.  The grand challenge of energy independence seems finally attainable assuming that Congress is able to drum up the remaining funds.  We may be standing in the threshold of a new era.', '2009-04-15 15:03:29'),
(49, 91, 'ETC', 'NANO-CRISIS', 'A company located in China, working with fabrication of flat screens that used block co-polymer lithography, had a device that catastrophically malfunctioned. Unforeseen magnetic properties of the used nano-particles caused unsafe overexposure to users to magnetic radiation. As a consequence, the victims are currently suffering from an array of ailments such as premature loss of hair, skin necrosis, and other side effects are still unknown. The nanotechnology community has taken a huge blow, affecting any labs researching block co-polymer lithography and nanowire assembly. Any lab dealing with block co-polymers and any technology deriving from it must cease immediately, pending further safety investigations. Any labs incorporating nanowires will have their risk levels substantially affected.\r\n<BR>\r\n<BR><img src="http://www.etcgroup.org/upload/gallery/89/02/cartoon100.jpg">', '2009-04-15 15:04:42'),
(50, 91, '', 'Stimulus Package Plan', 'The funding from the new Stimulus Package has been determined. Congress has agreed to focus all funding on acheiving Energy Independent Devices. The three leading research labs (IBM, NASA, MIT) have designed an intricate deal to fund and share toolkits in order to build the Hybrid Devices, Graphene Transistors, and Assembled Quantum Nanodots. The plan to establish the Wearable Computers and Portable Photovoltaic techonologies in the near future. This plan is a big step to reach the grand challenge, but will all go as planned? Where are the smaller research labs in this plan? Where will they get funding? Is Congress putting all their eggs in one basket?', '2009-04-15 15:07:03'),
(51, 91, 'NANOSPAM', 'Nanopocalypse!!', 'THE END IS NIGH!  Recent research in the use of co-polymer lithography and nanowire assembly have uncovered earth-shattering consequences. Fill up your pantry with canned beans and powdered milk!  ', '2009-04-15 15:15:35'),
(52, 91, 'Buckey Sussex', 'NANO-CRISIS Development', 'Block co-polymer lithography now halted in research, NASA and IBM are in a major bind.  They also are no longer allowed to use any research that feeds on block co-polymer lithography.  This means they cannot use Hybrid Devices, Graphene Transistors , Wearable Computers, Retinal Implant, Neural Implant, Biomedic Hearing Aid, or Portable Photovoltiac.  This means NASA''s and IBM''s dream of Energy Independent devices have pretty much ended.  Other groups will clearly be affected and further information will be announced.  Clearly Congress has a lot on their hands while they rethink their goals and strategy.', '2009-04-15 15:16:17'),
(53, 91, 'Buckey Sussex', 'Extra Extra Read All About it', 'What everyone in the Nano community has feared has finally happened.  A company in China using nanotechnology had what ETC reported as "a device that catastrophically malfuncitoned."  The cause of the accident involved a fabrication unit using block co-polymer lithography.  Upon hearing this, President Gorman immediatly halted any research using and involved with block co-polymer lithography.  Any use of nanowire assembly has also been red-flagged  by the executive branch.  Senator Rod Wyden, D-Ore. accompained by Altaf H. Carim, Co-Chair of the Nanoscale Science, Engineering and Technology (NSET) Subcommittee and a team of Nano-engineers visited China on Friday to assess the situation. \r\n<BR>\r\n<BR>Research here at NanoPost shows that Energy Indepent Devices is not the only goal  affected by the incident.  Looking deeper we find that all goals are currently unachievable.  the following chart displays the affect of losing co-block polymers.\r\n<BR>\r\n<BR>Red - Researched halted/Technology blocked from usage\r\n<BR>Yellow - Researchable with higher risk\r\n<BR>\r\n<BR><img src="http://i724.photobucket.com/albums/ww246/WrightEngineer/crisis-1.jpg">\r\n<BR>\r\n<BR>Senator Rod Wyden returned earlier this morning and immediatly met with President Gorman with his findings.  NanoPost correspondant Dex Smalls is currently waiting for the press breifing and we will update our readers as soon as we get more information.  \r\n<BR>\r\n<BR>However, Friday afternoon a Washington insider informed Nanopost that President Gorman would consider further research into block co-polymer lithography.  The research itself would not however be reserved for IBM who initially had done it. So this brings up an interesting dilemma in the research community.  Should, let''s say Rice or even P.I. be the one in control of the research and patent, they would gain control of IBM, Nasa, and pretty much any other company''s future.  P.I. has a history of bad blood with IBM and MIT is not to fond of IBM either.  It shall be very interesting to see how the following course of events will take place.  \r\n<BR>\r\n<BR>Congress, who has not been mentioned yet in this article has a large task ahead of them.  Congress will obviously be in major meetings today with both the exectutive branch and funding agencies NSF and DARPA to see where they plan on going from here.  With the disaster this writer asks whether or not WWIC did their job?  IBM recently received an excellent risk rating and then a manufacturing plant using their technology had a major malfunction.  Congress clearly stated they wanted risk management used on all research and the WWIC provided the service.  But where was the oversight?  Obviously Congress was not there.  Is this the same Congress we want re-elected this upcoming election.  Whoever gets eleced or re-elected to Congress needs to deeply look into the risk managment process.  A strong candidate that was not prementioned is Amanda Reid from ETC.  She would bring much experience from working directly with the general public and working directly with Congress.  She might be just what Congress needs to get nanotechnology research back on track.\r\n<BR>\r\n<BR>\r\n<BR>NanoPost serves to inform our readers with up-to-date information and will inform you with any more delevopments during this Nano-Crisis and re-election period.', '2009-04-20 13:59:38'),
(54, 91, 'NANOSPAM', 'This week in NANOSPAM', 'New Revlon NanoBoost Lip Stick completes trial testing on animals.  Animals have reactions to the new product from Revlon, fortunately reaction is higher self-esteem.  pg. 14\r\n<BR>\r\n<BR>American Eagle releases line of Prom Dresses with intertwined liquid-resistant NanoFiber technology designed to withstand up to 3.5 solo cups of beer.  Girl from Tallahassee, FL jumps into backyard pool wearing NanoFiber dress, explodes.  pg. 22, obituaries\r\n<BR>\r\n<BR>Japan develops groundbreaking $3.8 billion (USD) robot using super-conductive NanoCopper wires.  Robot sets international DDR high score.  pg. 31\r\n<BR>\r\n<BR>NanoCure recalled due to unforeseen side-effects.  NanoCure causes growth not only in the bathingsuit area, but in entire body, an illness recently termed "Jabba the Hutt syndrome".  pg. 39\r\n<BR>\r\n<BR>Bruce Vilanch denies accusations of using recalled product, NanoCure.  pg. 40\r\n<BR>\r\n<BR>Embattled Nanotechnology opponents march on the National Lawn.  MaNanUre (TM) applied to grass next day.  National Lawn makes full recovery.  pg. 44\r\n<BR>\r\n<BR>Speedo developes prototype swimsuit "The Gilled Cheetah" using slipstreamed NanoGlide technology.  Swimsuit tested by creator''s four year old daughter shatters Michael Phelp''s record in the 200m freestyle.  pg. 48\r\n<BR>\r\n<BR>Take the new NanoQuiz!  Find out what Nano structure you are and see celebs who got the same results!  pg. 50\r\n<BR>', '2009-04-20 14:03:13'),
(55, 91, 'WWIC', 'Excellent!', 'WWIC is proud to announce that it has excellent risk mitigation expertise now. This recent improvement will help each and every company to detect and mitigate any kind of risk involved.\r\n<BR>So, why wait, jump on the research and let us know, we''ll be more than happy to help you.', '2009-04-20 14:19:05'),
(56, 91, 'Amanda Reid', 'Amanda Reid for Congress', ' 	We need Reid!\r\n<BR>\r\n<BR>Vote Amanda Reid for Congress - she can make the change you hope to see in the world.\r\n<BR>\r\n<BR>It''s not that easy being green, but that''s a sacrifice she''s willing to take.\r\n<BR>\r\n<BR><img src="http://img212.imageshack.us/img212/8678/funnyo.jpg">\r\n<BR>\r\n<BR>A government block trying to cramp your style??\r\n<BR>She always has the public in mind. Working for ETC full-time, Amanda knows the ins and outs of the public eye and what needs to be done to make everyone happy.\r\n<BR>\r\n<BR>As Albert Einstein once said, "Yes, we have to divide up our time like that, between our politics and our equations. But to me our equations are far more important, for politics are only a matter of present concern. A mathematical equation stands forever." This is how Amanda Reid plans to approach a Congressional position - methodically, intelligently, open-mindedly, and strategically.\r\n<BR>\r\n<BR>Yes she can!', '2009-04-20 14:30:49'),
(57, 91, 'The Editor', 'Vote for Congress-- Check Your Email ', 'Don''t forget to get your votes for congress in before the end of class. With IBM causing this Nano-crisis do you really want a member of their team in charge of YOUR future? ', '2009-04-20 14:35:53'),
(58, 91, 'Buckey Sussex', 'Resolution?', 'It appears that Congress may get the go ahead to bypass block co-polymer research.  The plan appears to be for research to go ahead on Templated Self-Assembly and then go directly to Hybrid Devices without block co-polymer lithography.\r\n<BR>', '2009-04-20 14:38:06'),
(59, 91, 'Congress', 'Congress Re-Election Platform', 'Ross is boss', '2009-04-20 14:40:03'),
(60, 91, 'Buckey Sussex', 'Updated Tech Tree', '<img src="http://i724.photobucket.com/albums/ww246/WrightEngineer/crissss.jpg">', '2009-04-20 14:52:14'),
(61, 91, '', 'Congress Election Results', 'The following have been elected to Congress:\r\n<BR>\r\n<BR>Kevin Hart (IBM)\r\n<BR>Ted Mayo (incumbent)\r\n<BR>Ross Gordon (incumbent)', '2009-04-22 14:07:12'),
(62, 91, 'Buckey Sussex', 'It''s Gooooood!', 'NASA has finally gotten rid of its poor risk rating.  It has now been redeemed to good.', '2009-04-22 14:17:15'),
(63, 91, 'NanoSleuth', 'The Shadow of a Threat', 'Over the weekend, some troubling news has been creeping through the intelligence community.  Sources point to the likely possibility of continued research in Block Co-polymer Lithography in the communist dictatorship of North Korea.  Labs and government organizations here in the United States have recognized the risk associated with this research and have acted appropriately.  Unfortunately, our regulations have no sway beyond our country.  It seems now that we''ve opened this can of worms, but now we''re unable to close it.  The fear is that North Korea is developing its nanotechnologies with the desire to harm others.  We must keep national security in mind even when developing technologies within the United States, because of the propensity for knowledge to leak outside our borders.  What good is the advancement of technology within our own country if it eventually leads to our downfall?  The answer is to think critically about the ethics of our actions and weight the pros and cons before barreling headfirst into the future.', '2009-04-22 14:26:58'),
(64, 91, 'Buckey Sussex', 'Grand Challenge Ho!', 'DARPA is calling out to all companies and researchers for funding proposals to reach the grand challenge of "Biometric Nanoparticle Tracking" or "Bionic Prosthesis."  DARPA currently has $4,000 to give towards the research of these grand challenges with more money expected soon from Congress.', '2009-04-22 14:32:43'),
(65, 91, 'Buckey Sussex', 'Defense Funding', 'Congress, worried with the growing situation with North Korea, has granted DARPA an additional $3900 for completing their goals.  This money with the $4000 will give a combined $7900 of funding for anyone pursuing "Biometric Nanoparticle Tracking" or "Bionic Prosthesis."', '2009-04-22 14:44:50'),
(66, 91, 'ETC', 'Severe Consequences', 'April 22nd, IBM and NASA were offered the opportunity to release the block on co-polymers but rejected the offer. This was their chance to show the public that they care about the risks at hand, but they did not. \r\n<BR>\r\n<BR>All these companies found ways around the block, but this is not a good thing! They were told to send ETC a proposal to fix their risk to be able to continue, but they ignored the request and continued on. \r\n<BR>\r\n<BR>This block was supposed to be for everything that block co-polymers affected and thus any succeeding lines connected. This was not the case, however, in order to allow the companies the chance of a solid proposal to ETC.\r\n<BR>\r\n<BR>None of these companies should be trusted; the public has refused to buy any products and has not only issued an economic blockade, but also they are boycotting. These companies are not keeping the public''s best interest at hand, which should be the utmost priority.\r\n<BR>\r\n<BR>Severe consequences shall follow.', '2009-04-22 14:45:09'),
(67, 91, 'The NanoPatriot', 'April Showers brings Grand Challenges', 'The day we thought may never arrive has become reality, we have achieved our first grand challenge!  America enters a new era of global dominance with the development of energy independent technologies.  ', '2009-04-22 14:55:58'),
(68, 91, 'Buckey Sussex', 'You Scratch My Back, I''ll Scratch Yours.', 'P.I. is currently sitting on "a bunch of money."  They, however, have no way to spend it for all their avenues for research are blocked.  P.I. is asking any group to share their research so that they can move forward with their own research and contribute to progress.  This is a great opportunity especially for groups like MIT and Rice who need a little help reaching the next Grand Challenge.', '2009-04-22 14:58:26'),
(69, 91, 'Buckey Sussex', 'Money Money Everywhere', 'WWIC has now received enough money to fund research besides just funding risk management.  Any company or research group who wants funding should send a proposal directly to WWIC.', '2009-04-22 15:01:27'),
(70, 91, '', 'A Grand Challenge(r) Appears', 'Within a few minutes, a second Grand Challenge, Bionic Prosthesis, will be completed by IBM.  The NSF and DARPA have funded and directed the laboratories in pursuit of this Grand Challenge.  With access to two Grand Challenges, America has truly cemented a globally dominant position well into the foreseeable future.', '2009-04-22 15:02:23'),
(71, 91, 'TIME', 'NASA''s Success!', 'NASA has achieved the grand challenge of Energy Independent Devices, and has released it to the public. Their plan to use this technology to improve handheld devices used by the general public. They are ecstatic about their success and their minds are running wild with the possibilites. When asked, they want to "make a cell phone that never has to be recharged and a gameboy that runs on sunlight." This amazing acheivement from NASA''s hard work will offer improvements to every aspect of our lives. ', '2009-04-22 15:02:50'),
(72, 91, 'ETC', 'ETC Announcement  ', 'The ETC has never had any money throughout this whole simulation. To suggest that giving us money will make us look the other way is ignorant. The ETC represents the public, so how do you think it looks when you see that NO labs cared to even talk to us about what has been going on in their labs and what safety measures are necessary to prevent a catastrophe from happening again? (And in reality, we only asked for a TWO sentence "proposal" from each lab)\r\n<BR>\r\n<BR>When we received no proposals from any lab, we then took it upon ourselves to talk to IBM and NASA (labs that originally were researching block co-polymer lithography) about getting this block lifted from this research, but neither cared because they had already bypassed that technology and were going to reach their end goals. Not having anyone remotely interested in talking about safety in labs and preventing risk does not look good to the public at all. \r\n<BR>\r\n<BR>After we talked to WWIC, this is when we spoke to Congress and went to the media for help. Now, IBM has spoken to us about lifting the ban around safety issues for block co-polymer lithography, and MIT has also spoken to us about safety in their labs. This is all that ETC wanted; getting involved with the labs to make nanotechnology safe while keeping the public informed.', '2009-04-22 15:05:41'),
(73, 91, 'ETC', 'ETC Update', 'IBM has gotten the block lifted for them to use block co-polymers, if/when needed, and they have the sole rights to this technology. IBM was concerned with how the public felt about them and the risks at hand. There was miscommunication at first, but such dilemmas have been cleared up. Feel free to go to IBM; they seem to be the only ones to really trust!\r\n<BR>\r\n<BR>On a side note, MIT was concerned with the public, but did not know how to go about fixing this problem. MIT cares.\r\n<BR>\r\n<BR>NASA officially achieved the grand challenge of energy-independent devices. Too bad the public has boycott NASA''s technologies and refuse to give them any money. Maybe if they would have cared about the public all along - or about the dangers of technologies along the way - they would have gone to ETC with their proposals. NASA is not to be trusted. But, they have reached the grand prize!! oh.. I mean challenge... \r\n<BR>\r\n<BR>For those of you bashing ETC, you really shouldn''t shoot the middle man... especially when the middle man is your only hope to the finish line.', '2009-04-22 15:14:15'),
(74, 91, 'Buckey Sussex', 'Faster, Stronger Military', 'Bionic Prosthesis has now been made public by MIT.  DARPA plans to use this research to create super soldiers for use in future conflicts.  Humanists in outrage have protested against any further research of nanotechnology or the use of the technology on humans.', '2009-04-22 15:15:23'),
(75, 91, '', '', '<img src="http://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/718smiley.svg/300px-718smiley.svg.png" />', '2009-04-22 15:16:49'),
(76, 91, 'NanUhOh', 'Tax Payers Riot', 'Today in Chicago, Houston, and New York citizens filled the streets enraged by the recent tax hikes.  The latest stimulus package, in a desperate attempt to reach grand challenges put many tax payers in a crunch and uncertain of how to meet their bills.  As the national debt soars and insufficient development of the grand challenges exists to justify the spending, the average person is having a hard time seeing the reason for the reduction in their paycheck.  This situation does not present an easy fix and is poised to become a national crisis.  Perhaps a new grand challenge is to quell the imminent uprising of the American tax payer.', '2009-04-22 15:16:59');

-- --------------------------------------------------------

--
-- Table structure for table `nanopost_comments`
--

CREATE TABLE IF NOT EXISTS `nanopost_comments` (
  `nanopost_comment_id` int(11) NOT NULL auto_increment,
  `nanopost_id` int(11) NOT NULL default '0',
  `writer` varchar(255) NOT NULL default '',
  `comment` longtext NOT NULL,
  `post_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`nanopost_comment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='nanopost comments' AUTO_INCREMENT=77 ;

--
-- Dumping data for table `nanopost_comments`
--

INSERT INTO `nanopost_comments` (`nanopost_comment_id`, `nanopost_id`, `writer`, `comment`, `post_date`) VALUES
(1, 1, 'Admin', 'Testing "quotes" and ''single quotes''', '2009-04-06 14:43:56'),
(2, 4, 'Nano Ted', 'I am fearful that nano-milk will make me sick! Why would the FDA approve such a thing? Somebody needs to do something about this. P.S. I love my nano-silver slippers, they are so comfy.', '2009-04-06 14:50:44'),
(3, 4, 'Farmer', 'Nano-milk has helped my stay afloat in the weak economy. Without the increased production, I would not be able to pay the bills and take of my family.  Not only that, but the FDA has tested and approved the milk, can we not them?', '2009-04-06 14:53:34'),
(4, 8, 'WWIC', 'We''ll take it', '2009-04-06 15:02:16'),
(5, 6, 'Fearful Neighbor', 'Friendly? Neighborhood?  You fund and perpetuate the idea of a massive military that needs massive funding from the government, pulling funding from the small research labs that are trying to peacefully solve the worlds problems, not make them worse!  I am disgusted with your bland, overly bigoted RP statment. ', '2009-04-06 15:05:09'),
(6, 8, 'Poor, Broke Bloke', 'Me! Me! I want it!', '2009-04-06 15:06:00'),
(7, 10, 'Prometheus Industries', 'May we have this dance? ', '2009-04-06 15:08:23'),
(10, 17, 'P.I. Ultimatum', 'ATTENTION:\r\n<BR>\r\n<BR>P.I. has completed polymer research, but we have not enough capital to apply for a patent. Our repeated requests to different organizations for funding have gone unanswered. Thus we have been driven to this point:\r\n<BR>\r\n<BR>The first organization that supplies us with $150 by 2:20 PM will receive 1/3 of all revenue from future dealings involving our polymer research. \r\n<BR>IF WE DO NOT RECEIVE FUNDING by 2:20 PM, we will make our research freely available, thus no one will be able to make it proprietary. \r\n<BR>\r\n<BR>You have four-ish minutes.', '2009-04-08 14:16:45'),
(9, 12, 'P.I.', 'As a matter of fact, P.I. completed its polymer research many minutes ago. However, we lack the funds to patent; the first organization to aid us stands to benefit greatly from our cooperation.', '2009-04-06 15:14:02'),
(11, 16, 'P.I. Ultimatum', 'ATTENTION:\r\n<BR>\r\n<BR>P.I. has completed polymer research, but we have not enough capital to apply for a patent. Our repeated requests to different organizations for funding have gone unanswered. Thus we have been driven to this point:\r\n<BR>\r\n<BR>The first organization that supplies us with $150 by 2:20 PM will receive 1/3 of all revenue from future dealings involving our polymer research. \r\n<BR>IF WE DO NOT RECEIVE FUNDING by 2:20 PM, we will make our research freely available, thus no one will be able to make it proprietary. \r\n<BR>\r\n<BR>You have four-ish minutes.', '2009-04-08 14:16:59'),
(12, 15, 'P.I. Ultimatum', 'ATTENTION:\r\n<BR>\r\n<BR>P.I. has completed polymer research, but we have not enough capital to apply for a patent. Our repeated requests to different organizations for funding have gone unanswered. Thus we have been driven to this point:\r\n<BR>\r\n<BR>The first organization that supplies us with $150 by 2:20 PM will receive 1/3 of all revenue from future dealings involving our polymer research. \r\n<BR>IF WE DO NOT RECEIVE FUNDING by 2:20 PM, we will make our research freely available, thus no one will be able to make it proprietary. \r\n<BR>\r\n<BR>You have four-ish minutes.', '2009-04-08 14:17:11'),
(13, 14, 'P.I. Ultimatum', 'ATTENTION:\r\n<BR>\r\n<BR>P.I. has completed polymer research, but we have not enough capital to apply for a patent. Our repeated requests to different organizations for funding have gone unanswered. Thus we have been driven to this point:\r\n<BR>\r\n<BR>The first organization that supplies us with $150 by 2:20 PM will receive 1/3 of all revenue from future dealings involving our polymer research. \r\n<BR>IF WE DO NOT RECEIVE FUNDING by 2:20 PM, we will make our research freely available, thus no one will be able to make it proprietary. \r\n<BR>\r\n<BR>You have four-ish minutes.', '2009-04-08 14:17:29'),
(14, 13, 'P.I. Ultimatum', 'ATTENTION:\r\n<BR>\r\n<BR>P.I. has completed polymer research, but we have not enough capital to apply for a patent. Our repeated requests to different organizations for funding have gone unanswered. Thus we have been driven to this point:\r\n<BR>\r\n<BR>The first organization that supplies us with $150 by 2:20 PM will receive 1/3 of all revenue from future dealings involving our polymer research. \r\n<BR>IF WE DO NOT RECEIVE FUNDING by 2:20 PM, we will make our research freely available, thus no one will be able to make it proprietary. \r\n<BR>\r\n<BR>You have four-ish minutes.', '2009-04-08 14:17:45'),
(15, 12, 'Everybody', 'Um, WTF NanoPost? You obviously have no idea how this is supposed to work, do you?', '2009-04-08 14:18:41'),
(16, 17, 'From the ETC:', '<img src="http://www.etcgroup.org/upload/gallery/16/02/cartoon_14.jpg">', '2009-04-08 14:25:10'),
(17, 19, 'ETC', 'This is NOT good and should be changed immediately.  This information and technology could get into the wrong hands!', '2009-04-08 14:45:05'),
(18, 21, 'P.I.', 'To expand on NanoPost''s announcement:\r\n<BR>\r\n<BR>Prometheus Industries has an inherent advantage in researching C&F technologies (25 minute research time). Give us the money plus 10% for the research cost of the basic IP you want, and we''ll research it for you. The property will then be yours to do with as you wish.', '2009-04-08 14:48:11'),
(19, 24, '', 'me! me! I want change!  ', '2009-04-08 14:57:32'),
(20, 29, 'really?', 'Are you surprised?', '2009-04-13 14:28:17'),
(21, 29, 'ETC', 'The public has the right to know about what is going on.', '2009-04-13 14:32:19'),
(22, 31, 'rice', 'what happened if the risk assignment isnt on the congress''s risk assignment chart?\r\n<BR>', '2009-04-13 14:43:20'),
(23, 31, 'does this make sense?', 'soooooo...\r\n<BR>\r\n<BR>nobody can get money until risk assessments improve?  risk assessments can''t improve until more research is done and the risk is mitigated at a higher level (which requires money)?  \r\n<BR>\r\n<BR>stalemate?   ', '2009-04-13 14:43:51'),
(24, 32, 'moar!!!!!', '', '2009-04-13 14:53:19'),
(25, 32, 'moar!!!', 'GIVE THEM MORE MONEY!!!\r\n<BR>\r\n<BR>research can''t advance without more risk mitigation!!!!\r\n<BR>if they can''t OFFER risk mitigation,  then how can anyone be expected to make progress?!?!', '2009-04-13 14:55:22'),
(26, 31, 'Congress', 'It was not the aim of Congress to completely neglect the poor risk labs; in fact, we took it upon ourselves to fund those labs more in order for them to bring up their risk rating.\r\n<BR>\r\n<BR>So while we kept the funding on lock for a short while, it was only to ensure that the risky labs could propose budgets that included risk management.  It was never Congress''s aim to create a "stalemate."', '2009-04-13 14:56:23'),
(27, 34, 'DO IT!!', 'stop giving money to researchers and give money to risk mitigation!!\r\n<BR>\r\n<BR>this sucks!!', '2009-04-13 14:58:21'),
(28, 34, 'NSF', 'The NSF was aware of the transaction between DARPA and IBM before it took place, and this was the reason that NASA was instead selected for funding at this time.', '2009-04-13 15:02:47'),
(29, 41, 'Anonymous', 'This is completely false. That is all.', '2009-04-15 14:43:27'),
(30, 44, 'This Guy', 'Not This Guy!', '2009-04-15 14:46:02'),
(31, 44, 'Kevin McDonald supporter', 'Kevin McDonald is by far the best candidate out there.  I''ll give you three reasons: strength, courage, determination.  That defines leadership.  And he also likes to shell out money for research.', '2009-04-15 14:47:03'),
(32, 44, '', 'Did he recently use NanoCure(TM)?', '2009-04-15 14:48:39'),
(33, 44, 'This guy', 'No, But this guy did!', '2009-04-15 14:50:26'),
(34, 44, 'Kevin McDonald Supporter', 'Kevin McDonald saved my whole family from a fire last weekend at my house.  What has Congress done for you lately? McDonald ''09.', '2009-04-15 14:52:10'),
(35, 45, 'Da boss', 'Nasa should really get a better risk rating!! ', '2009-04-15 14:52:30'),
(36, 45, 'Neil Armstrong', 'NASA Has mitigated all the risk possible for every technology except the first one.  NASA requires more funding to complete more research that will improve their rating.  \r\n<BR>\r\n<BR><3  Victims of the system.', '2009-04-15 14:54:35'),
(53, 54, '', '<img src="http://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/718smiley.svg/300px-718smiley.svg.png" />', '2009-04-20 14:29:30'),
(38, 41, 'Prometheus Industries PR', 'This article contains multiple factual errors and has created a negative attitude in the Nano research community toward P.I. We demand acknowledgment of these errors by NanoPost and a public apology.\r\n<BR>\r\n<BR>1: "Once P.I. finally gets funding they waste it on patents their partners have already researched."\r\n<BR>\r\n<BR>False: At the time, P.I. was not and had never partnered with the institutions that were in possession of the technology in question (NASA and IBM).\r\n<BR>\r\n<BR>2: "If their upper management doesn''t get their act together soon their lab will fall tremendously behind and funding will be impossible to find."\r\n<BR>\r\n<BR>False. Upon hearing the news of our successful patent, even in the face of larger corporations who had previously completed the research, our primary investor sent us a bonus of $1000. More recently, the same investor sent us $2700 for another research partnership with Rice University.\r\n<BR>\r\n<BR>3: "Firing current leaders and reorgnanizing their business plan could be their best option." \r\n<BR>\r\n<BR>False: The recent resurgence of P.I. under its original leadership shows that its managerial practices remain valuable and relevant in today''s research environment.\r\n<BR>', '2009-04-15 14:57:25'),
(39, 44, 'this guy.', 'They gave me lasers and rocket boots.  Now I''m a cyborg!  \r\n<BR>\r\n<BR>what did Kevin do for YOU!?!?!', '2009-04-15 14:57:29'),
(40, 47, 'anonymous', 'well, except for PI.', '2009-04-15 14:58:34'),
(41, 44, 'da boss', 'sykk.  Mayo ''09 !! ', '2009-04-15 14:58:55'),
(42, 47, 'P.I.', 'As of now, we have the only "excellent" risk rating.\r\n<BR>\r\n<BR>thank you very much.', '2009-04-15 14:59:23'),
(43, 47, 'this guy', '"the Rice Cooker is heating up." \r\n<BR>\r\n<BR>good!  i''ll have mine Fried.   duck sauce, not soy.  hold the baby corn, extra carrots', '2009-04-15 15:00:19'),
(44, 48, 'New Era', 'The new era will begin when Kevin McDonald reigns over Congress', '2009-04-15 15:04:18'),
(45, 49, 'Devastated', 'Kevin McDonald would have fixed this.', '2009-04-15 15:06:35'),
(54, 55, 'confuse', 'what this mean???', '2009-04-20 14:30:15'),
(47, 49, 'ETC', 'We didn''t make this happen...it just did.', '2009-04-15 15:12:02'),
(52, 55, 'WWWWWWWWWWWWWWWWWWWWWWWWWWWWWW`', 'YES!', '2009-04-20 14:25:06'),
(49, 50, 'ETC', 'Due to do the crisis in China, any research done on hybrid devices and graphene transistors should not and will not continue because they are directly derived from block co-polymer lithography. ', '2009-04-15 15:15:13'),
(55, 56, 'this guy', 'that picture truly inspires confidence in her as a candidate.\r\n<BR>', '2009-04-20 14:33:30'),
(51, 54, 'AEO employee', 'AE makes prom dresses? Since when?', '2009-04-20 14:18:52'),
(56, 59, '', '<object width="560" height="340"><param name="movie" value="http://www.youtube.com/v/NisCkxU544c&hl=en&fs=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/NisCkxU544c&hl=en&fs=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="560" height="340"></embed></object>', '2009-04-20 14:42:46'),
(57, 59, 'Amanda Reid', 'nice rhyme', '2009-04-20 14:46:22'),
(58, 59, 'this guy', 'is that a useful post?   \r\n<BR>\r\n<BR>this guy thinks not.', '2009-04-20 14:50:13'),
(59, 61, 'Ted Mayo', 'Yes we can.  Yes we can.', '2009-04-22 14:10:30'),
(60, 62, '', '<img src="http://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/718smiley.svg/300px-718smiley.svg.png" />', '2009-04-22 14:21:26'),
(61, 66, 'angry in 114', 'those jerks', '2009-04-22 14:47:49'),
(62, 66, '', 'The route bypassing the dangerous technology was approved and encouraged by Prof. Gorman.', '2009-04-22 14:50:16'),
(63, 66, 'this guy', 'okay,\r\n<BR>\r\n<BR>there was a second path to get to ALL the technology that Block Co-poly affected.  \r\n<BR>that means that once this path was taken, you can completely IGNORE BCP, effectively negating the risks associated with it.  \r\n<BR>\r\n<BR>in effect, everyone was the MOST responsible by completely avoiding a risky area of research.  \r\n<BR>\r\n<BR>this guy puts his full trust and confidence in every company that keeps their hands completely clean of dangerous research instead of feebly trying to "send ETC a proposal to fix their risk to be able to continue" (which sounds alot like ?f i give you money, you look the other way.").  regardless of what ETC does about the block, isn''t BCP still dangerous?!?', '2009-04-22 14:52:41'),
(64, 67, 'NASA', 'YYYAAAAAAAAAAYYYYYYYYYY!!!!!\r\n<BR>thanks to everyone that helped.', '2009-04-22 14:57:28'),
(65, 68, 'Economist', 'Let''s devaluate the currency.', '2009-04-22 15:00:47'),
(66, 72, 'Wehttam Onitrammas', 'ETC SUCKS!', '2009-04-22 15:11:10'),
(67, 74, '', '<table style=''font:11px arial; color:#333; background-color:#f5f5f5'' cellpadding=''0'' cellspacing=''0'' width=''360'' height=''353''><tbody><tr style=''background-color:#e5e5e5'' valign=''middle''><td style=''padding:2px 1px 0px 5px;''><a target=''_blank'' style=''color:#333; text-decoration:none; font-weight:bold;'' href=''http://www.thedailyshow.com/''>The Daily Show With Jon Stewart</a></td><td style=''padding:2px 5px 0px 5px; text-align:right; font-weight:bold;''>M - Th 11p / 10c</td></tr><tr style=''height:14px;'' valign=''middle''><td style=''padding:2px 1px 0px 5px;'' colspan=''2''><a target=''_blank'' style=''color:#333; text-decoration:none; font-weight:bold;'' href=''http://www.thedailyshow.com/video/index.jhtml?videoId=217010&title=p.w.-singer''>P.W. Singer</a></td></tr><tr style=''height:14px; background-color:#353535'' valign=''middle''><td colspan=''2'' style=''padding:2px 5px 0px 5px; width:360px; overflow:hidden; text-align:right''><a target=''_blank'' style=''color:#96deff; text-decoration:none; font-weight:bold;'' href=''http://www.thedailyshow.com/''>thedailyshow.com</a></td></tr><tr valign=''middle''><td style=''padding:0px;'' colspan=''2''><embed style=''display:block'' src=''http://media.mtvnservices.com/mgid:cms:item:comedycentral.com:217010'' width=''360'' height=''301'' type=''application/x-shockwave-flash'' wmode=''window'' allowFullscreen=''true'' flashvars=''autoPlay=false'' allowscriptaccess=''always'' allownetworking=''all'' bgcolor=''#000000''></embed></td></tr><tr style=''height:18px;'' valign=''middle''><td style=''padding:0px;'' colspan=''2''><table style=''margin:0px; text-align:center'' cellpadding=''0'' cellspacing=''0'' width=''100%'' height=''100%''><tr valign=''middle''><td style=''padding:3px; width:33%;''><a target=''_blank'' style=''font:10px arial; color:#333; text-decoration:none;'' href=''http://www.thedailyshow.com/full-episodes/index.jhtml''>Daily Show<br/> Full Episodes</a></td><td style=''padding:3px; width:33%;''><a target=''_blank'' style=''font:10px arial; color:#333; text-decoration:none;'' href=''http://www.thedailyshow.com/tagSearchResults.jhtml?term=Clusterf%23%40k+to+the+Poor+House''>Economic Crisis</a></td><td style=''padding:3px; width:33%;''><a target=''_blank'' style=''font:10px arial; color:#333; text-decoration:none;'' href=''http://www.indecisionforever.com''>Political Humor</a></td></tr></table></td></tr></tbody></table>', '2009-04-22 15:15:35'),
(68, 72, 'this guy', 'this guy recalls being asked for money initially (to the tune of $500 to wilson)  in addition to the proposal to remove the block.  Maybe this guy was confused?  doubtful.     \r\n<BR>no matter how you dice it, the research that was found to be dangerous did not affect the subsequent research.  \r\n<BR>\r\n<BR>agreed, safety is the most important aspect of a lab, but look at it from a research standpoint:\r\n<BR>Pay money (regardless of whether it''s to the Risk Management or to ETC) to use a technology that''s been PROVEN dangerous?  or conduct research in a safe field and progress normally ans responsibly from there?\r\n<BR>\r\n<BR>not sidestepping the issue of public safety,  but who can blame any of these companies for keeping their hands clean of the dangerous materials?  sounds safe to me.  now we have 2 Grand challenges that haven''t a TRACE of BCP in it.', '2009-04-22 15:16:05'),
(69, 74, 'IBM', 'IBM made bionic prosthesis public because we were the original researchers.  Please get your facts straight.', '2009-04-22 15:16:31'),
(70, 73, 'this guy.', 'you ETC kids are too easy to hate on.  \r\n<BR>\r\n<BR>boycott NASA?!?!?\r\n<BR>\r\n<BR>they make rockets...   who boycotts rockets?!?!?', '2009-04-22 15:16:43'),
(71, 73, '', 'And NASA never had any of the problem technologies, IBM was the only one who researched BCP, though they shared the research results with NASA.', '2009-04-22 15:17:32'),
(72, 76, '', 'How bout this as a grand challenge: writing the final paper', '2009-05-01 15:37:19'),
(73, 76, 'Kevin McDonald', 'Kevin McDonald would have prevented this.', '2009-05-02 20:22:00'),
(74, 76, '', 'Would he have prevented writing a final paper?', '2009-05-03 17:35:54'),
(75, 76, 'The Real Kevin McDonald', 'Someone is making claims I don''t think I can back...', '2009-05-03 17:52:09'),
(76, 76, 'The Real Real Kevin McDonald', 'Guys, stop it', '2009-05-04 01:56:51');

-- --------------------------------------------------------

--
-- Table structure for table `patents`
--

CREATE TABLE IF NOT EXISTS `patents` (
  `patent_id` int(11) NOT NULL auto_increment,
  `class_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  `research_type_id` int(11) NOT NULL default '0',
  `proposal` text NOT NULL,
  `submitted` datetime NOT NULL default '0000-00-00 00:00:00',
  `approved` char(1) NOT NULL default '?',
  `response` text NOT NULL,
  PRIMARY KEY  (`patent_id`),
  UNIQUE KEY `patent_id` (`patent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='The patents belonging to various groups.' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `patents`
--

INSERT INTO `patents` (`patent_id`, `class_id`, `group_id`, `research_type_id`, `proposal`, `submitted`, `approved`, `response`) VALUES
(1, 91, 49, 6, 'MIT is conducting research to develop new innovative bionic prosthetic developments. With chemical vapor deposition (CVD), we can put a thin, hole-free film on the prosthetic materials, making them more reliable. The film cannot be dissolved by either hydrophobic or hydrophilic materials. Our future objectives with CVD is to understand how the coating will behave in an active biological environment. In addition, the surface of the material will be modified for attachment of bioactive molecules to increase cell attraction for the material surface. This will maximize the integration and stability of the coating within the cellular matrix after implantation. Furthermore, CVD can be used for nanowire assembly because the coating can provide secure wiring since it will be hole free and other particles will not be able to penetrate through. This will ultimately be a key player in bionic prosthesis because secure nanowiring is needed for it to work. ', '2009-04-08 14:35:43', 'y', 'Approved, but state it as claims on next patent'),
(2, 91, 52, 9, 'Prometheus Industries'' Patent Application on Scanning Probe Microscopy Technology\r\n\r\nWhile this technology is not novel (IBM has previously researched this technology and shared it with NASA), it certainly is non-obvious (as directly imaging individual atoms represents a paradigm shift in how humans view the world and conduct research on the nanometer scale).\r\nMoreover, as this research is the fruit of a business partnership between a private company and an elite academic institution, it holds more inherent merit for patent consideration, as it can be used by Rice University freely and forever for the good of mankind. NASA and IBM, on the other hand, are a government agency (subject to all the vagaries of state secrecy) and a mega-corporation that has institutional ties to Big Capitalism and Government interests. \r\n\r\nThis concludes our patent request.', '2009-04-13 14:35:30', 'y', ''),
(3, 91, 52, 14, 'Proposal:  	Prometheus Industries'' Patent Application on Hierarchical Self-Assembly\r\n\r\nHierarchical self-assembly, also known as hierarchical self-organization, is non-covalent organization of individual building blocks are formed over distinct and multiple levels. This tool allows for greatly increases the flexibility and adaptability of a material. The whole entire structure typically behaves much different then the individual building blocks and levels.\r\n\r\nWith this technology, we can improve the efficiency and survivability of our bionic prostheses. Nano-machines inside the limbs could administer endorphins, platelets, and medicine as needed.', '2009-04-15 15:07:05', 'y', ''),
(4, 91, 52, 15, 'P.I. would like to propose a patent for Gradient Lithography.\r\n\r\nOur patent on Gradient Lithography claims that by using Diffraction Gradient Lithography (DGL), we could stretch out long DNA to flow through a nanochannel.  By going through the nanochannel, we could better view, analyze and modify the DNA. The following explains why this technology is novel, non-obvious, and useful.\r\n\r\nNovel;\r\nCurrent lithography techniques can create these nano-fluidic channels to stretch DNA but they are prohibitively expensive and time consuming. Gradient Lithography is a modified version of photo lithography that can create these nano-fluidic channels much quicker.\r\n\r\nNon Obvious;\r\nOther companies have attempted to make these nano-fluidic channels but have not been able to because the fabrication process takes too long. if gradient lithography was obvious then these companies would have used this technique.\r\n\r\nUseful;\r\nThis technology will allow us to view DNA in its stretched out form instead of a jumbled miss.', '2009-04-22 14:41:04', 'y', ''),
(5, 91, 52, 37, 'Developing a Bionic Prosthesis represents a useful technology in that it will enable the injured to replace lost body parts and the slightly strange to upgrade their bodies to become stronger and faster than normal humans.\r\nThe novelty of this advance is evidenced by the fact that this research was not in the possession of any faction until a short while ago. The non-obviousness of this patent is shown by the fact that it resides deep behind a barrier of required research (which also contributes to its novelty)\r\n\r\n', '2009-04-22 15:12:16', '?', '');

-- --------------------------------------------------------

--
-- Table structure for table `persons`
--

CREATE TABLE IF NOT EXISTS `persons` (
  `person_id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `group_id` int(11) unsigned NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY  USING BTREE (`person_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `persons`
--

INSERT INTO `persons` (`person_id`, `name`, `group_id`, `password`) VALUES
(7, 'congress', 45, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(8, 'darpa', 46, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(9, 'nsf', 47, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(10, 'nasa', 48, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(11, 'mit', 49, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(12, 'rice', 50, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(13, 'ibm', 51, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(14, 'pi', 52, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(15, 'etc', 53, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(16, 'wwic', 54, '*C142FB215B6E05B7C134B1A653AD4B455157FD79'),
(17, 'nanopost', 55, '*C142FB215B6E05B7C134B1A653AD4B455157FD79');

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE IF NOT EXISTS `research` (
  `research_id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL default '0',
  `research_type_id` int(11) NOT NULL default '0',
  `submitted` datetime NOT NULL default '0000-00-00 00:00:00',
  `time_left` int(11) NOT NULL default '30',
  `failed_time_left` int(11) NOT NULL default '0',
  `failed` enum('y','n') NOT NULL default 'n',
  `failed_message` text NOT NULL,
  `cost` float NOT NULL default '1000',
  `research_proposal` text NOT NULL,
  `research_sources` text NOT NULL,
  `patented` enum('y','n') NOT NULL default 'n',
  `owns_research` enum('y','n') NOT NULL default 'n',
  PRIMARY KEY  (`research_id`),
  UNIQUE KEY `research_id` (`research_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Links a group to its research completed.' AUTO_INCREMENT=143 ;

--
-- Dumping data for table `research`
--

INSERT INTO `research` (`research_id`, `group_id`, `research_type_id`, `submitted`, `time_left`, `failed_time_left`, `failed`, `failed_message`, `cost`, `research_proposal`, `research_sources`, `patented`, `owns_research`) VALUES
(1, 52, 10, '2009-04-06 14:32:15', 0, 0, 'n', '', 1000, 'Polymer research can lead advanced materials used in clothing, habitations, scientific and medical advances...all aspects of modern civilization.Advanced polymers exhibit such characteristics as increased toughness, light weight, self-healing, and "smart" material that remember previous shapes.\r\n\r\nAt this early stage, risk is minimal as most of the research involves widely available materials whose properties are well understood. This leads us to believe that no risk mitigation is required at this time, although it may prove necessary with higher technologies.\r\n\r\nObjectives: To patent polymer research and advance to Block co-polymer Lithography.', 'http://www.ipruw.com/\r\nhttp://www.opri.net/\r\nhttp://www.gkss.de/institute/polymer_research/index.html.en', 'n', 'y'),
(2, 50, 7, '2009-04-06 14:55:41', 0, 0, 'n', '', 1000, 'There are four types of the electron microscope: the  transmission electron microscope (TEM), the scanning electron microscope (SEM), the reflection electron microscope (REM), and  the scanning transmission electron microscope (STEM). All four "use a particle beam of electrons to illuminate a specimen and create a highly-magnified image." They have a greater resolving power and can obtain much higher magnifications.\r\n\r\nWe hope to use this to aid us in hierarchical self-assembly research.\r\n\r\nThis technology does not seem to pose and significant risk threat.', 'http://en.wikipedia.org/wiki/Electron_microscope\r\nhttp://upload.wikimedia.org/wikipedia/en/2/24/Electron_Microscope.png', 'n', 'y'),
(3, 51, 10, '2009-04-06 14:56:21', 0, 0, 'n', '', 1000, 'Background: Macro molecules used in plastics.  Polymers are often used in the computer industry.\r\n\r\nObjectives\r\nShort-term: Obtain the toolkit of block co-polymer lithography.  Preliminary research block co-polymer lithography revealed this process to create nanoscale integrated circuits that will significantly increase computer performance.\r\n\r\nLong-term: To eventually reach the grand challenge of energy independent devices.  \r\n\r\nRisk Analysis: IBM is a proven research company with strengths in polymer R&D.  This research will be concluded in a timely, efficient manner, with detailed results.', 'www.IBM.com\r\n\r\nhttp://blogs.zdnet.com/emergingtech/?p=1050', 'n', 'y'),
(5, 49, 6, '2009-04-06 15:01:40', 0, 0, 'n', '', 1000, 'MIT is conducting research to develop new innovative bionic prosthetic developments. With chemical vapor deposition (CVD), we can put a thin, hole-free film on the prosthetic materials, making them more reliable. The film cannot be dissolved by either hydrophobic or hydrophilic materials. Our future objectives with CVD is to understand how the coating will behave in an active biological environment. In addition, the surface of the material will be modified for attachment of bioactive molecules to increase cell attraction for the material surface. This will maximize the integration and stability of the coating within the cellular matrix after implantation. Risks involving this process is still being researched and we will work on that during our own investigation.', 'http://pubs.acs.org/doi/full/10.1021/bm070242s?cookieSet=1', 'n', 'y'),
(6, 48, 3, '2009-04-06 15:02:36', 0, 0, 'n', '', 1000, 'We are proposing research in optical lithography. We believe this technology will lead to advances in lithographic self assembly and quantum dots. This will open up opportunities for more advanced research in the future. \r\n\r\nOptical lithography is a fabrication method currently used to produce microchips. It employs UV or visible light to etch circuits into the surface of a silicon wafer. There is little risk involved in this research because it is already widely used in industry. ', 'http://www.siliconfareast.com/lith_optical.htm\r\nhttp://en.wikipedia.org/wiki/Optical_lithography', 'n', 'y'),
(25, 45, 10, '2009-04-08 14:32:56', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(26, 46, 10, '2009-04-08 14:32:56', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(27, 47, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(28, 48, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(29, 49, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(30, 50, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(31, 53, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(32, 54, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(33, 55, 10, '2009-04-08 14:32:57', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(34, 48, 9, '2009-04-08 14:40:56', 0, 0, 'n', '', 1000, 'We are proposing to research Scanning probe microscopy , which aids in the eventual research into Templated self-assembly and hybrid devices.  \r\n\r\nSPM is a set of technologies that aid in imaging materials on the order of several microns to angstroms large.   ', 'http://www.mobot.org/jwcross/spm/\r\nhttp://en.wikipedia.org/wiki/Scanning_probe_microscopy', 'n', 'y'),
(35, 51, 3, '2009-04-08 14:44:28', 0, 0, 'n', '', 0, 'Received from NASA.', '', 'n', 'y'),
(36, 51, 12, '2009-04-08 14:45:11', 0, 0, 'n', '', 1000, 'Background: Quantum dots can be used in transistors, solar cells, LEDs, and diode lasers.\r\n\r\nObjectives \r\nShort term: To gain the ability to research block co-polymer lithography as well viral self-assembly.\r\n\r\nLong term: To research energy independent devices.\r\n\r\nRisk Analysis: Low, considering quantum dots are specialty of IBM.', 'http://en.wikipedia.org/wiki/Quantum_dot', 'n', 'y'),
(37, 49, 4, '2009-04-08 15:09:54', 0, 0, 'n', '', 1000, 'Ion etching is a microfabrication process used to develop various materials, as well as circuitry, among other applications, on thin wafers.  These materials that can be developed are of superior quality to their macroscopically created counterparts, in that they higher levels of purity, leading to more efficient operations in the case of energy applications, and higher levels of reliability in their other applications.\r\nIon etching is generally a process in which chemically reactive plasmas are used to refine the materials on wafers, though a few other variations exist.  Principally the variations in Ion etching arise from the differing types of environment it is performed in, with varying gases in the chamber, as well as varying levels of pressure.\r\nAt MIT we are researching these various types of Ion Etching, and their applications to higher level technologies.', 'http://www.ee.byu.edu/cleanroom/rie_etching.phtml\r\nhttp://en.wikipedia.org/wiki/Reactive-ion_etching', 'n', 'y'),
(38, 48, 12, '2009-04-08 15:10:04', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(39, 51, 9, '2009-04-08 15:10:13', 0, 0, 'n', '', 0, 'Received from NASA.', '', 'n', 'y'),
(40, 48, 18, '2009-04-13 14:11:48', 0, 0, 'n', '', 2000, 'Short Term:\r\nAfter the research of Optical Lithography we have reached the limitations of that top down approach. We are now looking forward towards new ways of development in the nanoscale. The way we believe to best do this is by bottom up technology. Lithographic Self-Assembly is one of those technologies. With Lithographic Self-Assembly we?ll be able to pursue new avenues and discovery new material properties.\r\n', 'http://www.physorg.com/news72635583.html\r\nhttp://www3.interscience.wiley.com/journal/113511106/abstract', 'n', 'y'),
(41, 52, 9, '2009-04-13 14:23:46', 0, 0, 'n', '', 1000, 'Scanning Probe Background:\r\n\r\nScanning Probe Microscopy (SPM) helps to form images of surfaces using a physical probe that scans the specimen. An image of the surface is obtained by mechanically moving the probe in a raster scan of the specimen, line by line, and recording the probe-surface interaction as a function of position.\r\nBenefits of scanning probe microscopy are diffraction is not a limitation, a vacuum is not needed to look at the specimen, and you can use this device to create smaller structures. Additionally, the magnification of the specimen is unsurpassed.\r\nResearching SPM will help us work towards our final goal of researching groundbreaking bionic prostheses, which will aid the American Public greatly. Children born without limbs will hopefully be able to achieve some semblence of normalcy in their lives thanks to our research.\r\n\r\nBusiness Relationship:\r\n\r\nPI will research C&F for Rice University.\r\n\r\n-Rice\r\n\r\n\r\nMission Objective::\r\n\r\nElectron Microscopy --> hierarchical self-assembly --> nano-scaffolds -->regenerated tissues --> bionic prosthesis\r\n\r\npolymers --> block co-polymer lithography -->hybrid devices --> wearable computers --> bionic prosthesis\r\n\r\nAs well as spectroscopy and scanning probe microscopy', 'Rice University', 'n', 'y'),
(42, 50, 9, '2009-04-13 14:44:35', 0, 0, 'n', '', 0, 'Received from PI.', '', 'n', 'y'),
(43, 51, 19, '2009-04-13 14:46:16', 0, 0, 'n', '', 2000, 'Background: Block copolymers consist of two dissimilar blocks that have been chemically attached.  Since they are dissimilar, the two blocks seperate; however, since they are chemically linked, they cannot separate entirely from each other.  Furher, they separate at the nanoscale.\r\n\r\nObjectives: \r\nShort term: Gain the toolkit of block copolymer lithography to possibly share with NASA. \r\n\r\nLong term: Research the grand challenge of energy independent devices.\r\n\r\nRisk Analysis: IBM is planning upon applying for risk reduction on this toolkit.  Further, there is less risk in that IBM is experienced in this type of research.\r\n', 'http://www.internano.org/content/view/131/158/', 'n', 'y'),
(44, 48, 26, '2009-04-13 15:00:06', 0, 0, 'n', '', 3000, 'After the research Lithographic Self-Assembly we are now looking at newer ways of self assembly. We are looking to the future with assembled quantum dots. With this research we will be leading the market in semiconductor technology. This is a continuation of our bottom up approach to produce futuristic technology.', 'http://www.sciencemag.org/cgi/content/full/286/5448/2312\r\nhttp://en.wikipedia.org/wiki/Quantum_dot', 'n', 'y'),
(45, 51, 18, '2009-04-13 15:03:38', 0, 0, 'n', '', 0, 'Received from NASA.', '', 'n', 'y'),
(46, 50, 4, '2009-04-13 15:03:50', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(47, 49, 9, '2009-04-13 15:03:50', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(48, 48, 19, '2009-04-13 15:05:04', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(49, 52, 4, '2009-04-13 15:10:45', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(50, 52, 7, '2009-04-13 15:11:37', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(51, 49, 16, '2009-04-15 14:18:23', 0, 0, 'n', '', 2000, 'In order to research towards bionic prosthesis, we believe that we need to research nanowire assembly. This would allow for wire assembly on the 10^-9 scale, thereby making bionic prosthesis technology more efficient. Without nanowire assembly, bionic prosthesis would not be possible (the complicated nature of the technology would result in gigantic prosthestics without nanowire assembly). In the immediate future, nanowire is going to be necessary for the development of graphene transistors which will lead to much more efficient and smaller electronics than the silicon counterparts.', 'http://en.wikipedia.org/wiki/Nanowire', 'n', 'y'),
(52, 51, 25, '2009-04-15 14:24:38', 0, 0, 'n', '', 3000, 'Background: A hybrid is defined as being a ?combination of two or more different things, aimed at achieving a particular objective or goal?.  In terms of computers and electronics, there are hybrid couplers (used in radio and telecommunications), a hybrid coil (used in telephones), and a telephone hybrid (an electronic circuit used in telephones).\r\n\r\nObjectives\r\nShort term: Obtaining this prototype will enable our group to pursue research of wearable computers (after sharing prototypes with MIT).  We will also share this tech. with NASA so that they can research the portable photovoltaic technology.\r\nLong term: After sharing the research on the two aforementioned technologies occurs, the grand challenge of energy independent devices can be accomplished.\r\n\r\nRisk Mitigation: NASA will pursue moderate risk mitigation on the prototype of hybrid devices (staying true to our promise to the groups that funded us.)\r\n', 'http://en.wikipedia.org/wiki/Hybrid', 'n', 'y'),
(53, 51, 26, '2009-04-15 14:41:23', 0, 0, 'n', '', 0, 'Received from NASA.', '', 'n', 'y'),
(54, 48, 25, '2009-04-15 14:41:33', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(55, 52, 14, '2009-04-15 14:48:09', 0, 0, 'n', '', 2000, 'Hierarchical Self-Assembly:\r\n\r\n 	Hierarchical self-assembly, also known as hierarchical self-organization, is non-covalent organization of individual building blocks are formed over distinct and multiple levels. This tool allows for greatly increases the flexibility and adaptability of a material. The whole entire structure typically behaves much different then the individual building blocks and levels.\r\n\r\nWith this technology, we can improve the efficiency and survivability of our bionic prostheses. Nanomachines inside the limbs could administer endorphins, platelets, and medicine as needed.', 'Rice University', 'n', 'y'),
(56, 50, 14, '2009-04-15 15:00:34', 0, 0, 'n', '', 0, 'Received from PI.', '', 'n', 'y'),
(57, 51, 22, '2009-04-15 15:03:40', 0, 0, 'y', 'NANOCATASTROPHE!', 3000, 'Background: Current graphene transistors have very poor on-off ratio, which researchers are trying to improve.  Recently MIT built an experimental grapheme chip that is capable of taking an electric signal and producing an output signal.\r\n\r\nObjectives\r\nShort term: Obtaining this prototype will enable us to finally research wearable computers.\r\nLong term: Energy Independent devices.\r\n\r\nRisk Mitigation: High.\r\n', 'http://en.wikipedia.org/wiki/Graphene', 'n', 'n'),
(58, 52, 15, '2009-04-20 14:31:21', 0, 0, 'n', '', 2000, 'Proposal:\r\nPrometheus Industries and MIT hereby submit their request to engage in a partnership to research Gradient Lithography.\r\n\r\n\r\nBackground by MIT:\r\nAt MIT, we are working towards bionic prosthesis. Amputees could soon be fitted with prosthetic limbs that enable them to regain their sense of touch thanks to these new devices. For example, a bionic arm is effectively controlled by one''s thoughts, as sensors attached to their chest pick up electrical cues from their rerouted arm nerves. For this, we need the gradient lithography technology to further progress up the technology tree.', '', 'n', 'y'),
(59, 50, 17, '2009-04-20 14:33:31', 0, 0, 'n', '', 2000, 'Templated Self-Assembly is form of assembly that uses Self-organizing block copolymers to create variety of periodic nanoscale patterns and to eventually create long range order of particles on the nano scale. This top down lithographic assembly will eventually lead to bottom-up self-organization processes.  With this technology we will be able to research hybrid devices, which will lead to wearable computers and eventually bionic prostheses.', '', 'n', 'y'),
(60, 49, 15, '2009-04-22 13:58:51', 0, 0, 'n', '', 0, 'Received from PI.', '', 'n', 'y'),
(61, 51, 16, '2009-04-22 14:06:23', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(62, 48, 16, '2009-04-22 14:09:03', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(63, 51, 17, '2009-04-22 14:11:05', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(64, 50, 25, '2009-04-22 14:11:41', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(65, 48, 17, '2009-04-22 14:12:20', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(66, 48, 34, '2009-04-22 14:13:14', 0, 0, 'n', '', 4000, 'Portable photovoltaic devices will allow us to make industrious energy independent devices.   They are the future leading to energy independence.  This is the last step in our technological advancements.', 'http://www.solar-cheap.com/portable-flexible-solar-pv-modules-global-solar/', 'n', 'y'),
(67, 50, 16, '2009-04-22 14:14:42', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(68, 49, 25, '2009-04-22 14:14:59', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(69, 51, 22, '2009-04-22 14:15:17', 0, 0, 'n', '', 3000, 'Background: Current graphene transistors have very poor on-off ratio, which researchers are trying to improve. Recently MIT built an experimental grapheme chip that is capable of taking an electric signal and producing an output signal.\r\n\r\nObjectives\r\nShort term: Obtaining this prototype will enable us to finally research wearable computers.\r\nLong term: Energy Independent devices.\r\n\r\nRisk Mitigation: High.', 'http://en.wikipedia.org/wiki/Graphene', 'n', 'y'),
(70, 51, 31, '2009-04-22 14:24:28', 0, 0, 'n', '', 4000, 'Background: Wearable computers are used in various fields such as behavior modeling, health monitoring systems, information technologies, and media development.  They are particularly useful for applications that require computer support while the user is engaged in physical activity.  Wearable computers are consistent in that there is no need to ever turn the computer off; in addition, another benefit is that the computers allow the user to multi-task.  In essence, the computer is a prosthetic.\r\n\r\nObjectives\r\nShort term: Wearable computers would be the first technology obtained by the group.  This technology would then possibly be shared with NASA, as they are researching their own technology.\r\n\r\nLong term: Energy independent devices would then be eligible to be researched.\r\n\r\nRisk Mitigation: The group would pursue risk mitigation.', 'http://en.wikipedia.org/wiki/Wearable_computer', 'n', 'y'),
(71, 51, 34, '2009-04-22 14:29:06', 0, 0, 'n', '', 0, 'Received from NASA.', '', 'n', 'y'),
(72, 49, 22, '2009-04-22 14:29:27', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(73, 48, 22, '2009-04-22 14:30:38', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(74, 50, 22, '2009-04-22 14:31:32', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(75, 49, 14, '2009-04-22 14:32:12', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(76, 48, 31, '2009-04-22 14:32:37', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(77, 48, 39, '2009-04-22 14:33:28', 0, 0, 'n', '', 5000, 'Energy Independent Devices are here!  With this technology the world will be free from the boundaries set by former fuel sources.  Today is a glorious day for mankind.', 'http://www.psfk.com/2009/03/pic-independent-solar-compactor.html', 'n', 'y'),
(78, 50, 21, '2009-04-22 14:34:46', 0, 0, 'n', '', 3000, 'Nano-scaffolds are made by processes such as electrospinning and chemical treatment. They can be used for nerve damage treatment, by inserting them into the site of damage and allowing stem cells to stimulate regrowth.\r\n\r\nResearch with nano-scaffolds will help us reach our goal of bionic prothesis through regenerated tissues.', 'http://www.sciencedaily.com/releases/2008/02/080225085147.htm', 'n', 'y'),
(79, 49, 23, '2009-04-22 14:35:13', 0, 0, 'n', '', 3000, 'The term osteoconduction applies to a three-dimensional process that is observed when porous structures are implanted into or adjacent to bone. Capillaries, perivascular tissues, and osteoprogenitor cells migrate into porous spaces and incorporate the porous structure with newly formed bone. The observed process is characterized by an initial ingrowth of fibrovascular tissue that invades the porous structure followed by the later development of new bone applied directly within it.', 'http://www.ncbi.nlm.nih.gov/pubmed/10471764', 'n', 'y'),
(80, 51, 39, '2009-04-22 14:44:31', 0, 0, 'n', '', 0, 'Received from NASA.', '', 'n', 'y'),
(81, 49, 21, '2009-04-22 14:44:45', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(82, 49, 29, '2009-04-22 14:45:39', 0, 0, 'n', '', 4000, 'The goal of regenerative medicine is to recapitulate in adult wounded tissue the intrinsic regenerative processes that are involved in normal adult tissue maintenance. Recent advances allow adult wounds to heal in a similar fashion to the regenerative healing that is also present during fetal development. Research suggests that tissue loss or injury that occurs during early fetal development can be corrected by a regenerative mechanism since fetal wound healing appears to occur without scar formation.', 'http://www.woundsresearch.com/article/7380', 'n', 'y'),
(83, 50, 23, '2009-04-22 14:46:22', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(84, 52, 25, '2009-04-22 14:50:57', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(85, 52, 22, '2009-04-22 14:51:24', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(86, 51, 29, '2009-04-22 14:53:19', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(87, 52, 31, '2009-04-22 14:53:28', 0, 0, 'n', '', 4000, 'Computers that you can wear on your body. this research will lead to bionic prostheses.', 'Rice U.', 'n', 'y'),
(88, 50, 29, '2009-04-22 14:53:47', 0, 0, 'n', '', 0, 'Received from MIT.', '', 'n', 'y'),
(89, 51, 37, '2009-04-22 14:54:24', 0, 0, 'n', '', 5000, 'Background: Bionic prosthesis are used to restore lost functions of a human being.  One such example is a bionic eye.  The bionic eye is essentially an externally-worn camera that helps produce perceptions for human beings.\r\n\r\nObjectives: The grand challenge of BIONIC PROSTHESIS!\r\n\r\nRisk Mitigation: We will pursue excellent risk mitigation.\r\n', 'http://en.wikipedia.org/wiki/Visual_prosthetic', 'n', 'y'),
(90, 45, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(91, 46, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(92, 47, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(93, 49, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(94, 50, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(95, 52, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(96, 53, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(97, 54, 39, '2009-04-22 14:54:25', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(98, 55, 39, '2009-04-22 14:54:26', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(99, 50, 39, '2009-04-22 14:57:10', 0, 0, 'n', '', 0, 'Received from PI.', '', 'n', 'y'),
(100, 50, 31, '2009-04-22 15:01:26', 0, 0, 'n', '', 0, 'Received from PI.', '', 'n', 'y'),
(101, 49, 37, '2009-04-22 15:03:12', 0, 0, 'n', '', 0, 'Received from IBM.', '', 'n', 'y'),
(102, 52, 29, '2009-04-22 15:04:00', 0, 0, 'n', '', 0, 'Received from Rice.', '', 'n', 'y'),
(109, 52, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(110, 53, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(111, 54, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(112, 55, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(113, 45, 29, '2009-04-30 16:29:04', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(114, 46, 29, '2009-04-30 16:29:05', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(104, 45, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(105, 46, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(106, 47, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(107, 48, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(108, 50, 37, '2009-04-22 15:07:44', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(115, 47, 29, '2009-04-30 16:29:05', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(116, 48, 29, '2009-04-30 16:29:05', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(117, 53, 29, '2009-04-30 16:29:05', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(118, 54, 29, '2009-04-30 16:29:05', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(119, 55, 29, '2009-04-30 16:29:05', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(136, 45, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(137, 46, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(138, 47, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(139, 49, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(140, 53, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(141, 54, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(142, 55, 31, '2009-04-30 16:29:22', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(127, 45, 7, '2009-04-30 16:29:18', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(128, 46, 7, '2009-04-30 16:29:18', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(129, 47, 7, '2009-04-30 16:29:18', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(130, 48, 7, '2009-04-30 16:29:19', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(131, 49, 7, '2009-04-30 16:29:19', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(132, 51, 7, '2009-04-30 16:29:19', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(133, 53, 7, '2009-04-30 16:29:19', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(134, 54, 7, '2009-04-30 16:29:19', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y'),
(135, 55, 7, '2009-04-30 16:29:19', 0, 0, 'n', '', 0, 'Made public.', '', 'n', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `research_types`
--

CREATE TABLE IF NOT EXISTS `research_types` (
  `research_type_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `duration` int(11) NOT NULL default '30',
  `cost` int(11) NOT NULL default '1000',
  `and_parents` text NOT NULL,
  `or_parents` text NOT NULL,
  `children` text NOT NULL,
  `facility_req` text NOT NULL,
  `description` text NOT NULL,
  `level` int(11) NOT NULL default '0',
  `core_area` int(11) NOT NULL default '0',
  PRIMARY KEY  (`research_type_id`),
  UNIQUE KEY `research_topic_id` (`research_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 PACK_KEYS=0 COMMENT='Details the types of research available.' AUTO_INCREMENT=47 ;

--
-- Dumping data for table `research_types`
--

INSERT INTO `research_types` (`research_type_id`, `title`, `duration`, `cost`, `and_parents`, `or_parents`, `children`, `facility_req`, `description`, `level`, `core_area`) VALUES
(35, 'Sensory Enhancement', 8, 5000, '27,20', '', '', '', '', 5, 0),
(34, 'Portable Photovoltaic', 8, 4000, '25,26', '', '39', '', '', 4, 0),
(33, 'Flexible Displays', 8, 4000, '24,26', '', '38', '', '', 4, 0),
(32, 'Sensor Networks', 8, 4000, '24,26', '', '36', '', '', 4, 0),
(31, 'Wearable Computers', 8, 4000, '22,25', '', '37,39', '', '', 4, 0),
(30, 'Biomedic Hearing Aid', 8, 4000, '23,35', '', '35', '', '', 4, 0),
(29, 'Regenerated Tissue', 8, 4000, '21,23', '', '37', '', '', 4, 0),
(28, 'Neural Implant', 8, 4000, '21,22', '', '36,38', '', '', 4, 0),
(27, 'Retinal Implant', 8, 4000, '21,22', '', '35', '', '', 4, 0),
(26, 'Assembled Quantum Dots', 8, 3000, '', '18,20', '32,33,34', '', '', 3, 0),
(25, 'Hybrid Devices', 8, 3000, '', '17,19', '30,31,34', '', '', 3, 0),
(24, 'Resonant Tunnel Device', 8, 3000, '', '16,18', '32,33', '', '', 3, 0),
(23, 'Osteoconductive Materials', 8, 3000, '', '15,17', '29,20', '', '', 3, 0),
(22, 'Graphene Transistors', 8, 3000, '', '16,19', '27,28,29', '', '', 3, 0),
(20, 'Viral Self-Assembly', 8, 2000, '12', '', '26', '', '', 2, 0),
(19, 'Block Co-polymer Lithography', 8, 2000, '10', '', '22,25', '', '', 2, 0),
(18, 'Lithographic Self-Assembly', 8, 2000, '3', '', '24,26', '', '', 2, 0),
(17, 'Templated Self-Assembly', 8, 2000, '9', '', '23,25', '', '', 2, 0),
(16, 'Nanowire Assembly', 8, 2000, '6', '', '22,24', '', '', 2, 0),
(15, 'Gradient Lithography', 8, 2000, '4', '', '23', '', '', 2, 0),
(12, 'Quantum Dots', 8, 1000, '', '', '20', '', '', 1, 4),
(11, 'Nano-Carbon', 8, 1000, '', '', '', '', '', 1, 4),
(10, 'Polymers', 8, 1000, '', '', '19', '', '', 1, 4),
(9, 'Scanning Probe Microscopy', 8, 1000, '', '', '17', '', '', 1, 3),
(8, 'Spectroscopy', 8, 1000, '', '', '', '', '', 1, 3),
(6, 'Chemical Vapor Deposition', 8, 1000, '', '', '16', '', '', 1, 2),
(5, 'Molecular Epitaxy', 8, 1000, '', '', '', '', '', 1, 2),
(4, 'Ion Etching', 8, 1000, '', '', '15', '', '', 1, 2),
(21, 'Nano-Scaffolds', 8, 3000, '', '13,14', '27,28,29', '', '', 3, 0),
(14, 'Hierarchical Self-Assembly', 8, 2000, '7', '', '21', '', '', 2, 0),
(7, 'Electron Microscopy', 8, 1000, '', '', '14', '', '', 1, 3),
(13, 'Nanofluidics', 8, 2000, '1', '', '21', '', '', 2, 0),
(3, 'Optical Lithography', 8, 1000, '', '', '18', '', '', 1, 1),
(2, 'Electron Beam Lithography', 8, 1000, '', '', '', '', '', 1, 1),
(1, 'Imprint Lithography', 8, 1000, '', '', '13', '', '', 1, 1),
(36, 'Biometric Nanoparticle Tracking', 8, 5000, '28,32', '', '', '', '', 5, 0),
(37, 'Bionic Prosthesis', 8, 5000, '29,31', '', '', '', '', 5, 0),
(38, 'Nanoscale Neurosurgery', 8, 5000, '28,33', '', '', '', '', 5, 0),
(39, 'Energy Independent Devices', 8, 5000, '31,34', '', '', '', '', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `risk_certificate_types`
--

CREATE TABLE IF NOT EXISTS `risk_certificate_types` (
  `certificate_type_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `duration` int(11) NOT NULL default '30',
  `cost` int(11) NOT NULL default '1000',
  `requires` text NOT NULL,
  `description` text NOT NULL,
  `risk_reduction` int(11) NOT NULL default '5',
  `application_cost` int(11) NOT NULL default '0',
  PRIMARY KEY  (`certificate_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `risk_certificate_types`
--

INSERT INTO `risk_certificate_types` (`certificate_type_id`, `title`, `duration`, `cost`, `requires`, `description`, `risk_reduction`, `application_cost`) VALUES
(1, 'Basic Risk Mitigation', 30, 1000, '', 'This is the basic risk mitigation that basic facilities provide.', 5, 150),
(2, 'Moderate Risk Mitigation', 30, 2500, '1', 'Increases risk analysis and reduction abilities.', 10, 250),
(3, 'Good Risk Mitigation', 30, 3500, '1,2', 'Increases risk analysis and reduction abilities.', 15, 350),
(4, 'Excellent Risk Mitigation', 30, 5000, '1,2,3', 'Increases risk analysis and reduction abilities.', 20, 450);

-- --------------------------------------------------------

--
-- Table structure for table `risk_certificates`
--

CREATE TABLE IF NOT EXISTS `risk_certificates` (
  `certificate_id` int(11) NOT NULL auto_increment,
  `certificate_type_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '54',
  `submitted` datetime NOT NULL default '0000-00-00 00:00:00',
  `time_left` int(11) NOT NULL default '0',
  `cost` int(11) NOT NULL default '0',
  PRIMARY KEY  (`certificate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `risk_certificates`
--

INSERT INTO `risk_certificates` (`certificate_id`, `certificate_type_id`, `group_id`, `submitted`, `time_left`, `cost`) VALUES
(1, 1, 54, '0000-00-00 00:00:00', -1, 150),
(7, 3, 54, '2009-04-13 14:58:17', 0, 350),
(6, 2, 54, '2009-04-13 14:25:42', 0, 250),
(8, 4, 54, '2009-04-20 14:07:55', 0, 450);

-- --------------------------------------------------------

--
-- Table structure for table `simulation_settings`
--

CREATE TABLE IF NOT EXISTS `simulation_settings` (
  `settings_id` int(11) NOT NULL auto_increment,
  `class_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`settings_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Stores settings for the simulation (ala global variables).' AUTO_INCREMENT=45 ;

--
-- Dumping data for table `simulation_settings`
--

INSERT INTO `simulation_settings` (`settings_id`, `class_id`, `name`, `value`) VALUES
(41, 91, 'mins_per_month', '1'),
(42, 91, 'patent_fee', '250'),
(43, 91, 'in_session', 'y'),
(44, 91, 'clock', '6');

-- --------------------------------------------------------

--
-- Table structure for table `social_score`
--

CREATE TABLE IF NOT EXISTS `social_score` (
  `group_id` int(11) NOT NULL default '0',
  `score` int(11) NOT NULL default '0',
  PRIMARY KEY  (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `social_score`
--

INSERT INTO `social_score` (`group_id`, `score`) VALUES
(48, 104),
(49, 105),
(50, 108),
(52, 125),
(51, 145);

-- --------------------------------------------------------

--
-- Table structure for table `social_score_changes`
--

CREATE TABLE IF NOT EXISTS `social_score_changes` (
  `change_id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL default '0',
  `message` text NOT NULL,
  `adjustment` int(11) NOT NULL default '0',
  PRIMARY KEY  (`change_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `social_score_changes`
--

INSERT INTO `social_score_changes` (`change_id`, `group_id`, `message`, `adjustment`) VALUES
(22, 49, 'Risk Reduction: Ion Etching by WWIC', -2),
(21, 51, 'No risk mitigation for Quantum Dots', -7),
(20, 48, 'Risk Reduction: Scanning Probe Microscopy by WWIC', 0),
(19, 48, 'No risk mitigation for Optical Lithography', -7),
(18, 49, 'No risk mitigation for Chemical Vapor Deposition', -7),
(17, 48, 'No risk mitigation for Chemical Vapor Deposition', -9),
(16, 51, 'No risk mitigation for Polymers', -8),
(15, 50, 'No risk mitigation for Electron Microscopy', -5),
(14, 52, 'No risk mitigation for Polymers', 0),
(23, 48, 'Risk Reduction: Lithographic Self-Assembly by WWIC', -4),
(24, 52, 'Risk Reduction: Scanning Probe Microscopy by WWIC', 1),
(25, 51, 'Risk Reduction: Block Co-polymer Lithography by WWIC', 10),
(26, 48, 'Risk Reduction: Assembled Quantum Dots by WWIC', 8),
(27, 49, 'Risk Reduction: Nanowire Assembly by WWIC', 7),
(28, 51, 'Risk Reduction: Assembled Quantum Dots by WWIC', 14),
(29, 52, 'Risk Reduction: Hierarchical Self-Assembly by WWIC', 11),
(30, 49, 'EPIC NANOCATASTROPHE', -10),
(31, 51, 'Risk Reduction: Graphene Transistors by WWIC', 6),
(32, 52, 'Risk Reduction: Gradient Lithography by WWIC', 3),
(33, 50, 'Risk Reduction: Templated Self-Assembly by WWIC', 14),
(34, 48, 'Risk Reduction: Portable Photovoltaic by WWIC', 20),
(35, 51, 'Risk Reduction: Graphene Transistors by WWIC', 14),
(36, 51, 'Risk Reduction: Wearable Computers by WWIC', 20),
(37, 48, 'Risk Reduction: Energy Independent Devices by WWIC', 16),
(38, 50, 'Risk Reduction: Nano-Scaffolds by WWIC', 19),
(39, 49, 'Risk Reduction: Osteoconductive Materials by WWIC', 14),
(40, 49, 'Risk Reduction: Regenerated Tissue by WWIC', 13),
(41, 52, 'Risk Reduction: Wearable Computers by WWIC', 12),
(42, 51, 'Risk Reduction: Bionic Prosthesis by WWIC', 16),
(43, 52, 'Risk Reduction: Bionic Prosthesis by WWIC', 18);
